import React from "react";

export default function CenterText3() {
  return (
    <>
      <div
        className="chr-gallery-card-cover__image-wrapper"
        style={{
          boxSizing: "border-box",
          borderRadius: "0px 0px 24px 24px",
          flex: "1 1 0%",
          overflow: "hidden",
          WebkitBoxAlign: "stretch",
          alignItems: "stretch",
          display: "flex",
          WebkitBoxFlex: "1",
          position: "relative",
          listStyleType: "none",
          listStyle: "outside none none",
          textAlign: "left",
        }}
      >
        <img
          alt="A section of an abstract UI shows that Chrome is ready to be updated."
          src="https://www.google.com/chrome/static/images/engagement-homepage/updates/updates.png"
          srcSet="/chrome/static/images/engagement-homepage/updates/updates.png, /chrome/static/images/engagement-homepage/updates/updates-2x.png 2x"
          style={{
            boxSizing: "border-box",
            borderStyle: "none",
            display: "block",
            height: "auto",
            minHeight: "100%",
            objectFit: "cover",
            width: "100%",
          }}
        />
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
