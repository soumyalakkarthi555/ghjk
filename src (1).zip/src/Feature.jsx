import React from 'react'

const Feature = ({ title, description, image, reverse }) => {
  return (
    <div>
         <section className={`feature ${reverse ? 'reverse' : ''}`}>
      <div className="feature-text">
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
      <div className="feature-image">
        <img src={image} alt={title} />
      </div>
    </section>
        
        </div>
  )
}

export default Feature