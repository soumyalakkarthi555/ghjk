import React from "react";

export default function Adjacent() {
  return (
    <>
      <div
        className="chr-mosaic__wrapper"
        style={{
          boxSizing: "border-box",
          display: "flex",
          flexWrap: "nowrap",
          willChange: "transform",
          gap: "32px",
          transition: "transform 0.2s linear, -webkit-transform 0.2s linear",
          transform: "translate(-616.825px, 0px)",
        }}
      >
        <div
          className="chr-mosaic__item"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
            willChange: "transform",
            zIndex: 2,
            WebkitBoxOrdinalGroup: "2",
            order: 1,
            transform: "translate(1.47166%, -1.40768%) scale(1)",
            opacity: 1,
          }}
        >
          <div
            className="chr-mosaic__image-container"
            style={{
              boxSizing: "border-box",
              transition: "opacity 0.85s ease-in-out",
              animationDuration: "0.85s",
              animationFillMode: "forwards",
              animationTimingFunction: "ease-out",
              willChange: "transform, opacity",
              opacity: 1,
              animationName: "animate-in-right",
            }}
          >
            <img
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-1.webp"
              srcSet="/chrome/static/images/dev-components/chrome-gallery-1.webp, /chrome/static/images/dev-components/chrome-gallery-1-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                display: "block",
                height: "424px",
              }}
            />
          </div>
        </div>
        <div
          className="chr-mosaic__item"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
            willChange: "transform",
            WebkitBoxOrdinalGroup: "3",
            order: 2,
            zIndex: 1,
            transform: "translate(0%, 3.19927%) scale(1)",
            opacity: 0.936015,
          }}
        >
          <div
            className="chr-mosaic__image-container chr-mosaic__image-container--border"
            style={{
              boxSizing: "border-box",
              transition: "opacity 0.85s ease-in-out",
              animationDuration: "0.85s",
              animationFillMode: "forwards",
              animationTimingFunction: "ease-out",
              willChange: "transform, opacity",
              border: "0.6px solid rgb(218, 220, 224)",
              overflow: "hidden",
              borderRadius: "clamp(12px, 1.38889vw, 20px)",
              boxShadow: "rgba(32, 33, 37, 0.1) 0px 4.8px 12px 0px",
              opacity: 1,
              animationName: "animate-in-bottom-right",
            }}
          >
            <img
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-2.webp"
              srcSet="/chrome/static/images/dev-components/chrome-gallery-2.webp, /chrome/static/images/dev-components/chrome-gallery-2-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                display: "block",
                height: "424px",
              }}
            />
          </div>
        </div>
        <div
          className="chr-mosaic__item"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
            willChange: "transform",
            zIndex: 2,
            WebkitBoxOrdinalGroup: "4",
            order: 3,
            transform: "translate(0%, 0.511883%) scale(1.0096)",
            opacity: 1,
          }}
        >
          <div
            className="chr-mosaic__image-container"
            style={{
              boxSizing: "border-box",
              transition: "opacity 0.85s ease-in-out",
              animationDuration: "0.85s",
              animationFillMode: "forwards",
              animationTimingFunction: "ease-out",
              willChange: "transform, opacity",
              opacity: 1,
              animationName: "animate-in-bottom",
            }}
          >
            <img
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-3.webp"
              srcSet="/chrome/static/images/dev-components/chrome-gallery-3.webp, /chrome/static/images/dev-components/chrome-gallery-3-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                display: "block",
                height: "424px",
              }}
            />
          </div>
        </div>
        <div
          className="chr-mosaic__item"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
            willChange: "transform",
            zIndex: 2,
            WebkitBoxOrdinalGroup: "5",
            order: 4,
            transform: "translate(3.32724%, -1.66362%) scale(1.016)",
            opacity: 1,
          }}
        >
          <div
            className="chr-mosaic__image-container chr-mosaic__image-container--border"
            style={{
              boxSizing: "border-box",
              transition: "opacity 0.85s ease-in-out",
              animationDuration: "0.85s",
              animationFillMode: "forwards",
              animationTimingFunction: "ease-out",
              willChange: "transform, opacity",
              border: "0.6px solid rgb(218, 220, 224)",
              overflow: "hidden",
              borderRadius: "clamp(12px, 1.38889vw, 20px)",
              boxShadow: "rgba(32, 33, 37, 0.1) 0px 4.8px 12px 0px",
              opacity: 1,
              animationName: "animate-in-left",
            }}
          >
            <img
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-4.webp"
              srcSet="/chrome/static/images/dev-components/chrome-gallery-4.webp, /chrome/static/images/dev-components/chrome-gallery-4-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                display: "block",
                height: "424px",
              }}
            />
          </div>
        </div>
        <div
          className="chr-mosaic__item"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
            willChange: "transform",
            zIndex: 2,
            WebkitBoxOrdinalGroup: "6",
            order: 5,
            transform: "translate(1.53565%, 0.639854%) scale(1)",
            opacity: 1,
          }}
        >
          <div
            className="chr-mosaic__image-container"
            style={{
              boxSizing: "border-box",
              transition: "opacity 0.85s ease-in-out",
              animationDuration: "0.85s",
              animationFillMode: "forwards",
              animationTimingFunction: "ease-out",
              willChange: "transform, opacity",
              opacity: 1,
              animationName: "animate-in-bottom-left",
            }}
          >
            <img
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-5.webp"
              srcSet="/chrome/static/images/dev-components/chrome-gallery-5.webp, /chrome/static/images/dev-components/chrome-gallery-5-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                display: "block",
                height: "424px",
              }}
            />
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
