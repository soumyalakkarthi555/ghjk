import React from "react";

export default function CenterContext2() {
  return (
    <>
      <div
        className="chr-gallery chr-gallery--3-up chr-grid-default-parent"
        style={{
          boxSizing: "border-box",
          margin: "auto",
          padding: "0px 74px",
          maxWidth: "1440px",
          paddingBlock: "40px",
        }}
      >
        <ul
          className="chr-gallery__container chr-grid-default"
          style={{
            boxSizing: "border-box",
            margin: "0px",
            padding: "0px",
            display: "grid",
            columnGap: "64px",
            gridTemplateColumns: "repeat(12, 1fr)",
            rowGap: "40px",
          }}
        >
          <li
            className="chr-gallery-card chr-gallery-card--static chr-gallery-card--light-yellow chr-gallery-card--large chr-gallery-card--media-contained"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              opacity: 1,
              position: "relative",
              backgroundColor: "rgb(254, 247, 224)",
              maxHeight: "40rem",
              minHeight: "unset",
              maxWidth: "initial",
              gridColumn: "span 12",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--static chr-gallery-card-cover--light-yellow chr-gallery-card-cover--large chr-gallery-card-cover--no-image chr-gallery-card-cover--media-contained"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                height: "100%",
                position: "relative",
                container: "card / inline-size",
                minHeight: "unset",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  {"GOOGLE AI"}
                </h2>
                <h3
                  className="chr-headline-3 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "2.25rem",
                    lineHeight: "2.75rem",
                    letterSpacing: "-0.046875rem",
                  }}
                >
                  {"Access AI superpowers while you browse."}
                </h3>
                <div
                  className="chr-gallery-card-cover__body-wrapper"
                  style={{ boxSizing: "border-box" }}
                >
                  <p
                    className="chr-copy-xl chr-gallery-card-cover__body"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontSize: "1.125rem",
                      lineHeight: "1.75rem",
                    }}
                  >
                    {
                      "Google is integrating artificial intelligence to make our products more useful. We use AI for features like Search, Google Translate, and more, and we’re innovating new technologies responsibly."
                    }
                  </p>
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-gallery-card-cover__link"
                    href="https://ai.google/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      padding: "12px 0px",
                      letterSpacing: "0rem",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      fontWeight: 500,
                      color: "rgb(25, 103, 210)",
                      marginTop: "8px",
                      fontSize: "1.125rem",
                      lineHeight: "1.5rem",
                    }}
                  >
                    {"Explore Google"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                      }}
                    >
                      {"AI"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(25, 103, 210)",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </div>
              </div>
              <div
                className="chr-gallery-card-cover__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px 0px 24px 24px",
                  overflow: "hidden",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  position: "relative",
                  flex: "unset",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  WebkitBoxFlex: "unset",
                  transform: "scale(1)",
                }}
              >
                <picture
                  className="js-lazy-load"
                  style={{
                    boxSizing: "border-box",
                    display: "block",
                    WebkitBoxFlex: "1",
                    flexGrow: 1,
                    height: "100%",
                    minHeight: "unset",
                    objectFit: "unset",
                    width: "100%",
                  }}
                >
                  <source
                    type="image/webp"
                    media="(max-width: 599px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_mobile.webp 1x, /chrome/static/images/v2/gallery/ai_mobile-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(max-width: 599px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_mobile.png 1x, /chrome/static/images/v2/gallery/ai_mobile-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/webp"
                    media="(min-width: 1024px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_desktop.webp 1x, /chrome/static/images/v2/gallery/ai_desktop-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(min-width: 1024px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_desktop.png 1x, /chrome/static/images/v2/gallery/ai_desktop-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/webp"
                    media="(min-width: 600px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_tablet.webp 1x, /chrome/static/images/v2/gallery/ai_tablet-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(min-width: 600px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/ai_tablet.png 1x, /chrome/static/images/v2/gallery/ai_tablet-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <img
                    src="https://www.google.com/chrome/static/images/v2/gallery/ai_desktop.png"
                    srcSet="/chrome/static/images/v2/gallery/ai_desktop.png"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      WebkitBoxFlex: "1",
                      flexGrow: 1,
                      height: "100%",
                      minHeight: "unset",
                      objectFit: "unset",
                      width: "100%",
                    }}
                  />
                </picture>
              </div>
            </div>
          </li>
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--yellow chr-gallery-card--back-card-larger"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              backgroundColor: "rgb(253, 226, 147)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--yellow"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "640px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  {"Google Search"}
                </h2>
                <h3
                  className="chr-headline-3 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "2.25rem",
                    lineHeight: "2.75rem",
                    letterSpacing: "-0.046875rem",
                  }}
                >
                  {"The search bar you love, built right in."}
                </h3>
              </div>
              <div
                className="chr-gallery-card-cover__image-wrapper chr-gallery-card-cover__image-wrapper--responsive"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px 0px 24px 24px",
                  flex: "1 1 0%",
                  overflow: "hidden",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  WebkitBoxFlex: "1",
                  position: "relative",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  transform: "scale(1)",
                }}
              >
                <picture
                  className="js-lazy-load"
                  style={{ boxSizing: "border-box" }}
                >
                  <source
                    type="image/webp"
                    media="(max-width: 599px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_mobile.webp 1x, /chrome/static/images/v2/gallery/search-front_mobile-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(max-width: 599px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_mobile.png 1x, /chrome/static/images/v2/gallery/search-front_mobile-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/webp"
                    media="(min-width: 1024px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_desktop.webp 1x, /chrome/static/images/v2/gallery/search-front_desktop-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(min-width: 1024px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_desktop.png 1x, /chrome/static/images/v2/gallery/search-front_desktop-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/webp"
                    media="(min-width: 600px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_tablet.webp 1x, /chrome/static/images/v2/gallery/search-front_tablet-2x.webp 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="image/png"
                    media="(min-width: 600px)"
                    srcSet="https://www.google.com/chrome/static/images/v2/gallery/search-front_tablet.png 1x, /chrome/static/images/v2/gallery/search-front_tablet-2x.png 2x"
                    style={{ boxSizing: "border-box" }}
                  />
                  <img
                    alt="A user typed 'weather in Paris' into Chrome's address bar and it has instantly generated results."
                    src="https://www.google.com/chrome/static/images/v2/gallery/search-front_desktop.png"
                    srcSet="/chrome/static/images/v2/gallery/search-front_desktop.png"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      height: "auto",
                      minHeight: "100%",
                      objectFit: "cover",
                      width: "100%",
                    }}
                  />
                </picture>
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--light chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(26, 115, 232)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(255, 255, 255)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--yellow"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                minHeight: "640px",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="A user typed “300 usd to eur” into Chrome's address bar and it has instantly generated results."
                  src="https://www.google.com/chrome/static/images/v2/gallery/search-back.webp"
                  srcSet="/chrome/static/images/v2/gallery/search-back.webp 1x, /chrome/static/images/v2/gallery/search-back-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    aspectRatio: "16 / 9",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "Access a world of knowledge at your fingertips. Check the weather, solve math equations, and get instant search results, all contained inside your browser’s address bar."
                  }
                </p>
              </div>
            </div>
          </li>
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--white"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              backgroundColor: "rgb(255, 255, 255)",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              border: "1px solid rgb(218, 220, 224)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--white chr-gallery-card-cover--no-image"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "640px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  {"GOOGLE WORKSPACE"}
                </h2>
                <h3
                  className="chr-headline-3 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "2.25rem",
                    lineHeight: "2.75rem",
                    letterSpacing: "-0.046875rem",
                  }}
                >
                  {"Get things done, with or without"}
                  <span
                    className="nowrap"
                    style={{ boxSizing: "border-box", whiteSpace: "nowrap" }}
                  >
                    Wi-Fi.
                  </span>{" "}
                </h3>
              </div>
              <div
                className="chr-gallery-card-cover__dynamic-images-wrapper"
                style={{
                  boxSizing: "border-box",
                  flex: "1 1 0%",
                  WebkitBoxFlex: "1",
                  width: "100%",
                  position: "relative",
                  visibility: "visible",
                }}
              >
                <div
                  className="chr-gallery-card-cover__image chr-gallery-card-cover__image--cover"
                  style={{
                    boxSizing: "border-box",
                    transition: "transform 0.3s, -webkit-transform 0.3s",
                    left: "var(--left_start)",
                    position: "absolute",
                    top: "var(--top_start)",
                    zIndex: 1,
                    height: "100%",
                    transform: "scale(1)",
                  }}
                >
                  <img
                    className="js-lazy-load"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/gallery/workspace-1.webp"
                    srcSet="/chrome/static/images/v2/gallery/workspace-1.webp 1x, /chrome/static/images/v2/gallery/workspace-1-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      height: "auto",
                      minHeight: "100%",
                      objectFit: "cover",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-gallery-card-cover__image chr-gallery-card-cover__image--cover"
                  style={{
                    boxSizing: "border-box",
                    transition: "transform 0.3s, -webkit-transform 0.3s",
                    left: "var(--left_start)",
                    position: "absolute",
                    top: "var(--top_start)",
                    zIndex: 2,
                    height: "100%",
                    transform: "scale(1)",
                  }}
                >
                  <img
                    className="js-lazy-load"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/gallery/workspace-2.webp"
                    srcSet="/chrome/static/images/v2/gallery/workspace-2.webp 1x, /chrome/static/images/v2/gallery/workspace-2-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      height: "auto",
                      minHeight: "100%",
                      objectFit: "cover",
                      width: "100%",
                    }}
                  />
                </div>
              </div>
              <div
                className="chr-gallery-card-cover__static-images-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px 0px 24px 24px",
                  flex: "1 1 0%",
                  overflow: "hidden",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  WebkitBoxFlex: "1",
                  position: "relative",
                  display: "none",
                  visibility: "hidden",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  transform: "scale(1)",
                }}
              >
                <img
                  className="js-lazy-load"
                  aria-hidden="true"
                  src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2NDAgNDgwJz48L3N2Zz4="
                  srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2NDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjgwIDk2MCc+PC9zdmc+ 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    height: "auto",
                    minHeight: "100%",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--light chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(26, 115, 232)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(255, 255, 255)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--white"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                minHeight: "640px",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="A toggle allows users to access their files while working offline."
                  src="https://www.google.com/chrome/static/images/v2/gallery/offline.webp"
                  srcSet="/chrome/static/images/v2/gallery/offline.webp 1x, /chrome/static/images/v2/gallery/offline-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    aspectRatio: "16 / 9",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "Get things done in Gmail, Google Docs, Google Slides, Google Sheets, Google Translate and Google Drive, even without an Internet connection."
                  }
                </p>
                <a
                  className="chr-link chr-link--primary chr-link--external chr-gallery-card-back__link chr-gallery-card-back__link--padding"
                  href="https://support.google.com/docs/answer/6388102?hl=en&co=GENIE.Platform%3DDesktop"
                  rel="noopener"
                  tabIndex="-1"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(25, 103, 210)",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn how to work"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"offline"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
