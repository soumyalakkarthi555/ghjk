import React from "react";

export default function FooterText() {
  return (
    <>
      <div
        className="chr-grid-default-parent"
        style={{
          boxSizing: "border-box",
          margin: "auto",
          padding: "0px 74px",
          maxWidth: "1440px",
        }}
      >
        <div
          className="chr-grid-default"
          style={{
            boxSizing: "border-box",
            display: "grid",
            columnGap: "64px",
            gridTemplateColumns: "repeat(12, 1fr)",
          }}
        >
          <div
            className="chr-banner chr-background__blue"
            style={{
              boxSizing: "border-box",
              backgroundColor: "rgb(26, 115, 232)",
              borderRadius: "24px",
              gap: "40px",
              margin: "40px 0",
              WebkitBoxAlign: "center",
              alignItems: "center",
              display: "flex",
              WebkitBoxOrient: "vertical",
              WebkitBoxDirection: "normal",
              flexDirection: "column",
              position: "relative",
              gridColumn: "1 / span 12",
              padding: "80px 0 120px",
            }}
          >
            <div
              className="chr-banner__content chr-text-align--center"
              style={{
                boxSizing: "border-box",
                textAlign: "center",
                gap: "16px",
                WebkitBoxAlign: "center",
                alignItems: "center",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                maxWidth: "640px",
                width: "100%",
              }}
            >
              <h2
                className="chr-headline-1 chr-banner__title chr-text-white"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 700,
                  fontSize: "3.75rem",
                  lineHeight: "4.5rem",
                  letterSpacing: "-0.078125rem",
                  color: "rgb(255, 255, 255)",
                  textWrap: "pretty",
                  width: "100%",
                  padding: "0px 12px",
                }}
              >
                {"Take your browser with you"}
              </h2>
              <p
                className="chr-banner__body chr-copy-xl chr-text-white"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  fontSize: "1.125rem",
                  lineHeight: "1.75rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans Text", arial, sans-serif',
                  color: "rgb(255, 255, 255)",
                  display: "block",
                  visibility: "visible",
                  maxWidth: "614px",
                }}
              >
                {
                  "Download Chrome on your mobile device or tablet and sign into your account for the same browser experience, everywhere."
                }
              </p>
            </div>
            <span
              className="chr-banner__button"
              style={{ boxSizing: "border-box" }}
            >
              <button
                id="js-download-now"
                className="chr-download-button chr-download-button--hero chr-download-button--inverted js-download show"
                type="button"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  overflow: "visible",
                  textTransform: "none",
                  background: "none",
                  border: "none",
                  whiteSpace: "nowrap",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  cursor: "pointer",
                  display: "inline-flex",
                  height: "auto",
                  WebkitBoxPack: "center",
                  justifyContent: "center",
                  backgroundColor: "rgb(255, 255, 255)",
                  color: "rgb(25, 103, 210)",
                  borderRadius: "32px",
                  gap: "12px",
                  padding: "20px 32px",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "reverse",
                  flexDirection: "row-reverse",
                  fontSize: "1.125rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  appearance: "button",
                }}
              >
                <span
                  className="environment"
                  style={{ boxSizing: "border-box", display: "none" }}
                >
                  Get Chrome
                </span>
                <span
                  className="environment environment--active"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  Download Chrome
                </span>
                <svg
                  className="chr-button__icon chr-download-button__icon"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    fill: "rgb(25, 103, 210)",
                    height: "24px",
                    width: "24px",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#download"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </button>
            </span>
            <div
              className="chr-banner__qr chr-text-align--center"
              style={{
                boxSizing: "border-box",
                textAlign: "center",
                bottom: "0px",
                position: "absolute",
                right: "64px",
                display: "block",
                visibility: "visible",
              }}
            >
              <div
                className="chr-qr-code chr-qr-code--container"
                style={{
                  boxSizing: "border-box",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  textAlign: "center",
                  width: "fit-content",
                  borderRadius: "16px 16px 0px 0px",
                  padding: "24px",
                  backgroundColor: "rgb(255, 255, 255)",
                  position: "relative",
                }}
              >
                <div
                  className="chr-qr-code__qr-container"
                  style={{
                    boxSizing: "border-box",
                    display: "flex",
                    height: "fit-content",
                    width: "auto",
                  }}
                >
                  <img
                    className="js-lazy-load chr-qr-code__image"
                    alt="QR code to download chrome browser in mobile devices"
                    src="https://www.google.com/chrome/static/images/go-mobile-qrs/qr-take-it-with-you.webp"
                    srcSet="/chrome/static/images/go-mobile-qrs/qr-take-it-with-you.webp 1x, /chrome/static/images/go-mobile-qrs/qr-take-it-with-you-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "104px",
                      width: "104px",
                    }}
                  />
                </div>
                <div
                  className="chr-qr-code__content"
                  style={{
                    boxSizing: "border-box",
                    marginTop: "8px",
                    maxWidth: "140px",
                  }}
                >
                  <p
                    className="chr-caption chr-text-heading"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "0.75rem",
                      lineHeight: "1.125rem",
                      letterSpacing: "0.009375rem",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      color: "rgb(32, 33, 36)",
                    }}
                  >
                    {"Scan for the"}
                    <br style={{ boxSizing: "border-box" }} /> Chrome app{" "}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
