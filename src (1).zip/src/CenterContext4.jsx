import React from "react";

export default function CenterContext4() {
  return (
    <>
      <div
        className="chr-gallery chr-gallery--4-up chr-grid-default-parent"
        style={{
          boxSizing: "border-box",
          margin: "auto",
          padding: "0px 74px",
          maxWidth: "1440px",
          paddingBlock: "40px",
        }}
      >
        <ul
          className="chr-gallery__container chr-grid-default"
          style={{
            boxSizing: "border-box",
            margin: "0px",
            padding: "0px",
            columnGap: "64px",
            gridTemplateColumns: "repeat(12, 1fr)",
            rowGap: "40px",
            columnCount: 2,
            display: "block",
          }}
        >
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--blue chr-gallery-card--back-card-larger"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              backgroundColor: "rgb(26, 115, 232)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
              display: "inline-block",
              width: "100%",
              marginBottom: "40px",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--blue chr-gallery-card-cover--no-image"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "640px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {"PASSWORD MANAGER"}
                </h2>
                <h3
                  className="chr-headline-3 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "2.25rem",
                    lineHeight: "2.75rem",
                    letterSpacing: "-0.046875rem",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {"Use strong passwords on every site."}
                </h3>
              </div>
              <div
                className="chr-gallery-card-cover__dynamic-images-wrapper"
                style={{
                  boxSizing: "border-box",
                  flex: "1 1 0%",
                  WebkitBoxFlex: "1",
                  width: "100%",
                  position: "relative",
                  visibility: "visible",
                }}
              >
                <div
                  className="chr-gallery-card-cover__image chr-gallery-card-cover__image--cover"
                  style={{
                    boxSizing: "border-box",
                    transition: "transform 0.3s, -webkit-transform 0.3s",
                    left: "var(--left_start)",
                    position: "absolute",
                    top: "var(--top_start)",
                    zIndex: 1,
                    height: "100%",
                    transform: "scale(1)",
                  }}
                >
                  <img
                    className="js-lazy-load"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/gallery/passwords-fill-1.webp"
                    srcSet="/chrome/static/images/v2/gallery/passwords-fill-1.webp 1x, /chrome/static/images/v2/gallery/passwords-fill-1-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      height: "auto",
                      minHeight: "100%",
                      objectFit: "cover",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-gallery-card-cover__image chr-gallery-card-cover__image--cover"
                  style={{
                    boxSizing: "border-box",
                    transition: "transform 0.3s, -webkit-transform 0.3s",
                    left: "var(--left_start)",
                    position: "absolute",
                    top: "var(--top_start)",
                    zIndex: 2,
                    height: "100%",
                    transform: "scale(1)",
                  }}
                >
                  <img
                    className="js-lazy-load"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/gallery/passwords-fill-2.webp"
                    srcSet="/chrome/static/images/v2/gallery/passwords-fill-2.webp 1x, /chrome/static/images/v2/gallery/passwords-fill-2-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      display: "block",
                      height: "auto",
                      minHeight: "100%",
                      objectFit: "cover",
                      width: "100%",
                    }}
                  />
                </div>
              </div>
              <div
                className="chr-gallery-card-cover__static-images-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px 0px 24px 24px",
                  flex: "1 1 0%",
                  overflow: "hidden",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  WebkitBoxFlex: "1",
                  position: "relative",
                  display: "none",
                  visibility: "hidden",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  transform: "scale(1)",
                }}
              >
                <img
                  className="js-lazy-load"
                  aria-hidden="true"
                  src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2NDAgNDgwJz48L3N2Zz4="
                  srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2NDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjgwIDk2MCc+PC9zdmc+ 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    height: "auto",
                    minHeight: "100%",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--dark chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(255, 255, 255)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(25, 103, 210)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--blue"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                minHeight: "640px",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="A prompt asks the user if they want to save their password to Google Password Manager."
                  src="https://www.google.com/chrome/static/images/v2/gallery/save-password.webp"
                  srcSet="/chrome/static/images/v2/gallery/save-password.webp 1x, /chrome/static/images/v2/gallery/save-password-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    aspectRatio: "16 / 9",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {
                    "Chrome has Google Password Manager built in, which makes it simple to save, manage and protect your passwords online. It also helps you create stronger passwords for every account you use."
                  }
                </p>
                <a
                  className="chr-link chr-link--inverted chr-link--external chr-gallery-card-back__link chr-gallery-card-back__link--padding"
                  href="https://passwords.google/"
                  rel="noopener"
                  tabIndex="-1"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(255, 255, 255)",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn more about Password"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"Manager"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(255, 255, 255)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
          </li>
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--white chr-gallery-card--small chr-gallery-card--back-card-larger"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              backgroundColor: "rgb(255, 255, 255)",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              border: "1px solid rgb(218, 220, 224)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
              display: "inline-block",
              width: "100%",
              minHeight: "560px",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--white chr-gallery-card-cover--small chr-gallery-card-cover--no-image"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "520px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  {"ENHANCED SAFE BROWSING"}
                </h2>
                <h3
                  className="chr-headline-2 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "48px",
                    letterSpacing: "-1px",
                    lineHeight: "56px",
                  }}
                >
                  {
                    "Browse with the confidence that you're staying safer online."
                  }
                </h3>
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--light chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(26, 115, 232)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(255, 255, 255)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--white"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
                minHeight: "520px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper chr-gallery-card-back__image-wrapper--small"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  maxHeight: "200px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="A red alert warns the user that a site they are trying to visit contains malware."
                  src="https://www.google.com/chrome/static/images/v2/gallery/malware-alert.webp"
                  srcSet="/chrome/static/images/v2/gallery/malware-alert.webp 1x, /chrome/static/images/v2/gallery/malware-alert-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                    aspectRatio: "243 / 100",
                    maxHeight: "200px",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "Chrome's Safe Browsing warns you about malware or phishing attacks. Turn on Enhanced Safe Browsing for even more safety protections."
                  }
                </p>
                <a
                  className="chr-link chr-link--primary chr-link--external chr-gallery-card-back__link chr-gallery-card-back__link--padding"
                  href="https://support.google.com/chrome/answer/9890866"
                  rel="noopener"
                  tabIndex="-1"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(25, 103, 210)",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn more about Safe"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"Browsing"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
          </li>
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--light-blue-01 chr-gallery-card--small chr-gallery-card--back-card-larger"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              backgroundColor: "rgb(232, 240, 254)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
              display: "inline-block",
              width: "100%",
              WebkitBoxOrdinalGroup: "5",
              order: 4,
              marginBottom: "40px",
              minHeight: "560px",
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--light-blue-01 chr-gallery-card-cover--small chr-gallery-card-cover--no-image"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "520px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  {"SAFETY CHECK"}
                </h2>
                <h3
                  className="chr-headline-2 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "48px",
                    letterSpacing: "-1px",
                    lineHeight: "56px",
                  }}
                >
                  {"Check your safety level in real time with just one click."}
                </h3>
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--light chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(26, 115, 232)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(255, 255, 255)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--light-blue-01"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
                minHeight: "520px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper chr-gallery-card-back__image-wrapper--small"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  maxHeight: "200px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="An alert shows that Chrome’s safety check has been completed and the browser is up to date."
                  src="https://www.google.com/chrome/static/images/v2/gallery/safety-check.webp"
                  srcSet="/chrome/static/images/v2/gallery/safety-check.webp 1x, /chrome/static/images/v2/gallery/safety-check-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                    aspectRatio: "243 / 100",
                    maxHeight: "200px",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "Chrome's Safety Check confirms the overall security and privacy of your browsing experience, including your saved passwords, extensions and settings. If something needs attention, Chrome will help you fix it."
                  }
                </p>
                <a
                  className="chr-link chr-link--primary chr-link--external chr-gallery-card-back__link chr-gallery-card-back__link--padding"
                  href="https://blog.google/products/chrome/more-intuitive-privacy-and-security-controls-chrome/"
                  rel="noopener"
                  tabIndex="-1"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(25, 103, 210)",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn more about safety on"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"Chrome"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
          </li>
          <li
            className="chr-gallery-card chr-gallery-card--interactive chr-gallery-card--dark-blue chr-gallery-card--back-card-larger"
            style={{
              boxSizing: "border-box",
              listStyle: "none",
              margin: "0px",
              padding: "0px",
              borderRadius: "24px",
              overflow: "hidden",
              transition: "background-color 200ms ease-out",
              opacity: 1,
              position: "relative",
              cursor: "pointer",
              backgroundColor: "rgb(23, 78, 166)",
              maxHeight: "40rem",
              maxWidth: "initial",
              gridColumn: "span 6",
              display: "inline-block",
              width: "100%",
              WebkitBoxOrdinalGroup: "4",
              order: 3,
            }}
          >
            <div
              className="chr-gallery-card-cover chr-gallery-card-cover--interactive chr-gallery-card-cover--dark-blue"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
                width: "100%",
                position: "relative",
                zIndex: 1,
                minHeight: "640px",
              }}
            >
              <div
                className="chr-gallery-card-cover__text-wrapper"
                style={{
                  boxSizing: "border-box",
                  gap: "16px",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  padding: "40px 64px",
                }}
              >
                <h2
                  className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontSize: "0.875rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0.03125rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    textTransform: "uppercase",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {"PRIVACY GUIDE"}
                </h2>
                <h3
                  className="chr-headline-3 chr-gallery-card-cover__heading"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "2.25rem",
                    lineHeight: "2.75rem",
                    letterSpacing: "-0.046875rem",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {
                    "Keep your privacy under your control with easy-to-use settings."
                  }
                </h3>
              </div>
              <div
                className="chr-gallery-card-cover__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px 0px 24px 24px",
                  flex: "1 1 0%",
                  overflow: "hidden",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  WebkitBoxFlex: "1",
                  position: "relative",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  transform: "scale(1)",
                }}
              >
                <img
                  className="js-lazy-load"
                  aria-hidden="true"
                  src="https://www.google.com/chrome/static/images/v2/gallery/google-safety.webp"
                  srcSet="/chrome/static/images/v2/gallery/google-safety.webp 1x, /chrome/static/images/v2/gallery/google-safety-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    height: "auto",
                    minHeight: "100%",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
            </div>
            <button
              className="chr-action-icon chr-action-icon--card chr-action-icon--regular chr-action-icon--dark chr-gallery-card__action-icon"
              aria-label="Flip card"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                appearance: "button",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                borderRadius: "50%",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                WebkitBoxAlign: "center",
                alignItems: "center",
                cursor: "pointer",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                transform: "scale(1)",
                backgroundColor: "rgb(255, 255, 255)",
                padding: "1px 6px",
                position: "absolute",
                zIndex: 2,
                bottom: "24px",
                height: "56px",
                right: "24px",
                width: "56px",
              }}
            >
              <svg
                className="chr-action-icon__icon"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  transition:
                    "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                  overflow: "hidden",
                  height: "32px",
                  width: "32px",
                  fill: "rgb(25, 103, 210)",
                }}
              >
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#plus"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
            <div
              className="chr-gallery-card-back chr-gallery-card-back--interactive chr-gallery-card-back--dark-blue"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                minHeight: "640px",
                width: "100%",
                left: "0px",
                pointerEvents: "none",
                position: "absolute",
                top: "0px",
                zIndex: 1,
                padding: "64px 64px",
              }}
            >
              <div
                className="chr-gallery-card-back__image-wrapper"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "16px",
                  overflow: "hidden",
                  marginBottom: "24px",
                  opacity: 0,
                }}
              >
                <img
                  className="js-lazy-load"
                  alt="An isolated module asks users if they would like to explore the Privacy Guide."
                  src="https://www.google.com/chrome/static/images/v2/gallery/privacy-guide.webp"
                  srcSet="/chrome/static/images/v2/gallery/privacy-guide.webp 1x, /chrome/static/images/v2/gallery/privacy-guide-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    aspectRatio: "16 / 9",
                    display: "block",
                    objectFit: "cover",
                    width: "100%",
                  }}
                />
              </div>
              <div
                className="chr-gallery-card-back__text-wrapper chr-gallery-card-back__text-wrapper--padding"
                style={{ boxSizing: "border-box", opacity: 0 }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-back__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    marginBottom: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                    color: "rgb(255, 255, 255)",
                  }}
                >
                  {
                    "Chrome makes it easy to understand exactly what you’re sharing online and who you’re sharing it with. Simply use the Privacy Guide, a step-by-step tour of your privacy settings."
                  }
                </p>
                <a
                  className="chr-link chr-link--inverted chr-link--external chr-gallery-card-back__link chr-gallery-card-back__link--padding"
                  href="https://blog.google/products/chrome/more-intuitive-privacy-and-security-controls-chrome/"
                  rel="noopener"
                  tabIndex="-1"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(255, 255, 255)",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn more about intuitive safety"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"controls"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(255, 255, 255)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
