import React from "react";

export default function CenterContext() {
  return (
    <>
      <div
        className="chr-grid-default chr-take-over-animation__container"
        style={{
          boxSizing: "border-box",
          display: "grid",
          columnGap: "64px",
          gridTemplateColumns: "repeat(12, 1fr)",
          padding: "80px 80px 0 80px",
          height: "auto",
          position: "sticky",
          rowGap: "80px",
          top: "calc(0px*-1)",
        }}
      >
        <div
          className="chr-take-over-animation__title"
          style={{
            boxSizing: "border-box",
            gridColumn: "3 / span 8",
            fontWeight: 700,
            opacity: 1,
            position: "relative",
            textAlign: "center",
            transform: "translate(0, 0px) scale(1)",
          }}
        >
          <h2
            className="chr-headline-1"
            aria-label="Make it yours and take it with you"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              color: "rgb(32, 33, 36)",
              fontFamily: '"Google Sans", arial, sans-serif',
              fontWeight: 700,
              fontSize: "3.75rem",
              lineHeight: "4.5rem",
              letterSpacing: "-0.078125rem",
            }}
          >
            {"Make it"}
            <span
              className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--red chr-heading-pill__pill-container--medium animated"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                overflow: "hidden",
                position: "relative",
                textAlign: "center",
                borderRadius: "48px",
                display: "inline-flex",
                WebkitBoxOrient: "horizontal",
                WebkitBoxDirection: "normal",
                flexDirection: "row",
                backgroundColor: "rgb(241, 243, 244)",
                color: "rgb(95, 99, 104)",
                WebkitBoxAlign: "center",
                alignItems: "center",
                transform: "none",
                animationFillMode: "both",
                animationTimingFunction: "ease-in-out",
                animationDelay: "1.5s",
                animationDuration: "200ms",
                animationName: "redColorChange",
                lineHeight: "4.5rem",
              }}
            >
              <span
                className="chr-heading-pill__mock"
                style={{ boxSizing: "border-box", height: "40px" }}
              />
              <div
                className="chr-lottie-animation chr-heading-pill__icon"
                style={{
                  boxSizing: "border-box",
                  display: "inline-flex",
                  flexShrink: 0,
                  marginLeft: "8px",
                  height: "72px",
                  width: "72px",
                }}
              >
                <svg
                  height="72"
                  width="72"
                  preserveAspectRatio="xMidYMid meet"
                  viewBox="0 0 72 72"
                  xmlns="http://www.w3.org/2000/svg"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    width: "100%",
                    height: "100%",
                    transform: "translate3d(0px, 0px, 0px)",
                  }}
                >
                  <defs style={{ boxSizing: "border-box" }}>
                    <clippath
                      id="__lottie_element_70"
                      style={{ boxSizing: "border-box" }}
                    >
                      <rect
                        height="72"
                        width="72"
                        x="0"
                        y="0"
                        style={{ boxSizing: "border-box" }}
                      />
                    </clippath>
                  </defs>
                  <g
                    clipPath="url(#__lottie_element_70)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <g
                      opacity="1"
                      transform="matrix(1,0,0,1,33,4.184999942779541)"
                      style={{ boxSizing: "border-box", display: "block" }}
                    >
                      <g
                        opacity="1"
                        transform="matrix(1,0,0,1,0,0)"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d=" M-12,-5.010000228881836 C-12,-5.010000228881836 12,-5.010000228881836 12,-5.010000228881836 C12,-5.010000228881836 12,17.5 12,17.5 C12,17.5 -12,17.5 -12,17.5 C-12,17.5 -12,-5.010000228881836 -12,-5.010000228881836z"
                          fill="rgb(246,174,169)"
                          fillOpacity="1"
                          style={{ boxSizing: "border-box" }}
                        />
                      </g>
                    </g>
                    <g
                      opacity="1"
                      transform="matrix(1,0,0,1,36,33.75)"
                      style={{ boxSizing: "border-box", display: "block" }}
                    >
                      <g
                        opacity="1"
                        transform="matrix(1,0,0,1,0,0)"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d=" M11,-16 C11,-16 11,-18 11,-18 C11,-19.100000381469727 10.100000381469727,-20 9,-20 C9,-20 -15,-20 -15,-20 C-16.100000381469727,-20 -17,-19.100000381469727 -17,-18 C-17,-18 -17,-10 -17,-10 C-17,-8.899999618530273 -16.100000381469727,-8 -15,-8 C-15,-8 9,-8 9,-8 C10.100000381469727,-8 11,-8.899999618530273 11,-10 C11,-10 11,-12 11,-12 C11,-12 13,-12 13,-12 C13,-12 13,-4 13,-4 C13,-4 -5,-4 -5,-4 C-6.099999904632568,-4 -7,-3.0999999046325684 -7,-2 C-7,-2 -7,18 -7,18 C-7,19.100000381469727 -6.099999904632568,20 -5,20 C-5,20 -1,20 -1,20 C0.10000000149011612,20 1,19.100000381469727 1,18 C1,18 1,0 1,0 C1,0 15,0 15,0 C16.100000381469727,0 17,-0.8999999761581421 17,-2 C17,-2 17,-14 17,-14 C17,-15.100000381469727 16.100000381469727,-16 15,-16 C15,-16 11,-16 11,-16z"
                          fill="rgb(234,67,53)"
                          fillOpacity="1"
                          style={{ boxSizing: "border-box" }}
                        />
                      </g>
                    </g>
                  </g>
                </svg>
              </div>
              <span
                className="chr-heading-pill__pill-text"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  display: "inline-flex",
                  maxHeight: "4.5rem",
                  fontSize: "3.25rem",
                  paddingRight: "32px",
                }}
              >
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    animationDelay: "20ms",
                    animationDuration: ".7s",
                    animationFillMode: "both",
                    animationName: "charBounceSlideInUp",
                    animationTimingFunction: "ease-in-out",
                    visibility: "visible",
                  }}
                >
                  {"y"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    animationDelay: "40ms",
                    animationDuration: ".7s",
                    animationFillMode: "both",
                    animationName: "charBounceSlideInUp",
                    animationTimingFunction: "ease-in-out",
                    visibility: "visible",
                  }}
                >
                  {"o"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    animationDelay: "60ms",
                    animationDuration: ".7s",
                    animationFillMode: "both",
                    animationName: "charBounceSlideInUp",
                    animationTimingFunction: "ease-in-out",
                    visibility: "visible",
                  }}
                >
                  {"u"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    animationDelay: "80ms",
                    animationDuration: ".7s",
                    animationFillMode: "both",
                    animationName: "charBounceSlideInUp",
                    animationTimingFunction: "ease-in-out",
                    visibility: "visible",
                  }}
                >
                  {"r"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    animationDelay: "100ms",
                    animationDuration: ".7s",
                    animationFillMode: "both",
                    animationName: "charBounceSlideInUp",
                    animationTimingFunction: "ease-in-out",
                    visibility: "visible",
                  }}
                >
                  {"s"}
                </span>
              </span>
            </span>
            {"and take it with you"}
          </h2>
        </div>
        <div
          className="chr-take-over-animation__mask"
          style={{
            boxSizing: "border-box",
            borderRadius: "16px",
            gridColumn: "2 / span 10",
            overflow: "clip",
            aspectRatio: "16 / 9",
            position: "relative",
            transform: "scale(1)",
            width: "100%",
            willChange: "contents",
            zIndex: 10,
          }}
        >
          <div
            className="chr-take-over-animation__take-over"
            style={{
              boxSizing: "border-box",
              overflow: "hidden",
              left: "0px",
              top: "0px",
              height: "calc((1 - 0)*100%)",
              position: "relative",
              zIndex: 2,
            }}
          >
            <img
              className="chr-take-over-animation__image"
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-arches.webp"
              srcSet="/chrome/static/images/v2/yours-take-over/theme-arches.webp, /chrome/static/images/v2/yours-take-over/theme-arches-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                width: "100%",
              }}
            />
          </div>
          <div
            className="chr-take-over-animation__take-over-v2"
            style={{
              boxSizing: "border-box",
              overflow: "hidden",
              left: "0px",
              position: "absolute",
              top: "0px",
              height: "calc((1 - 0)*100%)",
              zIndex: 1,
            }}
          >
            <img
              className="chr-take-over-animation__image"
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-ui-1.webp"
              srcSet="/chrome/static/images/v2/yours-take-over/theme-ui-1.webp, /chrome/static/images/v2/yours-take-over/theme-ui-1-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                width: "100%",
              }}
            />
          </div>
          <div
            className="chr-take-over-animation__take-over-v3"
            style={{
              boxSizing: "border-box",
              overflow: "hidden",
              left: "0px",
              position: "absolute",
              top: "0px",
              zIndex: 0,
            }}
          >
            <img
              className="chr-take-over-animation__image chr-take-over-animation__image--border"
              aria-hidden="true"
              src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-ui-2.webp"
              srcSet="/chrome/static/images/v2/yours-take-over/theme-ui-2.webp, /chrome/static/images/v2/yours-take-over/theme-ui-2-2x.webp 2x"
              style={{
                boxSizing: "border-box",
                borderStyle: "none",
                width: "100%",
                border: "2px solid rgb(255, 255, 255)",
              }}
            />
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
