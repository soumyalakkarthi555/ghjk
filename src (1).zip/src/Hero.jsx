import React from "react";

export default function Hero() {
  return (
    <>
    
      <svg
        className="chr-header-v3__logo-icon"
        style={{
          boxSizing: "border-box",
          height: "36px",
          minHeight: "36px",
          width: "134px",
          overflow: "hidden",
          color: "rgb(0, 0, 238)",
          cursor: "pointer",
          fontSize: "1.375rem",
          font: '22px / 32px "Google Sans", arial, sans-serif',
          lineHeight: "2rem",
        }}
      >
        <defs style={{ boxSizing: "border-box" }}>
          <lineargradient
            id="linear-gradient"
            gradientTransform="translate(0 -1034)"
            gradientUnits="userSpaceOnUse"
            x1="23.9"
            x2="5.15"
            y1="1076.02"
            y2="1043.54"
            style={{ boxSizing: "border-box" }}
          >
            <stop
              offset="0"
              stopColor="#1e8e3e"
              style={{ boxSizing: "border-box" }}
            />
            <stop
              offset="1"
              stopColor="#34a853"
              style={{ boxSizing: "border-box" }}
            />
          </lineargradient>
          <lineargradient
            id="linear-gradient-2"
            gradientTransform="translate(0 -1034)"
            gradientUnits="userSpaceOnUse"
            x1="18.32"
            x2="37.07"
            y1="1077.42"
            y2="1044.93"
            style={{ boxSizing: "border-box" }}
          >
            <stop
              offset="0"
              stopColor="#fcc934"
              style={{ boxSizing: "border-box" }}
            />
            <stop
              offset="1"
              stopColor="#fbbc04"
              style={{ boxSizing: "border-box" }}
            />
          </lineargradient>
          <lineargradient
            id="linear-gradient-3"
            gradientTransform="translate(0 -1034)"
            gradientUnits="userSpaceOnUse"
            x1="2.87"
            x2="40.19"
            y1="1047.56"
            y2="1047.56"
            style={{ boxSizing: "border-box" }}
          >
            <stop
              offset="0"
              stopColor="#d93025"
              style={{ boxSizing: "border-box" }}
            />
            <stop
              offset="1"
              stopColor="#ea4335"
              style={{ boxSizing: "border-box" }}
            />
          </lineargradient>
        </defs>
        <title style={{ boxSizing: "border-box" }}>icon chrome logo</title>
        <use
          xlinkHref="#color-google-logo-2023"
          style={{ boxSizing: "border-box" }}
        />
        <image
          className="svg-fallback"
          height="36"
          width="134"
          alt="Google Chrome"
          src="/chrome/static/images/fallback/chrome-logo-2023.png"
          style={{ boxSizing: "border-box", display: "none" }}
        />
      </svg>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
