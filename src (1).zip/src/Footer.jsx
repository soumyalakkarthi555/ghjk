import React from "react";

export default function Footer() {
  return (
    <>
      <footer
        id="js-footer"
        className="chr-footer chr-footer--jumplinks-mobile"
        style={{
          boxSizing: "border-box",
          margin: "0px",
          backgroundColor: "rgb(241, 243, 244)",
          display: "block",
        }}
      >
        <div
          className="chr-footer__social"
          style={{
            boxSizing: "border-box",
            margin: "0px auto",
            padding: "32px",
            maxWidth: "1440px",
          }}
        >
          <div
            className="chr-footer__social__container"
            style={{
              boxSizing: "border-box",
              display: "flex",
              gap: "32px",
              WebkitBoxAlign: "start",
              alignItems: "flex-start",
              alignSelf: "stretch",
              WebkitBoxOrient: "horizontal",
              WebkitBoxDirection: "normal",
              flexDirection: "row",
            }}
          >
            <h3
              className="chr-footer__social__title chr-headline-6"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                color: "rgb(32, 33, 36)",
                fontFamily: '"Google Sans", arial, sans-serif',
                fontSize: "1rem",
                lineHeight: "1.5rem",
                letterSpacing: "-0.00625rem",
                flex: "0 0 auto",
                WebkitBoxFlex: "0",
                fontWeight: 500,
                width: "auto",
              }}
            >
              {" "}
              Follow us
            </h3>
            <ul
              className="chr-footer__social__list"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                listStyle: "none",
                padding: "0px",
                gap: "32px",
                WebkitBoxAlign: "center",
                alignItems: "center",
                display: "flex",
              }}
            >
              <li
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  gap: "32px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                }}
              >
                <a
                  className="chr-footer__social-link"
                  href="https://www.youtube.com/user/googlechrome"
                  rel="noopener nofollow"
                  target="_blank"
                  title="YouTube"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    borderRadius: "50%",
                    color: "rgb(32, 33, 36)",
                    padding: "0px",
                    height: "24px",
                    width: "24px",
                  }}
                >
                  <svg
                    className="chr-icon chr-icon--24"
                    style={{
                      boxSizing: "border-box",
                      transition: "transform 0.2s, -webkit-transform 0.2s",
                      display: "inline-block",
                      fill: "currentcolor",
                      verticalAlign: "middle",
                      height: "24px",
                      width: "24px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }}>YouTube</title>
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#social-youtube"
                      style={{ boxSizing: "border-box" }}
                    />
                    <image
                      className="svg-fallback"
                      height="24"
                      width="24"
                      alt="YouTube"
                      src="/chrome/static/images/fallback/icon-youtube.jpg"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </a>
              </li>
              <li
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  gap: "32px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                }}
              >
                <a
                  className="chr-footer__social-link"
                  href="https://twitter.com/googlechrome"
                  rel="noopener nofollow"
                  target="_blank"
                  title="Twitter"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    borderRadius: "50%",
                    color: "rgb(32, 33, 36)",
                    padding: "0px",
                    height: "24px",
                    width: "24px",
                  }}
                >
                  <svg
                    className="chr-icon chr-icon--24"
                    style={{
                      boxSizing: "border-box",
                      transition: "transform 0.2s, -webkit-transform 0.2s",
                      display: "inline-block",
                      fill: "currentcolor",
                      verticalAlign: "middle",
                      height: "24px",
                      width: "24px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }}>Twitter</title>
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#social-twitter"
                      style={{ boxSizing: "border-box" }}
                    />
                    <image
                      className="svg-fallback"
                      height="24"
                      width="24"
                      alt="Twitter"
                      src="/chrome/static/images/fallback/icon-twitter.jpg"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </a>
              </li>
              <li
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  gap: "32px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                }}
              >
                <a
                  className="chr-footer__social-link"
                  href="https://www.facebook.com/googlechrome/"
                  rel="noopener nofollow"
                  target="_blank"
                  title="Facebook"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    borderRadius: "50%",
                    color: "rgb(32, 33, 36)",
                    padding: "0px",
                    height: "24px",
                    width: "24px",
                  }}
                >
                  <svg
                    className="chr-icon chr-icon--24"
                    style={{
                      boxSizing: "border-box",
                      transition: "transform 0.2s, -webkit-transform 0.2s",
                      display: "inline-block",
                      fill: "currentcolor",
                      verticalAlign: "middle",
                      height: "24px",
                      width: "24px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }}>Facebook</title>
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#social-facebook"
                      style={{ boxSizing: "border-box" }}
                    />
                    <image
                      className="svg-fallback"
                      height="24"
                      width="24"
                      alt="Facebook"
                      src="/chrome/static/images/fallback/icon-fb.jpg"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div
          className="chr-footer__links"
          style={{
            boxSizing: "border-box",
            borderTop: "1px solid rgb(218, 220, 224)",
            margin: "0px auto",
            borderBottom: "1px solid rgb(218, 220, 224)",
            width: "initial",
            padding: "40px 0px",
            maxWidth: "calc(1440px - 32px*2)",
          }}
        >
          <nav
            className="chr-footer__links__grid"
            style={{
              boxSizing: "border-box",
              gap: "8px",
              overflow: "hidden",
              display: "flex",
            }}
          >
            <div
              className="chr-footer__links__group"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                borderBottom: "0px",
                flex: "0 0 20%",
                padding: "0px",
                WebkitBoxFlex: "0",
                maxWidth: "20%",
                width: "20%",
              }}
            >
              <h4
                className="chr-headline-6 chr-footer__links__heading js-footer-link"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  display: "flex",
                  fontWeight: 500,
                  WebkitBoxPack: "justify",
                  justifyContent: "space-between",
                  position: "relative",
                  borderBottom: "0px solid rgb(218, 220, 224)",
                  outline: "0px",
                  cursor: "inherit",
                  paddingBottom: "24px",
                }}
              >
                {"Chrome Family"}
                <svg
                  className="chr-icon chr-icon--24"
                  role="img"
                  style={{
                    boxSizing: "border-box",
                    fill: "currentcolor",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    flex: "0 0 32px",
                    margin: "-5px 0 0 8px",
                    transition:
                      "transform 0.333s ease-in, -webkit-transform 0.333s ease-in",
                    color: "rgb(32, 33, 36)",
                    WebkitBoxFlex: "0",
                    transform: "rotate(0deg)",
                    verticalAlign: "middle",
                    display: "none",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </h4>
              <ul
                className="chr-footer__links__list"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  margin: "0px",
                  transition:
                    "max-height 0.4s ease-in-out, visibility 0.1s ease-out 0.1s",
                  maxHeight: "none",
                  visibility: "visible",
                }}
              >
                <li
                  className="chr-link chr-footer__links__list-item footer-other-platform"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingTop: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    id="js-other-platform"
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link js-download show"
                    href="https://www.google.com/chrome/index.html#"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Other Platforms"}
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                    paddingTop: "initial",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://www.google.com/intl/en_IN/chromebook/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chromebooks"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://www.google.com/chromecast/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chromecast"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item--hide"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "12px 0px",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "none",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://developer.chrome.com/webstore/?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Web"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Store"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
              </ul>
            </div>
            <div
              className="chr-footer__links__group"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                borderBottom: "0px",
                flex: "0 0 20%",
                padding: "0px",
                WebkitBoxFlex: "0",
                maxWidth: "20%",
                width: "20%",
              }}
            >
              <h4
                className="chr-headline-6 chr-footer__links__heading js-footer-link"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  display: "flex",
                  fontWeight: 500,
                  WebkitBoxPack: "justify",
                  justifyContent: "space-between",
                  position: "relative",
                  borderBottom: "0px solid rgb(218, 220, 224)",
                  outline: "0px",
                  cursor: "inherit",
                  paddingBottom: "24px",
                }}
              >
                {"Enterprise"}
                <svg
                  className="chr-icon chr-icon--24"
                  role="img"
                  style={{
                    boxSizing: "border-box",
                    fill: "currentcolor",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    flex: "0 0 32px",
                    margin: "-5px 0 0 8px",
                    transition:
                      "transform 0.333s ease-in, -webkit-transform 0.333s ease-in",
                    color: "rgb(32, 33, 36)",
                    WebkitBoxFlex: "0",
                    transform: "rotate(0deg)",
                    verticalAlign: "middle",
                    display: "none",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </h4>
              <ul
                className="chr-footer__links__list"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  margin: "0px",
                  transition:
                    "max-height 0.4s ease-in-out, visibility 0.1s ease-out 0.1s",
                  maxHeight: "none",
                  visibility: "visible",
                }}
              >
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingTop: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://chromeenterprise.google/intl/en_IN/browser/download/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Download Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Browser"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://chromeenterprise.google/intl/en_IN/browser/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Browser for"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Enterprise"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://chromeenterprise.google/intl/en_IN/devices/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Devices"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://chromeenterprise.google/intl/en_IN/os/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"ChromeOS"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://cloud.google.com/?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Google"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Cloud"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingBottom: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://gsuite.google.com/?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Google"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Workspace"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
              </ul>
            </div>
            <div
              className="chr-footer__links__group"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                borderBottom: "0px",
                flex: "0 0 20%",
                padding: "0px",
                WebkitBoxFlex: "0",
                maxWidth: "20%",
                width: "20%",
              }}
            >
              <h4
                className="chr-headline-6 chr-footer__links__heading js-footer-link"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  display: "flex",
                  fontWeight: 500,
                  WebkitBoxPack: "justify",
                  justifyContent: "space-between",
                  position: "relative",
                  borderBottom: "0px solid rgb(218, 220, 224)",
                  outline: "0px",
                  cursor: "inherit",
                  paddingBottom: "24px",
                }}
              >
                {"Education"}
                <svg
                  className="chr-icon chr-icon--24"
                  role="img"
                  style={{
                    boxSizing: "border-box",
                    fill: "currentcolor",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    flex: "0 0 32px",
                    margin: "-5px 0 0 8px",
                    transition:
                      "transform 0.333s ease-in, -webkit-transform 0.333s ease-in",
                    color: "rgb(32, 33, 36)",
                    WebkitBoxFlex: "0",
                    transform: "rotate(0deg)",
                    verticalAlign: "middle",
                    display: "none",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </h4>
              <ul
                className="chr-footer__links__list"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  margin: "0px",
                  transition:
                    "max-height 0.4s ease-in-out, visibility 0.1s ease-out 0.1s",
                  maxHeight: "none",
                  visibility: "visible",
                }}
              >
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingTop: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://edu.google.com/intl/en_IN/products/more-products/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Google Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Browser"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://edu.google.com/intl/en_IN/chromebooks/find-a-chromebook/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Devices"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingBottom: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://chrome.google.com/webstore/category/app/8-education?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Web"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Store"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
              </ul>
            </div>
            <div
              className="chr-footer__links__group"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                borderBottom: "0px",
                flex: "0 0 20%",
                padding: "0px",
                WebkitBoxFlex: "0",
                maxWidth: "20%",
                width: "20%",
              }}
            >
              <h4
                className="chr-headline-6 chr-footer__links__heading js-footer-link"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  display: "flex",
                  fontWeight: 500,
                  WebkitBoxPack: "justify",
                  justifyContent: "space-between",
                  position: "relative",
                  borderBottom: "0px solid rgb(218, 220, 224)",
                  outline: "0px",
                  cursor: "inherit",
                  paddingBottom: "24px",
                }}
              >
                {"Dev and Partners"}
                <svg
                  className="chr-icon chr-icon--24"
                  role="img"
                  style={{
                    boxSizing: "border-box",
                    fill: "currentcolor",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    flex: "0 0 32px",
                    margin: "-5px 0 0 8px",
                    transition:
                      "transform 0.333s ease-in, -webkit-transform 0.333s ease-in",
                    color: "rgb(32, 33, 36)",
                    WebkitBoxFlex: "0",
                    transform: "rotate(0deg)",
                    verticalAlign: "middle",
                    display: "none",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </h4>
              <ul
                className="chr-footer__links__list"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  margin: "0px",
                  transition:
                    "max-height 0.4s ease-in-out, visibility 0.1s ease-out 0.1s",
                  maxHeight: "none",
                  visibility: "visible",
                }}
              >
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingTop: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://www.chromium.org/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chromium"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://www.chromium.org/chromium-os"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"ChromeOS"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(95, 99, 104)",
                        display: "inline-block",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://developer.chrome.com/webstore/?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Web"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Store"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://www.chromeexperiments.com/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Experiments"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link"
                    href="https://www.google.com/intl/en_in/chrome/beta/"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Beta"}
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link"
                    href="https://www.google.com/intl/en_in/chrome/dev/"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Dev"}
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingBottom: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link"
                    href="https://www.google.com/intl/en_in/chrome/canary/"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Canary"}
                  </a>
                </li>
              </ul>
            </div>
            <div
              className="chr-footer__links__group"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                borderBottom: "0px",
                flex: "0 0 20%",
                padding: "0px",
                WebkitBoxFlex: "0",
                maxWidth: "20%",
                width: "20%",
              }}
            >
              <h4
                className="chr-headline-6 chr-footer__links__heading js-footer-link"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  display: "flex",
                  fontWeight: 500,
                  WebkitBoxPack: "justify",
                  justifyContent: "space-between",
                  position: "relative",
                  borderBottom: "0px solid rgb(218, 220, 224)",
                  outline: "0px",
                  cursor: "inherit",
                  paddingBottom: "24px",
                }}
              >
                {"Stay Connected"}
                <svg
                  className="chr-icon chr-icon--24"
                  role="img"
                  style={{
                    boxSizing: "border-box",
                    fill: "currentcolor",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    flex: "0 0 32px",
                    margin: "-5px 0 0 8px",
                    transition:
                      "transform 0.333s ease-in, -webkit-transform 0.333s ease-in",
                    color: "rgb(32, 33, 36)",
                    WebkitBoxFlex: "0",
                    transform: "rotate(0deg)",
                    verticalAlign: "middle",
                    display: "none",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </h4>
              <ul
                className="chr-footer__links__list"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  margin: "0px",
                  transition:
                    "max-height 0.4s ease-in-out, visibility 0.1s ease-out 0.1s",
                  maxHeight: "none",
                  visibility: "visible",
                }}
              >
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingTop: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://support.google.com/chrome/?hl=en-GB&rd=3#topic=7438008"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Help"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://blog.google/products/chrome/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Google Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Blog"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link"
                    href="https://www.google.com/intl/en_in/chrome/update/"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Update Chrome"}
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://support.google.com/chrome/?hl=en-GB&rd=3#topic=7438008"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Help"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--internal chr-footer__link"
                    href="https://www.google.com/intl/en_in/chrome/tips/"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Chrome Tips"}
                  </a>
                </li>
                <li
                  className="chr-link chr-footer__links__list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    fontSize: "1rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    display: "block",
                    lineHeight: "24px",
                    padding: "initial",
                    paddingBottom: "initial",
                    overflow: "initial",
                    maxWidth: "100%",
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://blog.google/products/chrome/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      outlineWidth: "6px",
                      width: "100%",
                      padding: "8px 0",
                    }}
                  >
                    {"Google Chrome"}
                    <span
                      className="chr-link-icon"
                      style={{
                        boxSizing: "border-box",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        display: "inline-flex",
                        flexWrap: "nowrap",
                        fill: "rgb(95, 99, 104)",
                      }}
                    >
                      {"Blog"}
                      <svg
                        className="chr-link__icon"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          transition:
                            "transform 0.1s linear, -webkit-transform 0.1s linear",
                          height: "16px",
                          marginLeft: "6px",
                          verticalAlign: "middle",
                          width: "16px",
                          fill: "rgb(95, 99, 104)",
                          display: "inline-block",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </nav>
        </div>
        <div
          className="chr-footer__bottom"
          style={{
            boxSizing: "border-box",
            margin: "0px auto",
            alignSelf: "stretch",
            display: "flex",
            maxWidth: "1440px",
            gap: "32px",
            padding: "32px 32px 64px",
            flexFlow: "wrap",
            WebkitBoxOrient: "horizontal",
            WebkitBoxDirection: "normal",
            WebkitBoxPack: "justify",
            justifyContent: "space-between",
          }}
        >
          <div
            className="chr-footer__glinks-wrapper"
            style={{
              boxSizing: "border-box",
              display: "flex",
              gap: "48px",
              WebkitBoxAlign: "center",
              alignItems: "center",
              WebkitBoxOrient: "horizontal",
              WebkitBoxDirection: "normal",
              flexDirection: "row",
            }}
          >
            <div
              className="chr-footer__logo"
              style={{ boxSizing: "border-box", height: "28px", width: "86px" }}
            >
              <a
                href="https://www.google.com/"
                rel="noopener"
                target="_blank"
                title="Google"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                }}
              >
                <svg
                  className="chr-footer__logo-img"
                  style={{
                    boxSizing: "border-box",
                    fill: "rgb(95, 99, 104)",
                    height: "28px",
                    width: "86px",
                    overflow: "hidden",
                  }}
                >
                  <title style={{ boxSizing: "border-box" }}>Google</title>
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#google-logo"
                    style={{ boxSizing: "border-box" }}
                  />
                  <image
                    className="svg-fallback"
                    height="28"
                    width="86"
                    alt="Google logo"
                    src="/chrome/static/images/fallback/google-footer-logo.jpg"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </a>
            </div>
            <nav
              className="chr-footer__glinks"
              style={{
                boxSizing: "border-box",
                gap: "16px",
                WebkitBoxAlign: "start",
                alignItems: "flex-start",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
              }}
            >
              <ul
                className="chr-footer__glinks-list"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  listStyle: "none",
                  padding: "0px",
                  flexFlow: "wrap",
                  gap: "24px",
                  display: "flex",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "normal",
                }}
              >
                <li
                  className="chr-footer__glinks-list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    display: "inline-block",
                    fontWeight: 500,
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://policies.google.com/privacy?hl=en-GB"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      width: "100%",
                      padding: "0px",
                    }}
                  >
                    {"Privacy and Terms"}
                  </a>
                </li>
                <li
                  className="chr-footer__glinks-list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    display: "inline-block",
                    fontWeight: 500,
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://about.google/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      width: "100%",
                      padding: "0px",
                    }}
                  >
                    {"About Google"}
                  </a>
                </li>
                <li
                  className="chr-footer__glinks-list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    display: "inline-block",
                    fontWeight: 500,
                  }}
                >
                  <a
                    className="chr-link chr-link--primary chr-link--external chr-footer__link"
                    href="https://about.google/products/"
                    rel="noopener"
                    target="_blank"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      fontWeight: 500,
                      color: "rgb(95, 99, 104)",
                      display: "inline-block",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      width: "100%",
                      padding: "0px",
                    }}
                  >
                    {"Google products"}
                  </a>
                </li>
                <li
                  className="chr-footer-glinks-list-item"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                  }}
                >
                  <button
                    className="glue-cookie-notification-bar-control chr-footer__link chr-footer__link--management"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      appearance: "button",
                      background: "none",
                      border: "none",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      margin: "0px",
                      padding: "0px",
                      fontWeight: 500,
                      height: "100%",
                      display: "none",
                    }}
                  >
                    {"Cookies management controls"}
                  </button>
                </li>
              </ul>
            </nav>
          </div>
          <ul
            className="chr-footer__help-language"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              listStyle: "none",
              padding: "0px",
              alignSelf: "stretch",
              display: "flex",
              gap: "32px",
              WebkitBoxOrient: "horizontal",
              WebkitBoxDirection: "normal",
              flexDirection: "row",
              WebkitBoxAlign: "center",
              alignItems: "center",
            }}
          >
            <li
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px",
              }}
            >
              <a
                className="chr-footer__link chr-link--nav"
                href="https://support.google.com/chrome/?hl=en-GB&rd=3#topic=7438008"
                rel="noopener"
                target="_blank"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  color: "rgb(95, 99, 104)",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  gap: "12px",
                  WebkitBoxAlign: "start",
                  alignItems: "flex-start",
                  display: "flex",
                  fontWeight: 500,
                  lineHeight: "24px",
                }}
              >
                <svg
                  className="chr-icon chr-icon--24"
                  style={{
                    boxSizing: "border-box",
                    transition: "transform 0.2s, -webkit-transform 0.2s",
                    display: "inline-block",
                    fill: "currentcolor",
                    verticalAlign: "middle",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    margin: "0px",
                    color: "rgb(95, 99, 104)",
                  }}
                >
                  <title style={{ boxSizing: "border-box" }}>Help</title>
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#mi-help"
                    style={{ boxSizing: "border-box" }}
                  />
                  <image
                    className="svg-fallback"
                    height="21"
                    width="20"
                    alt="Help"
                    src="/chrome/static/images/fallback/icon-help.jpg"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
                Help
              </a>
            </li>
            <li
              className="chr-footer__language-dropdown"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px",
                paddingLeft: "0px",
                paddingRight: "0px",
              }}
            >
              <label
                htmlFor="language-selector"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  clip: "rect(1px, 1px, 1px, 1px)",
                  height: "1px",
                  paddingBottom: "8px",
                  position: "absolute",
                  width: "1px",
                }}
              >
                Change language or region
              </label>
              <select
                id="language-selector"
                className="chr-headline-6 chr-footer__language-dropdown__select js-footer-language-select"
                defaultValue="/intl/en_in/chrome/"
                style={{
                  textTransform: "none",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "-0.00625rem",
                  borderBottom: "1px solid rgb(218, 220, 224)",
                  backgroundPosition: "right 50%",
                  borderLeft: "none",
                  borderRadius: "0px",
                  borderRight: "none",
                  borderTop: "none",
                  margin: "0px",
                  padding: "0 24px 0 2px",
                  whiteSpace: "pre-wrap",
                  backgroundColor: "rgb(241, 243, 244)",
                  color: "rgb(95, 99, 104)",
                  fill: "rgb(95, 99, 104)",
                  appearance: "none",
                  backgroundImage:
                    'url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGcgaWQ9ImFycm93X2Ryb3BfZG93biI+CjxwYXRoIGlkPSJWZWN0b3IiIGQ9Ik03IDkuNTAwMjRMMTIgMTQuNTAwMkwxNyA5LjUwMDI0SDdaIiBmaWxsPSIjNUY2MzY4Ii8+CjwvZz4KPC9zdmc+Cg==")',
                  backgroundRepeat: "no-repeat",
                  boxSizing: "border-box",
                  display: "inline-block",
                  fontWeight: 500,
                  height: "22px",
                  textOverflow: "ellipsis",
                  width: "100%",
                }}
              >
                <option
                  value="/intl/ca/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Català - Espanya"}
                </option>
                <option
                  value="/intl/da/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Dansk - Danmark"}
                </option>
                <option
                  value="/intl/de/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Deutsch - Deutschland"}
                </option>
                <option
                  value="/intl/et/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Eesti - Eesti"}
                </option>
                <option
                  value="/intl/en_au/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Australia"}
                </option>
                <option
                  value="/intl/en_ca/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Canada"}
                </option>
                <option
                  value="/intl/en_uk/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - United Kingdom"}
                </option>
                <option
                  value="/intl/en_hk/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Hong Kong SAR China"}
                </option>
                <option
                  value="/intl/en_ie/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Ireland"}
                </option>
                <option
                  value="/intl/en_in/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - India"}
                </option>
                <option
                  value="/intl/en_ph/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Philippines"}
                </option>
                <option
                  value="/intl/en_pk/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Pakistan"}
                </option>
                <option
                  value="/intl/en_sg/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - Singapore"}
                </option>
                <option
                  value="/intl/en_us/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"English - United States"}
                </option>
                <option
                  value="/intl/es-419/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Español - Latinoamérica"}
                </option>
                <option
                  value="/intl/es_es/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Español - España"}
                </option>
                <option
                  value="/intl/es_us/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Español - Estados Unidos"}
                </option>
                <option
                  value="/intl/fil/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Filipino - Pilipinas"}
                </option>
                <option
                  value="/intl/fr_ca/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Français - Canada"}
                </option>
                <option
                  value="/intl/fr/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Français - France"}
                </option>
                <option
                  value="/intl/hr/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Hrvatski - Hrvatska"}
                </option>
                <option
                  value="/intl/id/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Indonesia - Indonesia"}
                </option>
                <option
                  value="/intl/it/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Italiano - Italia"}
                </option>
                <option
                  value="/intl/lv/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Latviešu - Latvija"}
                </option>
                <option
                  value="/intl/lt/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Lietuvių - Lietuva"}
                </option>
                <option
                  value="/intl/hu/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Magyar - Magyarország"}
                </option>
                <option
                  value="/intl/ms/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Melayu - Malaysia"}
                </option>
                <option
                  value="/intl/nl/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Nederlands - Nederland"}
                </option>
                <option
                  value="/intl/no/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Norsk Bokmål - Norge"}
                </option>
                <option
                  value="/intl/pl/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Polski - Polska"}
                </option>
                <option
                  value="/intl/pt-PT/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Português - Portugal"}
                </option>
                <option
                  value="/intl/pt-BR/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Português - Brasil"}
                </option>
                <option
                  value="/intl/ro/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Română - România"}
                </option>
                <option
                  value="/intl/sk/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Slovenčina - Slovensko"}
                </option>
                <option
                  value="/intl/sl/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Slovenščina - Slovenija"}
                </option>
                <option
                  value="/intl/fi/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Suomi - Suomi"}
                </option>
                <option
                  value="/intl/sv/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Svenska - Sverige"}
                </option>
                <option
                  value="/intl/vi/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Tiếng Việt - Việt Nam"}
                </option>
                <option
                  value="/intl/tr/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Türkçe - Türkiye"}
                </option>
                <option
                  value="/intl/cs/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Čeština - Česko"}
                </option>
                <option
                  value="/intl/el/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Ελληνικά - Ελλάδα"}
                </option>
                <option
                  value="/intl/bg/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Български - България"}
                </option>
                <option
                  value="/intl/ru/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Русский - Россия"}
                </option>
                <option
                  value="/intl/sr/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Српски - Србија"}
                </option>
                <option
                  value="/intl/uk/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"Українська - Україна"}
                </option>
                <option
                  value="/intl/iw/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"עברית"}
                </option>
                <option
                  value="/intl/ar/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"العربية - المملكة العربية السعودية"}
                </option>
                <option
                  value="/intl/fa/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"فارسی"}
                </option>
                <option
                  value="/intl/hi/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"हिन्दी - भारत"}
                </option>
                <option
                  value="/intl/th/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"ไทย - ไทย"}
                </option>
                <option
                  value="/intl/zh-CN/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"中文 - 中国"}
                </option>
                <option
                  value="/intl/zh-HK/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"中文 - 中国香港特别行政区"}
                </option>
                <option
                  value="/intl/zh-TW/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"中文 - 台灣"}
                </option>
                <option
                  value="/intl/ja/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"日本語 - 日本"}
                </option>
                <option
                  value="/intl/ko/chrome/"
                  style={{ boxSizing: "border-box" }}
                >
                  {"한국어 - 대한민국"}
                </option>
              </select>
            </li>
          </ul>
        </div>
        <div
          className="chr-footer__jumplinks-mobile-container"
          style={{
            boxSizing: "border-box",
            width: "100%",
            height: "0px",
            marginTop: "-12px",
            display: "none",
            visibility: "hidden",
          }}
        />
        <div
          className="chr-footer__glue-cookie-banner"
          style={{
            boxSizing: "border-box",
            transition: "height 0.4s ease-in-out",
            height: "0",
          }}
        />
      </footer>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
