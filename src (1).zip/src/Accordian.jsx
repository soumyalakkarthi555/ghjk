import React from "react";

export default function Accordian() {
  return (
    <>
      <div
        className="chr-grid-default"
        style={{
          boxSizing: "border-box",
          display: "grid",
          columnGap: "64px",
          gridTemplateColumns: "repeat(12, 1fr)",
        }}
      >
        <div
          className="chr-static-carousel__controls chr-carousel__controls"
          style={{
            boxSizing: "border-box",
            gap: "16px",
            gridColumn: "2 / span 10",
            display: "flex",
            WebkitBoxOrient: "horizontal",
            WebkitBoxDirection: "normal",
            flexDirection: "row",
            marginTop: "40px",
            transition: "opacity 0.2s",
            opacity: 1,
          }}
        >
          <button
            className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--prev chr-carousel__control-btn--prev"
            aria-controls="fast-scrollable-carousel"
            aria-hidden="true"
            tabIndex="-1"
            title="Previous card"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              fontSize: "100%",
              lineHeight: 1.15,
              overflow: "visible",
              textTransform: "none",
              appearance: "button",
              background: "none",
              border: "none",
              fontFamily: "inherit",
              borderRadius: "50%",
              WebkitBoxAlign: "center",
              alignItems: "center",
              cursor: "pointer",
              display: "flex",
              WebkitBoxPack: "center",
              justifyContent: "center",
              height: "56px",
              width: "56px",
              backgroundColor: "rgb(232, 240, 254)",
              transition: "unset",
              transform: "rotateZ(180deg)",
            }}
          >
            <svg
              className="chr-action-icon__icon"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                overflow: "hidden",
                height: "32px",
                width: "32px",
                fill: "rgb(25, 103, 210)",
              }}
            >
              <use
                xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                style={{ boxSizing: "border-box" }}
              />
            </svg>
          </button>
          <button
            className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--next chr-carousel__control-btn--next"
            aria-controls="fast-scrollable-carousel"
            aria-hidden="true"
            disabled
            tabIndex="-1"
            title="Next card"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              fontSize: "100%",
              lineHeight: 1.15,
              overflow: "visible",
              textTransform: "none",
              appearance: "button",
              background: "none",
              border: "none",
              fontFamily: "inherit",
              borderRadius: "50%",
              transition:
                "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
              WebkitBoxAlign: "center",
              alignItems: "center",
              cursor: "pointer",
              display: "flex",
              WebkitBoxPack: "center",
              justifyContent: "center",
              transform: "scale(1)",
              height: "56px",
              width: "56px",
              backgroundColor: "rgb(241, 243, 244)",
            }}
          >
            <svg
              className="chr-action-icon__icon"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                transition:
                  "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                overflow: "hidden",
                height: "32px",
                width: "32px",
                fill: "rgb(128, 134, 139)",
              }}
            >
              <use
                xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                style={{ boxSizing: "border-box" }}
              />
            </svg>
          </button>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
