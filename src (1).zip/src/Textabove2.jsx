import React from "react";

export default function Textabove2() {
  return (
    <>
      <section
        id="yours"
        className="chr-section js-section spacer-05"
        style={{ boxSizing: "border-box", display: "block", padding: "40px 0" }}
      >
        <div
          className="chr-pill-section-title chr-show-only-in-mobile"
          style={{
            boxSizing: "border-box",
            display: "none",
            visibility: "hidden",
            margin: "auto",
            padding: "40px",
            textAlign: "center",
            paddingInline: "0px",
            maxWidth: "840px",
          }}
        >
          <h2
            className="chr-headline-1"
            aria-label="Make it yours and take it with you"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              color: "rgb(32, 33, 36)",
              fontFamily: '"Google Sans", arial, sans-serif',
              fontWeight: 700,
              fontSize: "3.75rem",
              lineHeight: "4.5rem",
              letterSpacing: "-0.078125rem",
            }}
          >
            {"Make it"}
            <span
              className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--red chr-heading-pill__pill-container--medium"
              aria-hidden="true"
              style={{
                boxSizing: "border-box",
                overflow: "hidden",
                position: "relative",
                textAlign: "center",
                borderRadius: "48px",
                display: "inline-flex",
                WebkitBoxOrient: "horizontal",
                WebkitBoxDirection: "normal",
                flexDirection: "row",
                backgroundColor: "rgb(241, 243, 244)",
                color: "rgb(95, 99, 104)",
                WebkitBoxAlign: "center",
                alignItems: "center",
                transform: "none",
                lineHeight: "4.5rem",
              }}
            >
              <span
                className="chr-heading-pill__mock"
                style={{ boxSizing: "border-box", height: "40px" }}
              />
              <div
                className="chr-lottie-animation chr-heading-pill__icon"
                style={{
                  boxSizing: "border-box",
                  display: "inline-flex",
                  flexShrink: 0,
                  marginLeft: "8px",
                  height: "72px",
                  width: "72px",
                }}
              >
                <svg
                  height="72"
                  width="72"
                  preserveAspectRatio="xMidYMid meet"
                  viewBox="0 0 72 72"
                  xmlns="http://www.w3.org/2000/svg"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    width: "100%",
                    height: "100%",
                    transform: "translate3d(0px, 0px, 0px)",
                  }}
                >
                  <defs style={{ boxSizing: "border-box" }}>
                    <clippath
                      id="__lottie_element_63"
                      style={{ boxSizing: "border-box" }}
                    >
                      <rect
                        height="72"
                        width="72"
                        x="0"
                        y="0"
                        style={{ boxSizing: "border-box" }}
                      />
                    </clippath>
                  </defs>
                  <g
                    clipPath="url(#__lottie_element_63)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <g
                      opacity="1"
                      transform="matrix(1,0,0,1,33,4.184999942779541)"
                      style={{ boxSizing: "border-box", display: "block" }}
                    >
                      <g
                        opacity="1"
                        transform="matrix(1,0,0,1,0,0)"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d=" M-12,-5.010000228881836 C-12,-5.010000228881836 12,-5.010000228881836 12,-5.010000228881836 C12,-5.010000228881836 12,17.5 12,17.5 C12,17.5 -12,17.5 -12,17.5 C-12,17.5 -12,-5.010000228881836 -12,-5.010000228881836z"
                          fill="rgb(246,174,169)"
                          fillOpacity="1"
                          style={{ boxSizing: "border-box" }}
                        />
                      </g>
                    </g>
                    <g
                      opacity="1"
                      transform="matrix(1,0,0,1,36,33.75)"
                      style={{ boxSizing: "border-box", display: "block" }}
                    >
                      <g
                        opacity="1"
                        transform="matrix(1,0,0,1,0,0)"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d=" M11,-16 C11,-16 11,-18 11,-18 C11,-19.100000381469727 10.100000381469727,-20 9,-20 C9,-20 -15,-20 -15,-20 C-16.100000381469727,-20 -17,-19.100000381469727 -17,-18 C-17,-18 -17,-10 -17,-10 C-17,-8.899999618530273 -16.100000381469727,-8 -15,-8 C-15,-8 9,-8 9,-8 C10.100000381469727,-8 11,-8.899999618530273 11,-10 C11,-10 11,-12 11,-12 C11,-12 13,-12 13,-12 C13,-12 13,-4 13,-4 C13,-4 -5,-4 -5,-4 C-6.099999904632568,-4 -7,-3.0999999046325684 -7,-2 C-7,-2 -7,18 -7,18 C-7,19.100000381469727 -6.099999904632568,20 -5,20 C-5,20 -1,20 -1,20 C0.10000000149011612,20 1,19.100000381469727 1,18 C1,18 1,0 1,0 C1,0 15,0 15,0 C16.100000381469727,0 17,-0.8999999761581421 17,-2 C17,-2 17,-14 17,-14 C17,-15.100000381469727 16.100000381469727,-16 15,-16 C15,-16 11,-16 11,-16z"
                          fill="rgb(234,67,53)"
                          fillOpacity="1"
                          style={{ boxSizing: "border-box" }}
                        />
                      </g>
                    </g>
                  </g>
                </svg>
              </div>
              <span
                className="chr-heading-pill__pill-text"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                  display: "inline-flex",
                  maxHeight: "4.5rem",
                  fontSize: "3.25rem",
                  paddingRight: "32px",
                }}
              >
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    visibility: "hidden",
                  }}
                >
                  {"y"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    visibility: "hidden",
                  }}
                >
                  {"o"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    visibility: "hidden",
                  }}
                >
                  {"u"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    visibility: "hidden",
                  }}
                >
                  {"r"}
                </span>
                <span
                  className="chr-heading-pill__pill-char"
                  style={{
                    boxSizing: "border-box",
                    fontWeight: 500,
                    visibility: "hidden",
                  }}
                >
                  {"s"}
                </span>
              </span>
            </span>
            {"and take it with you"}
          </h2>
        </div>
        <div
          className="chr-take-over-animation"
          style={{
            boxSizing: "border-box",
            height: "230vh",
            marginBottom: "80px",
            position: "relative",
            width: "100%",
            display: "block",
            paddingBottom: "-5.08937499999999px",
          }}
        >
          <div
            className="chr-take-over-animation__wrapper chr-grid-default-parent"
            style={{
              boxSizing: "border-box",
              margin: "auto",
              padding: "0px 74px",
              maxWidth: "1440px",
              height: "100%",
              position: "relative",
            }}
          >
            <div
              className="chr-grid-default chr-take-over-animation__container"
              style={{
                boxSizing: "border-box",
                display: "grid",
                columnGap: "64px",
                gridTemplateColumns: "repeat(12, 1fr)",
                padding: "80px 80px 0 80px",
                height: "auto",
                position: "sticky",
                rowGap: "80px",
                top: "calc(219px*-1)",
              }}
            >
              <div
                className="chr-take-over-animation__title"
                style={{
                  boxSizing: "border-box",
                  gridColumn: "3 / span 8",
                  fontWeight: 700,
                  opacity: 0.41814159292035413,
                  position: "relative",
                  textAlign: "center",
                  transform: "translate(0, 347.5px) scale(0.12463162852599552)",
                }}
              >
                <h2
                  className="chr-headline-1"
                  aria-label="Make it yours and take it with you"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    color: "rgb(32, 33, 36)",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 700,
                    fontSize: "3.75rem",
                    lineHeight: "4.5rem",
                    letterSpacing: "-0.078125rem",
                  }}
                >
                  {"Make it"}
                  <span
                    className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--red chr-heading-pill__pill-container--medium animated"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      position: "relative",
                      textAlign: "center",
                      borderRadius: "48px",
                      display: "inline-flex",
                      WebkitBoxOrient: "horizontal",
                      WebkitBoxDirection: "normal",
                      flexDirection: "row",
                      backgroundColor: "rgb(241, 243, 244)",
                      color: "rgb(95, 99, 104)",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      transform: "none",
                      animationFillMode: "both",
                      animationTimingFunction: "ease-in-out",
                      animationDelay: "1.5s",
                      animationDuration: "200ms",
                      animationName: "redColorChange",
                      lineHeight: "4.5rem",
                    }}
                  >
                    <span
                      className="chr-heading-pill__mock"
                      style={{ boxSizing: "border-box", height: "40px" }}
                    />
                    <div
                      className="chr-lottie-animation chr-heading-pill__icon"
                      style={{
                        boxSizing: "border-box",
                        display: "inline-flex",
                        flexShrink: 0,
                        marginLeft: "8px",
                        height: "72px",
                        width: "72px",
                      }}
                    >
                      <svg
                        height="72"
                        width="72"
                        preserveAspectRatio="xMidYMid meet"
                        viewBox="0 0 72 72"
                        xmlns="http://www.w3.org/2000/svg"
                        style={{
                          boxSizing: "border-box",
                          overflow: "hidden",
                          width: "100%",
                          height: "100%",
                          transform: "translate3d(0px, 0px, 0px)",
                        }}
                      >
                        <defs style={{ boxSizing: "border-box" }}>
                          <clippath
                            id="__lottie_element_70"
                            style={{ boxSizing: "border-box" }}
                          >
                            <rect
                              height="72"
                              width="72"
                              x="0"
                              y="0"
                              style={{ boxSizing: "border-box" }}
                            />
                          </clippath>
                        </defs>
                        <g
                          clipPath="url(#__lottie_element_70)"
                          style={{ boxSizing: "border-box" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,33,4.184999942779541)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-12,-5.010000228881836 C-12,-5.010000228881836 12,-5.010000228881836 12,-5.010000228881836 C12,-5.010000228881836 12,17.5 12,17.5 C12,17.5 -12,17.5 -12,17.5 C-12,17.5 -12,-5.010000228881836 -12,-5.010000228881836z"
                                fill="rgb(246,174,169)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,36,33.75)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M11,-16 C11,-16 11,-18 11,-18 C11,-19.100000381469727 10.100000381469727,-20 9,-20 C9,-20 -15,-20 -15,-20 C-16.100000381469727,-20 -17,-19.100000381469727 -17,-18 C-17,-18 -17,-10 -17,-10 C-17,-8.899999618530273 -16.100000381469727,-8 -15,-8 C-15,-8 9,-8 9,-8 C10.100000381469727,-8 11,-8.899999618530273 11,-10 C11,-10 11,-12 11,-12 C11,-12 13,-12 13,-12 C13,-12 13,-4 13,-4 C13,-4 -5,-4 -5,-4 C-6.099999904632568,-4 -7,-3.0999999046325684 -7,-2 C-7,-2 -7,18 -7,18 C-7,19.100000381469727 -6.099999904632568,20 -5,20 C-5,20 -1,20 -1,20 C0.10000000149011612,20 1,19.100000381469727 1,18 C1,18 1,0 1,0 C1,0 15,0 15,0 C16.100000381469727,0 17,-0.8999999761581421 17,-2 C17,-2 17,-14 17,-14 C17,-15.100000381469727 16.100000381469727,-16 15,-16 C15,-16 11,-16 11,-16z"
                                fill="rgb(234,67,53)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </g>
                      </svg>
                    </div>
                    <span
                      className="chr-heading-pill__pill-text"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        display: "inline-flex",
                        maxHeight: "4.5rem",
                        fontSize: "3.25rem",
                        paddingRight: "32px",
                      }}
                    >
                      <span
                        className="chr-heading-pill__pill-char"
                        style={{
                          boxSizing: "border-box",
                          fontWeight: 500,
                          animationDelay: "20ms",
                          animationDuration: ".7s",
                          animationFillMode: "both",
                          animationName: "charBounceSlideInUp",
                          animationTimingFunction: "ease-in-out",
                          visibility: "visible",
                        }}
                      >
                        {"y"}
                      </span>
                      <span
                        className="chr-heading-pill__pill-char"
                        style={{
                          boxSizing: "border-box",
                          fontWeight: 500,
                          animationDelay: "40ms",
                          animationDuration: ".7s",
                          animationFillMode: "both",
                          animationName: "charBounceSlideInUp",
                          animationTimingFunction: "ease-in-out",
                          visibility: "visible",
                        }}
                      >
                        {"o"}
                      </span>
                      <span
                        className="chr-heading-pill__pill-char"
                        style={{
                          boxSizing: "border-box",
                          fontWeight: 500,
                          animationDelay: "60ms",
                          animationDuration: ".7s",
                          animationFillMode: "both",
                          animationName: "charBounceSlideInUp",
                          animationTimingFunction: "ease-in-out",
                          visibility: "visible",
                        }}
                      >
                        {"u"}
                      </span>
                      <span
                        className="chr-heading-pill__pill-char"
                        style={{
                          boxSizing: "border-box",
                          fontWeight: 500,
                          animationDelay: "80ms",
                          animationDuration: ".7s",
                          animationFillMode: "both",
                          animationName: "charBounceSlideInUp",
                          animationTimingFunction: "ease-in-out",
                          visibility: "visible",
                        }}
                      >
                        {"r"}
                      </span>
                      <span
                        className="chr-heading-pill__pill-char"
                        style={{
                          boxSizing: "border-box",
                          fontWeight: 500,
                          animationDelay: "100ms",
                          animationDuration: ".7s",
                          animationFillMode: "both",
                          animationName: "charBounceSlideInUp",
                          animationTimingFunction: "ease-in-out",
                          visibility: "visible",
                        }}
                      >
                        {"s"}
                      </span>
                    </span>
                  </span>
                  {"and take it with you"}
                </h2>
              </div>
              <div
                className="chr-take-over-animation__mask"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "0px",
                  gridColumn: "2 / span 10",
                  overflow: "clip",
                  aspectRatio: "16 / 9",
                  position: "relative",
                  transform: "scale(1.3238095238095238)",
                  width: "100%",
                  willChange: "contents",
                  zIndex: 10,
                }}
              >
                <div
                  className="chr-take-over-animation__take-over"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    left: "0px",
                    top: "0px",
                    height: "calc((1 - 1)*100%)",
                    position: "relative",
                    zIndex: 2,
                  }}
                >
                  <img
                    className="chr-take-over-animation__image"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-arches.webp"
                    srcSet="/chrome/static/images/v2/yours-take-over/theme-arches.webp, /chrome/static/images/v2/yours-take-over/theme-arches-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-take-over-animation__take-over-v2"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    left: "0px",
                    position: "absolute",
                    top: "0px",
                    height: "calc((1 - 1)*100%)",
                    zIndex: 1,
                  }}
                >
                  <img
                    className="chr-take-over-animation__image"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-ui-1.webp"
                    srcSet="/chrome/static/images/v2/yours-take-over/theme-ui-1.webp, /chrome/static/images/v2/yours-take-over/theme-ui-1-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-take-over-animation__take-over-v3"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    left: "0px",
                    position: "absolute",
                    top: "0px",
                    zIndex: 0,
                  }}
                >
                  <img
                    className="chr-take-over-animation__image chr-take-over-animation__image--border"
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/v2/yours-take-over/theme-ui-2.webp"
                    srcSet="/chrome/static/images/v2/yours-take-over/theme-ui-2.webp, /chrome/static/images/v2/yours-take-over/theme-ui-2-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      width: "100%",
                      border: "2px solid rgb(255, 255, 255)",
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="chr-accordion-timed chr-grid-default-parent"
          style={{
            boxSizing: "border-box",
            margin: "auto",
            padding: "0px 74px",
            maxWidth: "1440px",
          }}
        >
          <div
            className="chr-accordion-timed__container chr-grid-default"
            style={{
              boxSizing: "border-box",
              display: "grid",
              columnGap: "64px",
              gridTemplateColumns: "repeat(12, 1fr)",
              paddingBlock: "40px",
              WebkitBoxAlign: "center",
              alignItems: "center",
            }}
          >
            <div
              className="chr-accordion-timed__panel-wrapper"
              style={{
                boxSizing: "border-box",
                gridArea: "1 / 1 / auto / span 6",
                WebkitBoxAlign: "center",
                alignItems: "center",
                aspectRatio: "1 / 1",
                display: "flex",
                position: "relative",
              }}
            >
              <div
                id="chr-accordion-timed__panel-customize-chrome"
                className="chr-accordion-timed__panel chr-accordion-timed__panel--active chr-accordion-timed__panel--active-init"
                aria-hidden="false"
                role="region"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "24px",
                  overflow: "hidden",
                  aspectRatio: "1 / 1",
                  opacity: 0,
                  position: "absolute",
                  animation: "auto ease 0s 1 normal none running none",
                  animationDuration: "",
                  animationTimingFunction: "",
                  animationDelay: "",
                  animationIterationCount: "",
                  animationDirection: "",
                  animationPlayState: "",
                  animationName: "",
                  animationTimeline: "",
                  animationRangeStart: "",
                  animationRangeEnd: "",
                  animationFillMode: "forwards",
                  willChange: "opacity",
                }}
              >
                <video
                  aria-hidden="true"
                  autoPlay
                  muted
                  poster="/chrome/static/images/v2/accordion-timed/themes-poster.webp"
                  preload="none"
                  style={{
                    boxSizing: "border-box",
                    display: "block",
                    aspectRatio: "1 / 1",
                    height: "100%",
                    width: "100%",
                  }}
                >
                  <source
                    type="video/webm"
                    src="https://www.google.com/chrome/static/videos/v2/accordion-timed/themes.webm"
                    style={{ boxSizing: "border-box" }}
                  />
                  <source
                    type="video/mp4"
                    src="https://www.google.com/chrome/static/videos/v2/accordion-timed/themes.mp4"
                    style={{ boxSizing: "border-box" }}
                  />
                </video>
                <img
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    aspectRatio: "1 / 1",
                    height: "100%",
                    width: "100%",
                    display: "none",
                  }}
                />
              </div>
              <div
                id="chr-accordion-timed__panel-browse-devices"
                className="chr-accordion-timed__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "24px",
                  overflow: "hidden",
                  aspectRatio: "1 / 1",
                  opacity: 0,
                  position: "absolute",
                }}
              >
                <img
                  height={614}
                  width={614}
                  alt="A mobile browser loads tabs from a desktop browser, including Google Maps and NYC parking info."
                  src="https://www.google.com/chrome/static/images/v2/accordion-timed/tab-sync.webp"
                  srcSet="/chrome/static/images/v2/accordion-timed/tab-sync.webp, /chrome/static/images/v2/accordion-timed/tab-sync-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    aspectRatio: "1 / 1",
                    height: "100%",
                    width: "100%",
                  }}
                />
              </div>
              <div
                id="chr-accordion-timed__panel-save-time"
                className="chr-accordion-timed__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  borderRadius: "24px",
                  overflow: "hidden",
                  aspectRatio: "1 / 1",
                  opacity: 0,
                  position: "absolute",
                }}
              >
                <img
                  height={614}
                  width={614}
                  alt="A user is able to instantly enter their name and address to a form using autofill."
                  src="https://www.google.com/chrome/static/images/v2/accordion-timed/autofill.webp"
                  srcSet="/chrome/static/images/v2/accordion-timed/autofill.webp, /chrome/static/images/v2/accordion-timed/autofill-2x.webp 2x"
                  style={{
                    boxSizing: "border-box",
                    borderStyle: "none",
                    display: "block",
                    aspectRatio: "1 / 1",
                    height: "100%",
                    width: "100%",
                  }}
                />
              </div>
            </div>
            <div
              className="chr-accordion-timed__side-content chr-accordion-timed__side-content--has-link"
              style={{
                boxSizing: "border-box",
                gap: "40px",
                gridArea: "1 / 8 / auto / span 4",
                padding: "40px 0",
                WebkitBoxAlign: "start",
                alignItems: "flex-start",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                height: "100%",
                WebkitBoxPack: "justify",
                justifyContent: "space-between",
              }}
            >
              <div
                className="chr-accordion-timed__list"
                style={{
                  boxSizing: "border-box",
                  gap: "32px",
                  WebkitBoxAlign: "start",
                  alignItems: "flex-start",
                  alignSelf: "stretch",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                  flexShrink: 0,
                }}
              >
                <div
                  className="chr-accordion-timed__item chr-accordion-timed__item--active"
                  style={{
                    boxSizing: "border-box",
                    gap: "32px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    position: "relative",
                    willChange: "opacity",
                  }}
                >
                  <div
                    className="chr-accordion-timed__item__progress-wrapper"
                    style={{
                      boxSizing: "border-box",
                      alignSelf: "stretch",
                      flexShrink: 0,
                      position: "relative",
                      width: "4px",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__progress"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgb(241, 243, 244)",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                      }}
                    />
                    <div
                      className="chr-accordion-timed__item__progress chr-accordion-timed__item__progress--active"
                      style={{
                        boxSizing: "border-box",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                        backgroundColor: "rgb(26, 115, 232)",
                        transform: "scaleY(0)",
                        transformOrigin: "center top",
                        animationDuration: "5000ms",
                        animationFillMode: "forwards",
                        animationTimingFunction: "linear",
                        willChange: "transform",
                      }}
                    />
                  </div>
                  <div
                    className="chr-accordion-timed__item__content"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__title chr-accordion-timed__item__title-container"
                      aria-controls="customize-chrome-body"
                      aria-expanded="true"
                      role="button"
                      tabIndex="0"
                      style={{
                        cursor: "pointer",
                        padding: "8px",
                        boxSizing: "content-box",
                        transform: "translateX(-8px)",
                      }}
                    >
                      <h3
                        className="chr-accordion-timed__item__title chr-headline-4"
                        style={{
                          boxSizing: "border-box",
                          margin: "0px",
                          color: "rgb(32, 33, 36)",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 700,
                          fontSize: "1.75rem",
                          lineHeight: "2.25rem",
                          letterSpacing: "-0.03125rem",
                          cursor: "pointer",
                        }}
                      >
                        {"Customise your Chrome"}
                      </h3>
                    </div>
                    <div
                      id="customize-chrome-body"
                      className="chr-accordion-timed__item__body"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "grid-template-rows 500ms ease-out, -ms-grid-rows 500ms ease-out",
                        display: "grid",
                        gridTemplateRows: "1fr",
                      }}
                    >
                      <div
                        className="chr-accordion-timed__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          padding: "0px 0px 2px 2px",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy-xl"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1.125rem",
                            lineHeight: "1.75rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                          }}
                        >
                          Personalise your web browser with themes, dark mode
                          and other options built just for you.
                        </p>
                        <a
                          className="chr-link chr-link--primary chr-link--external chr-accordion-timed__item__link"
                          href="https://chrome.google.com/webstore/category/themes"
                          rel="noopener"
                          target="_blank"
                          style={{
                            boxSizing: "border-box",
                            backgroundColor: "rgba(0, 0, 0, 0)",
                            textDecoration: "none",
                            padding: "12px 0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            display: "inline-block",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 500,
                            color: "rgb(25, 103, 210)",
                          }}
                        >
                          {"Explore"}
                          <span
                            className="chr-link-icon"
                            style={{
                              boxSizing: "border-box",
                              WebkitBoxAlign: "center",
                              alignItems: "center",
                              display: "inline-flex",
                              flexWrap: "nowrap",
                            }}
                          >
                            {"themes"}
                            <svg
                              className="chr-link__icon"
                              aria-hidden="true"
                              style={{
                                boxSizing: "border-box",
                                overflow: "hidden",
                                transition:
                                  "transform 0.1s linear, -webkit-transform 0.1s linear",
                                height: "16px",
                                marginLeft: "6px",
                                verticalAlign: "middle",
                                width: "16px",
                                fill: "rgb(25, 103, 210)",
                              }}
                            >
                              <use
                                xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                                style={{ boxSizing: "border-box" }}
                              />
                            </svg>
                          </span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className="chr-accordion-timed__item"
                  style={{
                    boxSizing: "border-box",
                    gap: "32px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    position: "relative",
                    willChange: "opacity",
                  }}
                >
                  <div
                    className="chr-accordion-timed__item__progress-wrapper"
                    style={{
                      boxSizing: "border-box",
                      alignSelf: "stretch",
                      flexShrink: 0,
                      position: "relative",
                      width: "4px",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__progress"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgb(241, 243, 244)",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                      }}
                    />
                    <div
                      className="chr-accordion-timed__item__progress chr-accordion-timed__item__progress--active"
                      style={{
                        boxSizing: "border-box",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                        backgroundColor: "rgb(26, 115, 232)",
                        transform: "scaleY(0)",
                        transformOrigin: "center top",
                      }}
                    />
                  </div>
                  <div
                    className="chr-accordion-timed__item__content"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__title chr-accordion-timed__item__title-container"
                      aria-controls="browse-devices-body"
                      aria-expanded="false"
                      role="button"
                      tabIndex="0"
                      style={{
                        cursor: "pointer",
                        padding: "8px",
                        boxSizing: "content-box",
                        transform: "translateX(-8px)",
                      }}
                    >
                      <h3
                        className="chr-accordion-timed__item__title chr-headline-4"
                        style={{
                          boxSizing: "border-box",
                          margin: "0px",
                          color: "rgb(32, 33, 36)",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 700,
                          fontSize: "1.75rem",
                          lineHeight: "2.25rem",
                          letterSpacing: "-0.03125rem",
                          cursor: "pointer",
                        }}
                      >
                        {"Browse across devices"}
                      </h3>
                    </div>
                    <div
                      id="browse-devices-body"
                      className="chr-accordion-timed__item__body"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "grid-template-rows 500ms ease-out, -ms-grid-rows 500ms ease-out",
                        display: "grid",
                        gridTemplateRows: "0fr",
                      }}
                    >
                      <div
                        className="chr-accordion-timed__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          padding: "0px 0px 2px 2px",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy-xl"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1.125rem",
                            lineHeight: "1.75rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                          }}
                        >
                          Sign in to Chrome on any device to access your
                          bookmarks, saved passwords and more.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className="chr-accordion-timed__item"
                  style={{
                    boxSizing: "border-box",
                    gap: "32px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    position: "relative",
                    willChange: "opacity",
                  }}
                >
                  <div
                    className="chr-accordion-timed__item__progress-wrapper"
                    style={{
                      boxSizing: "border-box",
                      alignSelf: "stretch",
                      flexShrink: 0,
                      position: "relative",
                      width: "4px",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__progress"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgb(241, 243, 244)",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                      }}
                    />
                    <div
                      className="chr-accordion-timed__item__progress chr-accordion-timed__item__progress--active"
                      style={{
                        boxSizing: "border-box",
                        height: "100%",
                        position: "absolute",
                        top: "0px",
                        width: "100%",
                        backgroundColor: "rgb(26, 115, 232)",
                        transform: "scaleY(0)",
                        transformOrigin: "center top",
                      }}
                    />
                  </div>
                  <div
                    className="chr-accordion-timed__item__content"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <div
                      className="chr-accordion-timed__item__title chr-accordion-timed__item__title-container"
                      aria-controls="save-time-body"
                      aria-expanded="false"
                      role="button"
                      tabIndex="0"
                      style={{
                        cursor: "pointer",
                        padding: "8px",
                        boxSizing: "content-box",
                        transform: "translateX(-8px)",
                      }}
                    >
                      <h3
                        className="chr-accordion-timed__item__title chr-headline-4"
                        style={{
                          boxSizing: "border-box",
                          margin: "0px",
                          color: "rgb(32, 33, 36)",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 700,
                          fontSize: "1.75rem",
                          lineHeight: "2.25rem",
                          letterSpacing: "-0.03125rem",
                          cursor: "pointer",
                        }}
                      >
                        {"Save time with autofill"}
                      </h3>
                    </div>
                    <div
                      id="save-time-body"
                      className="chr-accordion-timed__item__body"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "grid-template-rows 500ms ease-out, -ms-grid-rows 500ms ease-out",
                        display: "grid",
                        gridTemplateRows: "0fr",
                      }}
                    >
                      <div
                        className="chr-accordion-timed__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          padding: "0px 0px 2px 2px",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy-xl"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1.125rem",
                            lineHeight: "1.75rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                          }}
                        >
                          Use Chrome to save addresses, passwords and more to
                          quickly autofill your details.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <a
                className="chr-link chr-link--button-secondary chr-link--external"
                href="http://accounts.google.com/"
                rel="noopener"
                target="_blank"
                style={{
                  boxSizing: "border-box",
                  textDecoration: "none",
                  backgroundColor: "rgb(232, 240, 254)",
                  color: "rgb(25, 103, 210)",
                  padding: "12px 0px",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  display: "inline-block",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "24px",
                  paddingInline: "24px",
                }}
              >
                {"Sign in to get"}
                <span
                  className="chr-link-icon"
                  style={{
                    boxSizing: "border-box",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "inline-flex",
                    flexWrap: "nowrap",
                  }}
                >
                  {"started"}
                  <svg
                    className="chr-link__icon"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      transition:
                        "transform 0.1s linear, -webkit-transform 0.1s linear",
                      fill: "currentcolor",
                      height: "16px",
                      marginLeft: "6px",
                      verticalAlign: "middle",
                      width: "16px",
                    }}
                  >
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </a>
            </div>
          </div>
          <div
            className="chr-accordion-timed__container-mobile chr-grid-default"
            style={{
              boxSizing: "border-box",
              columnGap: "64px",
              gridTemplateColumns: "repeat(12, 1fr)",
              paddingBlock: "40px",
              display: "none",
              visibility: "hidden",
            }}
          >
            <div
              className="chr-accordion-timed__panel-mobile-wrapper"
              style={{
                boxSizing: "border-box",
                gap: "64px",
                WebkitBoxAlign: "start",
                alignItems: "flex-start",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                gridColumn: "3 / -3",
              }}
            >
              <div
                className="chr-accordion-timed__panel-mobile-content"
                style={{
                  boxSizing: "border-box",
                  gap: "8px",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                }}
              >
                <div
                  className="chr-accordion-timed__mobile-content__panel"
                  style={{
                    boxSizing: "border-box",
                    borderRadius: "24px",
                    overflow: "hidden",
                    aspectRatio: "auto 3 / 2",
                    marginBottom: "8px",
                  }}
                >
                  <img
                    height={624}
                    width={624}
                    alt="Icons display nine different themes. If the user clicks the theme, the background image will change."
                    src="https://www.google.com/chrome/static/images/v2/accordion-timed/themes-mobile.webp"
                    srcSet="/chrome/static/images/v2/accordion-timed/themes-mobile.webp, /chrome/static/images/v2/accordion-timed/themes-mobile-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "100%",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-accordion-timed__mobile-content__item chr-accordion-timed__mobile-content__item--active"
                  style={{ boxSizing: "border-box" }}
                >
                  <div
                    className="chr-accordion-timed__mobile-content__item__content"
                    style={{
                      boxSizing: "border-box",
                      gap: "8px",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <h3
                      className="chr-accordion-timed__mobile-content__item__title chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        color: "rgb(32, 33, 36)",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 700,
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                      }}
                    >
                      {"Customise your Chrome"}
                    </h3>
                    <div
                      className="chr-accordion-timed__mobile-content__item__body"
                      style={{ boxSizing: "border-box" }}
                    >
                      <div
                        className="chr-accordion-timed__mobile-content__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                          }}
                        >
                          Personalise your web browser with themes, dark mode
                          and other options built just for you.
                        </p>
                        <a
                          className="chr-link chr-link--primary chr-link--external chr-accordion-timed__mobile-content__item__link"
                          href="https://chrome.google.com/webstore/category/themes"
                          rel="noopener"
                          target="_blank"
                          style={{
                            boxSizing: "border-box",
                            backgroundColor: "rgba(0, 0, 0, 0)",
                            textDecoration: "none",
                            padding: "12px 0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            display: "inline-block",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 500,
                            color: "rgb(25, 103, 210)",
                          }}
                        >
                          {"Explore"}
                          <span
                            className="chr-link-icon"
                            style={{
                              boxSizing: "border-box",
                              WebkitBoxAlign: "center",
                              alignItems: "center",
                              display: "inline-flex",
                              flexWrap: "nowrap",
                            }}
                          >
                            {"themes"}
                            <svg
                              className="chr-link__icon"
                              aria-hidden="true"
                              style={{
                                boxSizing: "border-box",
                                overflow: "hidden",
                                transition:
                                  "transform 0.1s linear, -webkit-transform 0.1s linear",
                                height: "16px",
                                marginLeft: "6px",
                                verticalAlign: "middle",
                                width: "16px",
                                fill: "rgb(25, 103, 210)",
                              }}
                            >
                              <use
                                xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                                style={{ boxSizing: "border-box" }}
                              />
                            </svg>
                          </span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="chr-accordion-timed__panel-mobile-content"
                style={{
                  boxSizing: "border-box",
                  gap: "8px",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                }}
              >
                <div
                  className="chr-accordion-timed__mobile-content__panel"
                  style={{
                    boxSizing: "border-box",
                    borderRadius: "24px",
                    overflow: "hidden",
                    aspectRatio: "auto 3 / 2",
                    marginBottom: "8px",
                  }}
                >
                  <img
                    height={624}
                    width={624}
                    alt="A mobile browser loads tabs from a desktop browser, including Google Maps and NYC parking info."
                    src="https://www.google.com/chrome/static/images/v2/accordion-timed/tab-sync-mobile.webp"
                    srcSet="/chrome/static/images/v2/accordion-timed/tab-sync-mobile.webp, /chrome/static/images/v2/accordion-timed/tab-sync-mobile-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "100%",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-accordion-timed__mobile-content__item"
                  style={{ boxSizing: "border-box" }}
                >
                  <div
                    className="chr-accordion-timed__mobile-content__item__content"
                    style={{
                      boxSizing: "border-box",
                      gap: "8px",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <h3
                      className="chr-accordion-timed__mobile-content__item__title chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        color: "rgb(32, 33, 36)",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 700,
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                      }}
                    >
                      {"Browse across devices"}
                    </h3>
                    <div
                      className="chr-accordion-timed__mobile-content__item__body"
                      style={{ boxSizing: "border-box" }}
                    >
                      <div
                        className="chr-accordion-timed__mobile-content__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                          }}
                        >
                          Sign in to Chrome on any device to access your
                          bookmarks, saved passwords and more.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="chr-accordion-timed__panel-mobile-content"
                style={{
                  boxSizing: "border-box",
                  gap: "8px",
                  WebkitBoxAlign: "stretch",
                  alignItems: "stretch",
                  display: "flex",
                  WebkitBoxOrient: "vertical",
                  WebkitBoxDirection: "normal",
                  flexDirection: "column",
                }}
              >
                <div
                  className="chr-accordion-timed__mobile-content__panel"
                  style={{
                    boxSizing: "border-box",
                    borderRadius: "24px",
                    overflow: "hidden",
                    aspectRatio: "auto 3 / 2",
                    marginBottom: "8px",
                  }}
                >
                  <img
                    height={624}
                    width={624}
                    alt="A user is able to instantly enter their name and address to a form using autofill."
                    src="https://www.google.com/chrome/static/images/v2/accordion-timed/autofill-mobile.webp"
                    srcSet="/chrome/static/images/v2/accordion-timed/autofill-mobile.webp, /chrome/static/images/v2/accordion-timed/autofill-mobile-2x.webp 2x"
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "100%",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-accordion-timed__mobile-content__item"
                  style={{ boxSizing: "border-box" }}
                >
                  <div
                    className="chr-accordion-timed__mobile-content__item__content"
                    style={{
                      boxSizing: "border-box",
                      gap: "8px",
                      WebkitBoxAlign: "start",
                      alignItems: "flex-start",
                      display: "flex",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                    }}
                  >
                    <h3
                      className="chr-accordion-timed__mobile-content__item__title chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        color: "rgb(32, 33, 36)",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 700,
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                      }}
                    >
                      {"Save time with autofill"}
                    </h3>
                    <div
                      className="chr-accordion-timed__mobile-content__item__body"
                      style={{ boxSizing: "border-box" }}
                    >
                      <div
                        className="chr-accordion-timed__mobile-content__item__inner-body"
                        style={{
                          boxSizing: "border-box",
                          gap: "8px",
                          overflow: "hidden",
                          WebkitBoxAlign: "start",
                          alignItems: "flex-start",
                          display: "flex",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                        }}
                      >
                        <p
                          className="chr-copy"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                          }}
                        >
                          Use Chrome to save addresses, passwords and more to
                          quickly autofill your details.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <a
                className="chr-link chr-link--button-secondary chr-link--external"
                href="http://accounts.google.com/"
                rel="noopener"
                target="_blank"
                style={{
                  boxSizing: "border-box",
                  textDecoration: "none",
                  backgroundColor: "rgb(232, 240, 254)",
                  color: "rgb(25, 103, 210)",
                  padding: "12px 0px",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  display: "inline-block",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "24px",
                  paddingInline: "24px",
                }}
              >
                {"Sign in to get"}
                <span
                  className="chr-link-icon"
                  style={{
                    boxSizing: "border-box",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "inline-flex",
                    flexWrap: "nowrap",
                  }}
                >
                  {"started"}
                  <svg
                    className="chr-link__icon"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      transition:
                        "transform 0.1s linear, -webkit-transform 0.1s linear",
                      fill: "currentcolor",
                      height: "16px",
                      marginLeft: "6px",
                      verticalAlign: "middle",
                      width: "16px",
                    }}
                  >
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </a>
            </div>
          </div>
        </div>
        <div
          className="chr-media-content chr-grid-default-parent chr-show-only-in-desktop environment environment--active"
          style={{
            boxSizing: "border-box",
            margin: "auto",
            padding: "0px 74px",
            maxWidth: "1440px",
            display: "block",
            visibility: "visible",
            paddingBlock: "40px",
          }}
        >
          <div
            className="chr-media-content__container chr-grid-default"
            style={{
              boxSizing: "border-box",
              display: "grid",
              columnGap: "64px",
              gridTemplateColumns: "repeat(12, 1fr)",
              rowGap: "16px",
              WebkitBoxAlign: "center",
              alignItems: "center",
            }}
          >
            <div
              className="chr-media-content__content-wrapper"
              style={{
                boxSizing: "border-box",
                gridColumn: "span 4",
                height: "fit-content",
              }}
            >
              <h3
                className="chr-headline-4 chr-media-content__heading"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 700,
                  fontSize: "3rem",
                  letterSpacing: "-0.0625rem",
                  lineHeight: "3.5rem",
                  marginBottom: "16px",
                }}
              >
                {"Extend your experience"}
              </h3>
              <p
                className="chr-media-content__body chr-copy chr-text-content"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  fontFamily: '"Google Sans Text", arial, sans-serif',
                  fontWeight: 400,
                  color: "rgb(95, 99, 104)",
                  fontSize: "1.125rem",
                  letterSpacing: "0px",
                  lineHeight: "1.75rem",
                }}
              >
                {
                  "From shopping and entertainment to productivity, find extensions to improve your experience in the Chrome Web Store."
                }
              </p>
              <a
                className="chr-link chr-link--button-secondary chr-link--external chr-media-content__link"
                href="https://chrome.google.com/webstore/category/extensions"
                rel="noopener"
                target="_blank"
                style={{
                  boxSizing: "border-box",
                  textDecoration: "none",
                  backgroundColor: "rgb(232, 240, 254)",
                  color: "rgb(25, 103, 210)",
                  padding: "12px 0px",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  display: "inline-block",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "24px",
                  paddingInline: "24px",
                  marginTop: "40px",
                  maxWidth: "fit-content",
                  width: "100%",
                }}
              >
                {"Explore"}
                <span
                  className="chr-link-icon"
                  style={{
                    boxSizing: "border-box",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "inline-flex",
                    flexWrap: "nowrap",
                  }}
                >
                  {"extensions"}
                  <svg
                    className="chr-link__icon"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      transition:
                        "transform 0.1s linear, -webkit-transform 0.1s linear",
                      fill: "currentcolor",
                      height: "16px",
                      marginLeft: "6px",
                      verticalAlign: "middle",
                      width: "16px",
                    }}
                  >
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </a>
            </div>
            <div
              className="chr-media-content__media-wrapper"
              style={{
                boxSizing: "border-box",
                display: "flex",
                position: "relative",
                gridColumn: "3 / 11",
                gridArea: "initial / span 8",
              }}
            >
              <img
                className="js-lazy-load"
                alt="An abstract Chrome UI is surrounded by icons that represent categories for browser extensions. The icons represent Shopping, Entertainment, Tools, Art & Design, and Accessibility."
                src="https://www.google.com/chrome/static/images/dev-components/extensions-ui.png"
                srcSet={`/chrome/static/images/dev-components/extensions-ui.png 1x,
            /chrome/static/images/dev-components/extensions-ui-2x.png 2x`}
                style={{
                  boxSizing: "border-box",
                  borderStyle: "none",
                  height: "auto",
                  width: "100%",
                }}
              />
              <div
                className="chr-keyframe-animation is-loaded"
                style={{
                  boxSizing: "border-box",
                  height: "100%",
                  left: "0px",
                  position: "absolute",
                  top: "0px",
                  width: "100%",
                  opacity: 1,
                }}
              >
                <div
                  className="chr-keyframe-animation__layer"
                  style={{
                    boxSizing: "border-box",
                    transition: "none",
                    display: "flex",
                    height: "auto",
                    opacity: "var(--opacity, 1)",
                    position: "absolute",
                    transform:
                      "translateX(25.2px) translateY(130.890625px) scale(1)",
                    width: "10%",
                  }}
                >
                  <img
                    width={84}
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/dev-components/extensions-shop.png"
                    srcSet={`/chrome/static/images/dev-components/extensions-shop.png,
                  /chrome/static/images/dev-components/extensions-shop-2x.png 2x`}
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "auto",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-keyframe-animation__layer"
                  style={{
                    boxSizing: "border-box",
                    transition: "none",
                    display: "flex",
                    height: "auto",
                    opacity: "var(--opacity, 1)",
                    position: "absolute",
                    transform: "translateX(520.8px) translateY(0px) scale(1)",
                    width: "18%",
                  }}
                >
                  <img
                    width={151}
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/dev-components/extensions-icon.png"
                    srcSet={`/chrome/static/images/dev-components/extensions-icon.png,
                  /chrome/static/images/dev-components/extensions-icon-2x.png 2x`}
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "auto",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-keyframe-animation__layer"
                  style={{
                    boxSizing: "border-box",
                    transition: "none",
                    display: "flex",
                    height: "auto",
                    opacity: "var(--opacity, 1)",
                    position: "absolute",
                    transform:
                      "translateX(730.8px) translateY(188.4825px) scale(1)",
                    width: "10%",
                  }}
                >
                  <img
                    width={84}
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/dev-components/extensions-video.png"
                    srcSet={`/chrome/static/images/dev-components/extensions-video.png,
                  /chrome/static/images/dev-components/extensions-video-2x.png 2x`}
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "auto",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-keyframe-animation__layer"
                  style={{
                    boxSizing: "border-box",
                    transition: "none",
                    display: "flex",
                    height: "auto",
                    opacity: "var(--opacity, 1)",
                    position: "absolute",
                    transform:
                      "translateX(562.8px) translateY(382.200625px) scale(1)",
                    width: "10%",
                  }}
                >
                  <img
                    width={84}
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/dev-components/extensions-paint.png"
                    srcSet={`/chrome/static/images/dev-components/extensions-paint.png,
                  /chrome/static/images/dev-components/extensions-paint-2x.png 2x`}
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "auto",
                      width: "100%",
                    }}
                  />
                </div>
                <div
                  className="chr-keyframe-animation__layer"
                  style={{
                    boxSizing: "border-box",
                    transition: "none",
                    display: "flex",
                    height: "auto",
                    opacity: "var(--opacity, 1)",
                    position: "absolute",
                    transform:
                      "translateX(151.2px) translateY(403.143125px) scale(1)",
                    width: "12%",
                  }}
                >
                  <img
                    width={101}
                    aria-hidden="true"
                    src="https://www.google.com/chrome/static/images/dev-components/extensions-person.png"
                    srcSet={`/chrome/static/images/dev-components/extensions-person.png,
                  /chrome/static/images/dev-components/extensions-person-2x.png 2x`}
                    style={{
                      boxSizing: "border-box",
                      borderStyle: "none",
                      height: "auto",
                      width: "100%",
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
