import React from "react";

export default function Center() {
  return (
    <>
    
      <div
        className="chr-grid-default chr-chrome-hero__wrapper"
        style={{
          boxSizing: "border-box",
          display: "grid",
          columnGap: "64px",
          gridTemplateColumns: "repeat(12, 1fr)",
          gridTemplateRows:
            "40px [logo] auto 8px [heading] auto 32px [jumplinks] auto 24px [download] auto 64px",
        }}
      >
        <div
          className="chr-chrome-hero__logo"
          style={{
            boxSizing: "border-box",
            transition: "opacity 0.85s ease-out, top 0.85s ease-out",
            position: "relative",
            gridArea: "logo / 1 / logo / -1",
            opacity: 1,
            top: "0px",
          }}
        >
          <img
            alt="Google Chrome logo."
            role="img"
            src="https://www.google.com/chrome/static/images/chrome-logo-m100.svg"
            style={{
              boxSizing: "border-box",
              borderStyle: "none",
              margin: "auto",
              display: "block",
            }}
          />
        </div>
        <h1
          className="chr-headline-0 chr-chrome-hero__heading"
          style={{
            boxSizing: "border-box",
            margin: "0px",
            color: "rgb(32, 33, 36)",
            fontFamily: '"Google Sans", arial, sans-serif',
            fontWeight: 700,
            fontSize: "4.5rem",
            lineHeight: "5.25rem",
            letterSpacing: "-0.21875rem",
            transition: "opacity 0.85s ease-out, top 0.85s ease-out",
            position: "relative",
            gridArea: "heading / 1 / heading / -1",
            textAlign: "center",
            opacity: 1,
            top: "0px",
          }}
        >
          {"The browser"}
          <br style={{ boxSizing: "border-box" }} /> built to be yours
        </h1>
        <div
          className="chr-chrome-hero__jumplinks environment environment--active"
          style={{
            boxSizing: "border-box",
            display: "block",
            transition: "opacity 0.85s ease-out, top 0.85s ease-out",
            position: "relative",
            gridArea: "jumplinks / 1 / jumplinks / -1",
            minHeight: "56px",
            opacity: 1,
            top: "0px",
          }}
        >
          <div
            className="chr-jumplinks-v2 chr-jumplinks-v2--sticky"
            aria-hidden="true"
            style={{
              boxSizing: "border-box",
              transition:
                "transform 0.4s ease-in, -webkit-transform 0.4s ease-in",
              left: "0px",
              pointerEvents: "none",
              width: "100%",
              zIndex: 50,
              position: "initial",
              top: "84px",
              willChange: "top",
              display: "block",
            }}
          >
            <ul
              className="chr-jumplinks-v2__list shadow-elevation-2"
              style={{
                boxSizing: "border-box",
                boxShadow:
                  "rgba(32, 33, 36, 0.15) 0px 1px 2px, rgba(32, 33, 36, 0.08) 0px 1px 8px",
                borderRadius: "50px",
                margin: "0px auto",
                padding: "8px",
                backgroundColor: "rgb(255, 255, 255)",
                display: "flex",
                WebkitBoxPack: "center",
                justifyContent: "center",
                pointerEvents: "all",
                width: "fit-content",
              }}
            >
              <li
                className="chr-jumplinks-v2__list-item"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px 1px",
                  flexShrink: 0,
                }}
              >
                <a
                  className="chr-link chr-link--jumplink"
                  href="https://www.google.com/chrome/index.html#updates"
                  tabIndex="-1"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    borderRadius: "50px",
                    color: "rgb(95, 99, 104)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    padding: "8px 20px",
                    height: "40px",
                  }}
                >
                  {"Updates"}
                </a>
              </li>
              <li
                className="chr-jumplinks-v2__list-item"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px 1px",
                  flexShrink: 0,
                }}
              >
                <a
                  className="chr-link chr-link--jumplink"
                  href="https://www.google.com/chrome/index.html#yours"
                  tabIndex="-1"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    borderRadius: "50px",
                    color: "rgb(95, 99, 104)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    padding: "8px 20px",
                    height: "40px",
                  }}
                >
                  {"Yours"}
                </a>
              </li>
              <li
                className="chr-jumplinks-v2__list-item"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px 1px",
                  flexShrink: 0,
                }}
              >
                <a
                  className="chr-link chr-link--jumplink"
                  href="https://www.google.com/chrome/index.html#safe"
                  tabIndex="-1"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    borderRadius: "50px",
                    color: "rgb(95, 99, 104)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    padding: "8px 20px",
                    height: "40px",
                  }}
                >
                  {"Safe"}
                </a>
              </li>
              <li
                className="chr-jumplinks-v2__list-item"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px 1px",
                  flexShrink: 0,
                }}
              >
                <a
                  className="chr-link chr-link--jumplink"
                  href="https://www.google.com/chrome/index.html#fast"
                  tabIndex="-1"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    borderRadius: "50px",
                    color: "rgb(95, 99, 104)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    padding: "8px 20px",
                    height: "40px",
                  }}
                >
                  {"Fast"}
                </a>
              </li>
              <li
                className="chr-jumplinks-v2__list-item"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px 1px",
                  flexShrink: 0,
                }}
              >
                <a
                  className="chr-link chr-link--jumplink"
                  href="https://www.google.com/chrome/index.html#by-google"
                  tabIndex="-1"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontSize: "1rem",
                    lineHeight: "1.5rem",
                    letterSpacing: "0rem",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    borderRadius: "50px",
                    color: "rgb(95, 99, 104)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    padding: "8px 20px",
                    height: "40px",
                  }}
                >
                  {"By Google"}
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div
          className="chr-chrome-hero__download environment environment--active"
          style={{
            boxSizing: "border-box",
            display: "block",
            transition: "opacity 0.85s ease-out, top 0.85s ease-out",
            position: "relative",
            gridArea: "download / 1 / download / -1",
            gridColumn: "3 / span 8",
            opacity: 1,
            top: "0px",
          }}
        >
          <div
            className="chr-text-installer"
            style={{
              boxSizing: "border-box",
              WebkitBoxAlign: "center",
              alignItems: "center",
              display: "flex",
              WebkitBoxOrient: "horizontal",
              WebkitBoxDirection: "normal",
              flexDirection: "row",
              WebkitBoxPack: "center",
              justifyContent: "center",
              textAlign: "center",
              width: "100%",
            }}
          >
            <p
              className="chr-text-installer__copy chr-copy"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "1rem",
                lineHeight: "1.5rem",
                letterSpacing: "0rem",
                fontFamily: '"Google Sans Text", arial, sans-serif',
                fontWeight: 400,
                color: "rgb(32, 33, 36)",
              }}
            >
              {"Need the Chrome installer?"}
              <span
                className="chr-text-installer__download_button"
                style={{ boxSizing: "border-box" }}
              >
                <button
                  id="js-download-hero"
                  className="chr-download-button chr-download-button--inline js-download show"
                  type="button"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    overflow: "visible",
                    textTransform: "none",
                    background: "none",
                    border: "none",
                    gap: "8px",
                    whiteSpace: "nowrap",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "inline-flex",
                    height: "auto",
                    WebkitBoxPack: "center",
                    justifyContent: "center",
                    WebkitBoxOrient: "horizontal",
                    WebkitBoxDirection: "reverse",
                    flexDirection: "row-reverse",
                    borderRadius: "0px",
                    padding: "0px",
                    color: "rgb(25, 103, 210)",
                    fontFamily: "inherit",
                    fontSize: "inherit",
                    fontWeight: "inherit",
                    letterSpacing: "inherit",
                    lineHeight: "inherit",
                    appearance: "button",
                  }}
                >
                  {"Download here"}
                  <svg
                    className="chr-button__icon chr-download-button__icon"
                    style={{
                      boxSizing: "border-box",
                      height: "20px",
                      width: "20px",
                      overflow: "hidden",
                      display: "none",
                    }}
                  >
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#download"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </button>
              </span>
            </p>
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
