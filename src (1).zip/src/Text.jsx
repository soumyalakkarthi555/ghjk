import React from "react";

export default function Text() {
  return (
    <>
      <h1
        className="chr-headline-0 chr-chrome-hero__heading"
        style={{
          boxSizing: "border-box",
          margin: "0px",
          color: "rgb(32, 33, 36)",
          fontFamily: '"Google Sans", arial, sans-serif',
          fontWeight: 700,
          fontSize: "4.5rem",
          lineHeight: "5.25rem",
          letterSpacing: "-0.21875rem",
          transition: "opacity 0.85s ease-out, top 0.85s ease-out",
          position: "relative",
          gridArea: "heading / 1 / heading / -1",
          textAlign: "center",
          opacity: 1,
          top: "0px",
        }}
      >
        {"The browser"}
        <br style={{ boxSizing: "border-box" }} /> built to be yours
      </h1>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
