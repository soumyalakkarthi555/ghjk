import React from "react";

export default function Middlebar() {
  return (
    <>
      <div
        className="chr-chrome-hero__jumplinks environment environment--active"
        style={{
          boxSizing: "border-box",
          display: "block",
          transition: "opacity 0.85s ease-out, top 0.85s ease-out",
          position: "relative",
          gridArea: "jumplinks / 1 / jumplinks / -1",
          minHeight: "56px",
          opacity: 1,
          top: "0px",
        }}
      >
        <div
          className="chr-jumplinks-v2 chr-jumplinks-v2--sticky"
          aria-hidden="true"
          style={{
            boxSizing: "border-box",
            transition:
              "transform 0.4s ease-in, -webkit-transform 0.4s ease-in",
            left: "0px",
            pointerEvents: "none",
            width: "100%",
            zIndex: 50,
            position: "initial",
            top: "84px",
            willChange: "top",
            display: "block",
          }}
        >
          <ul
            className="chr-jumplinks-v2__list shadow-elevation-2"
            style={{
              boxSizing: "border-box",
              boxShadow:
                "rgba(32, 33, 36, 0.15) 0px 1px 2px, rgba(32, 33, 36, 0.08) 0px 1px 8px",
              borderRadius: "50px",
              margin: "0px auto",
              padding: "8px",
              backgroundColor: "rgb(255, 255, 255)",
              display: "flex",
              WebkitBoxPack: "center",
              justifyContent: "center",
              pointerEvents: "all",
              width: "fit-content",
            }}
          >
            <li
              className="chr-jumplinks-v2__list-item"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px 1px",
                flexShrink: 0,
              }}
            >
              <a
                className="chr-link chr-link--jumplink"
                href="https://www.google.com/chrome/index.html#updates"
                tabIndex="-1"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "50px",
                  color: "rgb(95, 99, 104)",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  padding: "8px 20px",
                  height: "40px",
                }}
              >
                {"Updates"}
              </a>
            </li>
            <li
              className="chr-jumplinks-v2__list-item"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px 1px",
                flexShrink: 0,
              }}
            >
              <a
                className="chr-link chr-link--jumplink"
                href="https://www.google.com/chrome/index.html#yours"
                tabIndex="-1"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "50px",
                  color: "rgb(95, 99, 104)",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  padding: "8px 20px",
                  height: "40px",
                }}
              >
                {"Yours"}
              </a>
            </li>
            <li
              className="chr-jumplinks-v2__list-item"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px 1px",
                flexShrink: 0,
              }}
            >
              <a
                className="chr-link chr-link--jumplink"
                href="https://www.google.com/chrome/index.html#safe"
                tabIndex="-1"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "50px",
                  color: "rgb(95, 99, 104)",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  padding: "8px 20px",
                  height: "40px",
                }}
              >
                {"Safe"}
              </a>
            </li>
            <li
              className="chr-jumplinks-v2__list-item"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px 1px",
                flexShrink: 0,
              }}
            >
              <a
                className="chr-link chr-link--jumplink"
                href="https://www.google.com/chrome/index.html#fast"
                tabIndex="-1"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "50px",
                  color: "rgb(95, 99, 104)",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  padding: "8px 20px",
                  height: "40px",
                }}
              >
                {"Fast"}
              </a>
            </li>
            <li
              className="chr-jumplinks-v2__list-item"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                margin: "0px",
                padding: "0px 1px",
                flexShrink: 0,
              }}
            >
              <a
                className="chr-link chr-link--jumplink"
                href="https://www.google.com/chrome/index.html#by-google"
                tabIndex="-1"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  borderRadius: "50px",
                  color: "rgb(95, 99, 104)",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  padding: "8px 20px",
                  height: "40px",
                }}
              >
                {"By Google"}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
