import Accordian from './Accordian';
import Adjacent from './Adjacent';
import Adjacent1 from './Adjacent1';
import Adjacent2 from './Adjacent2';
import Adjacent3 from './Adjacent3';
import './App.css';
import Center1 from './Center1';
import CenterContext from './CenterContext';
import CenterContext2 from './CenterContext2';
import CenterContext4 from './CenterContext4';
import CenterFooter from './CenterFooter';
import CenterText from './CenterText';
import CenterText2 from './CenterText2';
import CenterText3 from './CenterText3';
import Centercontext3 from './Centercontext3';
import Footer from './Footer';
import FooterText from './FooterText';
import Header from "./Header"
import Hero from './Hero';
import MainAdjacent from './MainAdjacent';
import Middlebar from './Middlebar';
import Middlebar1 from './Middlebar1';
import Text from './Text';
import Textabove1 from './Textabove1';
import Textabove2 from './Textabove2';

function App() {
  return (
    <div className="App">
      
      <Header />
      <Center1/>
      <Hero/>
      <Text/>
      <Middlebar/>
      <Middlebar1/>
      <MainAdjacent/>
     <Adjacent  />
     <Adjacent1/>
     <Adjacent2/>
     <Adjacent3/>
     <CenterText/>
     <CenterText2/>
     <CenterText3/>
     <CenterContext/>






<Textabove2/>
<Textabove1/>
<CenterContext4/>
     <Centercontext3/>
     <br/>
     <br/>
     <br/>
     <Accordian/>
     <CenterContext2/>
    
    <CenterFooter/>
    <FooterText/>
     <Footer/>      
   </div>
  );
}

export default App;
