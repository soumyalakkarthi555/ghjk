import React from "react";

export default function CenterFooter() {
  return (
    <>
      <div
        className="chr-grid-default"
        style={{
          boxSizing: "border-box",
          display: "grid",
          columnGap: "64px",
          gridTemplateColumns: "repeat(12, 1fr)",
        }}
      >
        <div
          className="chr-accordion-group__wrapper"
          style={{
            boxSizing: "border-box",
            gridArea: "2 / 1 / auto / span 4",
            WebkitBoxAlign: "start",
            alignItems: "flex-start",
            display: "flex",
            WebkitBoxOrient: "vertical",
            WebkitBoxDirection: "normal",
            flexDirection: "column",
            WebkitBoxPack: "center",
            justifyContent: "center",
            zIndex: 1,
            gridColumn: "2 / span 10",
          }}
        >
          <h2
            className="chr-headline-2 chr-accordion-group__heading"
            style={{
              boxSizing: "border-box",
              margin: "0px",
              color: "rgb(32, 33, 36)",
              fontFamily: '"Google Sans", arial, sans-serif',
              fontWeight: 700,
              fontSize: "3rem",
              lineHeight: "3.5rem",
              letterSpacing: "-0.0625rem",
              textAlign: "center",
              width: "100%",
              marginTop: "80px",
            }}
          >
            Frequently asked questions
          </h2>
          <div
            className="chr-accordion-group"
            style={{
              boxSizing: "border-box",
              padding: "40px 0 64px",
              width: "100%",
              paddingBottom: "80px",
            }}
          >
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-1"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-1-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      How do I make Chrome my default web browser?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-1-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    You can set Chrome as your default browser on Windows or Mac
                    operating systems as well as your iPhone, iPad or Android
                    device. When you set Chrome as your default browser, any
                    link you click will automatically open in Chrome.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://support.google.com/chrome/answer/95417"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Find specific instructions for your device here
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-2"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-2-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      How can I customise Chrome?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-2-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    You can test out different colours, themes and settings in
                    real time by opening a new tab in Chrome and clicking the
                    “Customise Chrome” icon in the bottom right corner. A new
                    side panel will open with the available customisation
                    features.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://blog.google/products/chrome/new-ways-to-customize-chrome-on-your-desktop/"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Learn more about customising Chrome
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-3"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-3-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      What are Chrome's safety settings?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-3-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    Chrome uses cutting-edge safety and security features to
                    help you manage your safety. Use Safety Check to instantly
                    audit for compromised passwords, safe browsing status and
                    any available Chrome updates.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://support.google.com/chrome/answer/10468685?hl=en&co=GENIE.Platform%3DAndroid"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Learn more about safety and security on Chrome
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-4"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-4-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      What is Chrome’s password manager?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-4-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    Chrome uses{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="http://passwords.google.com/"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Google Password Manager
                    </a>
                    , which makes it simple to save, manage and protect your
                    passwords online. It also helps you create strong, unique
                    passwords for every account you use.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://passwords.google/"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Learn more about Google Password Manager
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-5"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-5-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      How do I add a browser extension to Chrome?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-5-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    It’s easy to add extensions to Chrome for desktop. Simply
                    visit the Chrome Web Store, find and select the extension
                    you want, and click Add to Chrome. Some extensions might
                    need additional permissions. To use the extension, click on
                    its icon to the right of the address bar.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://support.google.com/chrome_webstore/answer/2664769?hl=en"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Learn more about extensions
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
            <div
              className="chr-accordion chr-accordion--faq"
              style={{
                boxSizing: "border-box",
                fontSize: "0.75rem",
                lineHeight: "1.25rem",
                letterSpacing: "0.0125rem",
                position: "relative",
              }}
            >
              <div
                id="faq-section-6"
                className="chr-accordion__hint-container js-collapsible__hint"
                aria-controls="faq-section-6-collapsible"
                aria-expanded="false"
                role="button"
                tabIndex="0"
                style={{
                  overflow: "hidden",
                  cursor: "pointer",
                  paddingInline: "8px",
                  boxSizing: "content-box",
                  transform: "translateX(-8px)",
                  width: "100%",
                }}
              >
                <span
                  className="chr-accordion__hint js-collapsible__hint-title"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "1rem",
                    lineHeight: "2rem",
                    margin: "0px",
                    padding: "40px 0",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxPack: "justify",
                    justifyContent: "space-between",
                    marginBottom: "0px",
                    width: "100%",
                    gap: "24px",
                    color: "rgb(25, 103, 210)",
                    paddingBottom: "32px",
                  }}
                >
                  <div
                    className="chr-accordion__header"
                    style={{ boxSizing: "border-box" }}
                  >
                    <h3
                      className="chr-accordion__heading chr-headline-4"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontSize: "1.75rem",
                        lineHeight: "2.25rem",
                        letterSpacing: "-0.03125rem",
                        fontWeight: 700,
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      How do I update Chrome?
                    </h3>
                  </div>
                  <svg
                    className="chr-icon chr-icon--32 chr-accordion__icon js-collapsible__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      verticalAlign: "middle",
                      height: "32px",
                      width: "32px",
                      transition: "transform 0.3s, -webkit-transform 0.3s",
                      fill: "rgb(25, 103, 210)",
                      minWidth: "32px",
                      overflow: "hidden",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }} />
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#plus-icon"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </span>
              </div>
              <div
                id="faq-section-6-collapsible"
                className="chr-accordion__panel js-collapsible__panel"
                aria-hidden="true"
                role="region"
                style={{
                  boxSizing: "border-box",
                  overflow: "hidden",
                  transition: "padding 0.3s ease-out",
                }}
              >
                <div
                  className="chr-accordion__content js-collapsible__panel_content"
                  style={{
                    boxSizing: "border-box",
                    transition: "height 0.4s ease-out",
                    padding: "0px",
                    height: "0px",
                  }}
                >
                  <p
                    className="chr-copy chr-accordion__description"
                    tabIndex="-1"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "1rem",
                      lineHeight: "1.5rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      fontWeight: 400,
                      maxWidth: "720px",
                    }}
                  >
                    Normally updates happen in the background when you close and
                    reopen your computer's browser. If you haven’t closed your
                    browser in a while, you might see a pending update.{" "}
                    <a
                      className="chr-accordion__link"
                      aria-hidden="true"
                      href="https://support.google.com/chrome/answer/95414?hl=en&co=GENIE.Platform%3DDesktop"
                      rel="noopener noreferrer"
                      tabIndex="-1"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        color: "rgb(25, 103, 210)",
                      }}
                    >
                      Learn more about Chrome updates
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
