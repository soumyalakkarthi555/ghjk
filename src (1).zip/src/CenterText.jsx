import React from "react";

export default function CenterText() {
  return (
    <>
      <h2
        className="chr-headline-1"
        aria-label="Discover the latest updates from Chrome"
        style={{
          boxSizing: "border-box",
          margin: "0px",
          color: "rgb(32, 33, 36)",
          fontFamily: '"Google Sans", arial, sans-serif',
          fontWeight: 700,
          fontSize: "3.75rem",
          lineHeight: "4.5rem",
          letterSpacing: "-0.078125rem",
          textAlign: "center",
        }}
      >
        {"Discover the latest"}
        <br style={{ boxSizing: "border-box" }} />{" "}
        <span
          className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--blue chr-heading-pill__pill-container--medium animated"
          aria-hidden="true"
          style={{
            boxSizing: "border-box",
            overflow: "hidden",
            position: "relative",
            textAlign: "center",
            borderRadius: "48px",
            display: "inline-flex",
            WebkitBoxOrient: "horizontal",
            WebkitBoxDirection: "normal",
            flexDirection: "row",
            backgroundColor: "rgb(232, 240, 254)",
            color: "rgb(25, 103, 210)",
            WebkitBoxAlign: "center",
            alignItems: "center",
            transform: "none",
            animationFillMode: "both",
            animationTimingFunction: "ease-in-out",
            lineHeight: "4.5rem",
          }}
        >
          <span
            className="chr-heading-pill__mock"
            style={{ boxSizing: "border-box", height: "40px" }}
          />
          <div
            className="chr-lottie-animation chr-heading-pill__icon"
            style={{
              boxSizing: "border-box",
              display: "inline-flex",
              flexShrink: 0,
              marginLeft: "8px",
              height: "72px",
              width: "72px",
            }}
          >
            <svg
              height="72"
              width="72"
              preserveAspectRatio="xMidYMid meet"
              viewBox="0 0 72 72"
              xmlns="http://www.w3.org/2000/svg"
              style={{
                boxSizing: "border-box",
                overflow: "hidden",
                width: "100%",
                height: "100%",
                transform: "translate3d(0px, 0px, 0px)",
              }}
            >
              <defs style={{ boxSizing: "border-box" }}>
                <clippath
                  id="__lottie_element_23"
                  style={{ boxSizing: "border-box" }}
                >
                  <rect
                    height="72"
                    width="72"
                    x="0"
                    y="0"
                    style={{ boxSizing: "border-box" }}
                  />
                </clippath>
              </defs>
              <g
                clipPath="url(#__lottie_element_23)"
                style={{ boxSizing: "border-box" }}
              >
                <g
                  opacity="1"
                  transform="matrix(1,0,0,1,36,36)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M16,0 C16,8.836999893188477 8.836999893188477,16 0,16 C-8.836999893188477,16 -16,8.836999893188477 -16,0 C-16,-8.836999893188477 -8.836999893188477,-16 0,-16 C6.456999778747559,-16 12.020999908447266,-12.175000190734863 14.548999786376953,-6.666999816894531"
                      fillOpacity="0"
                      stroke="rgb(25,103,210)"
                      strokeLinecap="butt"
                      strokeLinejoin="miter"
                      strokeMiterlimit="4"
                      strokeOpacity="1"
                      strokeWidth="4"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
                <g
                  opacity="1"
                  transform="matrix(0.9999988675117493,0,0,0.9999988675117493,39.019996643066406,39.66999435424805)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M-2.1449999809265137,-3.369999885559082 C-2.1449999809265137,-3.369999885559082 -5.019999980926514,-1.6699999570846558 -5.019999980926514,-1.6699999570846558 C-5.019999980926514,-1.6699999570846558 3.4800000190734863,3.369999885559082 3.4800000190734863,3.369999885559082 C3.4800000190734863,3.369999885559082 5.019999980926514,0.8100000023841858 5.019999980926514,0.8100000023841858 C5.019999980926514,0.8100000023841858 -2.1449999809265137,-3.369999885559082 -2.1449999809265137,-3.369999885559082z"
                      fill="rgb(25,103,210)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
                <g
                  opacity="0.99"
                  transform="matrix(0.9999995231628418,0,0,0.9999995231628418,35.5,33.000003814697266)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M1.5,-5 C1.5,-5 -1.5,-5 -1.5,-5 C-1.5,-5 -1.5,5 -1.5,5 C-1.5,5 1.5,4.955999851226807 1.5,4.955999851226807 C1.5,4.955999851226807 1.5,-5 1.5,-5z"
                      fill="rgb(25,103,210)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
                <g
                  opacity="1"
                  transform="matrix(0.9999986290931702,0,0,0.9999986290931702,36.00001525878906,35.99998474121094)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M18,-4 C18,-4 18,-18 18,-18 C18,-18 4,-4 4,-4 C4,-4 18,-4 18,-4z"
                      fill="rgb(25,103,210)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
              </g>
            </svg>
          </div>
          <span
            className="chr-heading-pill__pill-text"
            style={{
              boxSizing: "border-box",
              overflow: "hidden",
              whiteSpace: "nowrap",
              display: "inline-flex",
              maxHeight: "4.5rem",
              fontSize: "3.25rem",
              paddingRight: "32px",
            }}
          >
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "20ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"u"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "40ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"p"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "60ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"d"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "80ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"a"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "100ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"t"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "120ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"e"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "140ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"s"}
            </span>
          </span>
        </span>
        {"from Chrome"}
      </h2>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
