import React from "react";

export default function CenterText2() {
  return (
    <>
      <ul
        className="chr-gallery__container chr-grid-default"
        style={{
          boxSizing: "border-box",
          margin: "0px",
          padding: "0px",
          display: "grid",
          columnGap: "64px",
          gridTemplateColumns: "repeat(12, 1fr)",
          rowGap: "40px",
        }}
      >
        <li
          className="chr-gallery-card chr-gallery-card--static chr-gallery-card--light-blue-01"
          style={{
            boxSizing: "border-box",
            listStyle: "none",
            margin: "0px",
            padding: "0px",
            borderRadius: "24px",
            overflow: "hidden",
            transition: "background-color 200ms ease-out",
            opacity: 1,
            position: "relative",
            backgroundColor: "rgb(232, 240, 254)",
            maxHeight: "40rem",
            maxWidth: "initial",
            gridColumn: "span 6",
          }}
        >
          <div
            className="chr-gallery-card-cover chr-gallery-card-cover--static chr-gallery-card-cover--light-blue-01"
            style={{
              boxSizing: "border-box",
              display: "flex",
              WebkitBoxOrient: "vertical",
              WebkitBoxDirection: "normal",
              flexDirection: "column",
              WebkitBoxPack: "justify",
              justifyContent: "space-between",
              position: "relative",
              width: "100%",
              container: "card / inline-size",
              minHeight: "640px",
            }}
          >
            <div
              className="chr-gallery-card-cover__text-wrapper"
              style={{
                boxSizing: "border-box",
                gap: "16px",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                padding: "40px 64px",
              }}
            >
              <h2
                className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  fontSize: "0.875rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0.03125rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  textTransform: "uppercase",
                  color: "rgb(95, 99, 104)",
                }}
              >
                {"Updates"}
              </h2>
              <h3
                className="chr-headline-2 chr-gallery-card-cover__heading"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 700,
                  fontSize: "48px",
                  letterSpacing: "-1px",
                  lineHeight: "56px",
                }}
              >
                {"Automatic updates"}
              </h3>
              <div
                className="chr-gallery-card-cover__body-wrapper"
                style={{ boxSizing: "border-box" }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-cover__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "There’s a new Chrome release every four weeks, making it easy to have the newest features and a faster, safer web browser."
                  }
                </p>
                <a
                  className="chr-link chr-link--primary chr-link--internal chr-gallery-card-cover__link"
                  href="https://www.google.com/intl/en_in/chrome/update/"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(25, 103, 210)",
                    marginTop: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn about automatic updates"}
                </a>
              </div>
            </div>
            <div
              className="chr-gallery-card-cover__image-wrapper"
              style={{
                boxSizing: "border-box",
                borderRadius: "0px 0px 24px 24px",
                flex: "1 1 0%",
                overflow: "hidden",
                WebkitBoxAlign: "stretch",
                alignItems: "stretch",
                display: "flex",
                WebkitBoxFlex: "1",
                position: "relative",
              }}
            >
              <img
                alt="A section of an abstract UI shows that Chrome is ready to be updated."
                src="https://www.google.com/chrome/static/images/engagement-homepage/updates/updates.png"
                srcSet="/chrome/static/images/engagement-homepage/updates/updates.png, /chrome/static/images/engagement-homepage/updates/updates-2x.png 2x"
                style={{
                  boxSizing: "border-box",
                  borderStyle: "none",
                  display: "block",
                  height: "auto",
                  minHeight: "100%",
                  objectFit: "cover",
                  width: "100%",
                }}
              />
            </div>
          </div>
        </li>
        <li
          className="chr-gallery-card chr-gallery-card--static chr-gallery-card--light-yellow"
          style={{
            boxSizing: "border-box",
            listStyle: "none",
            margin: "0px",
            padding: "0px",
            borderRadius: "24px",
            overflow: "hidden",
            transition: "background-color 200ms ease-out",
            opacity: 1,
            position: "relative",
            backgroundColor: "rgb(254, 247, 224)",
            maxHeight: "40rem",
            maxWidth: "initial",
            gridColumn: "span 6",
          }}
        >
          <div
            className="chr-gallery-card-cover chr-gallery-card-cover--static chr-gallery-card-cover--light-yellow"
            style={{
              boxSizing: "border-box",
              display: "flex",
              WebkitBoxOrient: "vertical",
              WebkitBoxDirection: "normal",
              flexDirection: "column",
              WebkitBoxPack: "justify",
              justifyContent: "space-between",
              position: "relative",
              width: "100%",
              container: "card / inline-size",
              minHeight: "640px",
            }}
          >
            <div
              className="chr-gallery-card-cover__text-wrapper"
              style={{
                boxSizing: "border-box",
                gap: "16px",
                display: "flex",
                WebkitBoxOrient: "vertical",
                WebkitBoxDirection: "normal",
                flexDirection: "column",
                padding: "40px 64px",
              }}
            >
              <h2
                className="chr-eyebrow chr-gallery-card-cover__eyebrow"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  fontSize: "0.875rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0.03125rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  textTransform: "uppercase",
                  color: "rgb(95, 99, 104)",
                }}
              >
                {"Latest"}
              </h2>
              <h3
                className="chr-headline-2 chr-gallery-card-cover__heading"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 700,
                  fontSize: "48px",
                  letterSpacing: "-1px",
                  lineHeight: "56px",
                }}
              >
                {"New from Chrome"}
              </h3>
              <div
                className="chr-gallery-card-cover__body-wrapper"
                style={{ boxSizing: "border-box" }}
              >
                <p
                  className="chr-copy-xl chr-gallery-card-cover__body"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    letterSpacing: "0rem",
                    color: "rgb(95, 99, 104)",
                    fontFamily: '"Google Sans Text", arial, sans-serif',
                    fontSize: "1.125rem",
                    lineHeight: "1.75rem",
                  }}
                >
                  {
                    "Chrome regularly updates with tools and features that make it faster and easier to use."
                  }
                </p>
                <a
                  className="chr-link chr-link--primary chr-link--external chr-gallery-card-cover__link"
                  href="https://www.google.com/chrome/whats-new/latest"
                  rel="noopener"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    padding: "12px 0px",
                    letterSpacing: "0rem",
                    display: "inline-block",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    color: "rgb(25, 103, 210)",
                    marginTop: "8px",
                    fontSize: "1.125rem",
                    lineHeight: "1.5rem",
                  }}
                >
                  {"Learn what’s new on"}
                  <span
                    className="chr-link-icon"
                    style={{
                      boxSizing: "border-box",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "inline-flex",
                      flexWrap: "nowrap",
                    }}
                  >
                    {"Chrome"}
                    <svg
                      className="chr-link__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        transition:
                          "transform 0.1s linear, -webkit-transform 0.1s linear",
                        height: "16px",
                        marginLeft: "6px",
                        verticalAlign: "middle",
                        width: "16px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </span>
                </a>
              </div>
            </div>
            <div
              className="chr-gallery-card-cover__image-wrapper chr-gallery-card-cover__image-wrapper--lottie"
              style={{
                boxSizing: "border-box",
                borderRadius: "0px 0px 24px 24px",
                flex: "1 1 0%",
                overflow: "hidden",
                WebkitBoxAlign: "stretch",
                alignItems: "stretch",
                display: "flex",
                WebkitBoxFlex: "1",
                position: "relative",
              }}
            >
              <div
                className="chr-gallery-card-cover__lottie-wrapper"
                aria-hidden="true"
                style={{
                  boxSizing: "border-box",
                  flex: "1 1 0%",
                  WebkitBoxFlex: "1",
                  position: "absolute",
                  top: "0px",
                  width: "100%",
                }}
              >
                <div
                  className="chr-lottie-animation chr-gallery-card-cover__lottie"
                  style={{ boxSizing: "border-box" }}
                >
                  <svg
                    height="360"
                    width="640"
                    preserveAspectRatio="xMidYMid meet"
                    viewBox="0 0 640 360"
                    xmlns="http://www.w3.org/2000/svg"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      width: "100%",
                      height: "100%",
                      transform: "translate3d(0px, 0px, 0px)",
                    }}
                  >
                    <defs style={{ boxSizing: "border-box" }}>
                      <clippath
                        id="__lottie_element_36"
                        style={{ boxSizing: "border-box" }}
                      >
                        <rect
                          height="360"
                          width="640"
                          x="0"
                          y="0"
                          style={{ boxSizing: "border-box" }}
                        />
                      </clippath>
                      <clippath
                        id="__lottie_element_38"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d="M0,0 L1280,0 L1280,720 L0,720z"
                          style={{ boxSizing: "border-box" }}
                        />
                      </clippath>
                      <clippath
                        id="__lottie_element_42"
                        style={{ boxSizing: "border-box" }}
                      >
                        <path
                          d="M0,0 L93,0 L93,83 L0,83z"
                          style={{ boxSizing: "border-box" }}
                        />
                      </clippath>
                      <lineargradient
                        id="__lottie_element_48"
                        gradientUnits="userSpaceOnUse"
                        spreadMethod="pad"
                        x1="-24.993999481201172"
                        x2="23.6299991607666"
                        y1="-163.27499389648438"
                        y2="-163.27499389648438"
                        style={{ boxSizing: "border-box" }}
                      >
                        <stop
                          offset="0%"
                          stopColor="rgb(217,48,37)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="50%"
                          stopColor="rgb(225,57,45)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="100%"
                          stopColor="rgb(234,67,53)"
                          style={{ boxSizing: "border-box" }}
                        />
                      </lineargradient>
                      <lineargradient
                        id="__lottie_element_55"
                        gradientUnits="userSpaceOnUse"
                        spreadMethod="pad"
                        x1="13.145999908447266"
                        x2="-23.22800064086914"
                        y1="-114.31099700927734"
                        y2="-93.31099700927734"
                        style={{ boxSizing: "border-box" }}
                      >
                        <stop
                          offset="0%"
                          stopColor="rgb(30,142,62)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="50%"
                          stopColor="rgb(41,155,72)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="100%"
                          stopColor="rgb(52,168,83)"
                          style={{ boxSizing: "border-box" }}
                        />
                      </lineargradient>
                      <lineargradient
                        id="__lottie_element_59"
                        gradientUnits="userSpaceOnUse"
                        spreadMethod="pad"
                        x1="-18.361000061035156"
                        x2="6.270999908447266"
                        y1="-107.3239974975586"
                        y2="-64.65899658203125"
                        style={{ boxSizing: "border-box" }}
                      >
                        <stop
                          offset="0%"
                          stopColor="rgb(252,201,52)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="50%"
                          stopColor="rgb(251,195,28)"
                          style={{ boxSizing: "border-box" }}
                        />
                        <stop
                          offset="100%"
                          stopColor="rgb(251,188,4)"
                          style={{ boxSizing: "border-box" }}
                        />
                      </lineargradient>
                    </defs>
                    <g
                      clipPath="url(#__lottie_element_36)"
                      style={{ boxSizing: "border-box" }}
                    >
                      <g
                        clipPath="url(#__lottie_element_38)"
                        opacity="1"
                        transform="matrix(0.5,0,0,0.5,0,0)"
                        style={{ boxSizing: "border-box", display: "block" }}
                      >
                        <g
                          clipPath="url(#__lottie_element_42)"
                          opacity="1"
                          transform="matrix(5.849999904632568,-0.0000017048688505383325,0.0000017048688505383325,5.849999904632568,706.9749755859375,222.22508239746094)"
                          style={{ boxSizing: "border-box", display: "block" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,45.89899826049805,41.39899826049805)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0.10100000351667404,-0.39899998903274536)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M0,-20.850500106811523 C11.507390975952148,-20.850500106811523 20.850500106811523,-11.507390975952148 20.850500106811523,0 C20.850500106811523,11.507390975952148 11.507390975952148,20.850500106811523 0,20.850500106811523 C-11.507390975952148,20.850500106811523 -20.850500106811523,11.507390975952148 -20.850500106811523,0 C-20.850500106811523,-11.507390975952148 -11.507390975952148,-20.850500106811523 0,-20.850500106811523z"
                                fill="rgb(255,255,255)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,61.361000061035156,46.67599868774414)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-1.9119999408721924,0.012000000104308128 C-1.9119999408721924,0.012000000104308128 -14.347999572753906,21.551000595092773 -14.347999572753906,21.551000595092773 C-9.303000450134277,21.555999755859375 -4.3460001945495605,20.229999542236328 0.024000000208616257,17.708999633789062 C4.394000053405762,15.187000274658203 8.022000312805176,11.557999610900879 10.543000221252441,7.188000202178955 C13.064000129699707,2.816999912261963 14.387999534606934,-2.1410000324249268 14.381999969482422,-7.185999870300293 C14.376999855041504,-12.230999946594238 13.041999816894531,-17.18600082397461 10.51099967956543,-21.551000595092773 C10.51099967956543,-21.551000595092773 -14.362000465393066,-21.551000595092773 -14.362000465393066,-21.551000595092773 C-14.362000465393066,-21.551000595092773 -14.381999969482422,-21.538999557495117 -14.381999969482422,-21.538999557495117 C-11.857000350952148,-21.547000885009766 -9.37399959564209,-20.888999938964844 -7.184000015258789,-19.631000518798828 C-4.99399995803833,-18.371999740600586 -3.174999952316284,-16.55900001525879 -1.909999966621399,-14.373000144958496 C-0.6449999809265137,-12.187000274658203 0.020999999716877937,-9.706000328063965 0.019999999552965164,-7.179999828338623 C0.019999999552965164,-4.65500020980835 -0.6470000147819519,-2.1740000247955322 -1.9119999408721924,0.012000000104308128 C-1.9119999408721924,0.012000000104308128 -1.9119999408721924,0.012000000104308128 -1.9119999408721924,0.012000000104308128z"
                                fill="url(#__lottie_element_59)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,38.854000091552734,46.68899917602539)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-4.302000045776367,-0.0010000000474974513 C-4.302000045776367,-0.0010000000474974513 -16.738000869750977,-21.540000915527344 -16.738000869750977,-21.540000915527344 C-19.264999389648438,-17.17300033569336 -20.594999313354492,-12.217000007629395 -20.59600067138672,-7.171999931335449 C-20.597000122070312,-2.127000093460083 -19.26799964904785,2.8299999237060547 -16.743999481201172,7.197999954223633 C-14.218999862670898,11.565999984741211 -10.588000297546387,15.192999839782715 -6.216000080108643,17.709999084472656 C-1.843999981880188,20.22800064086914 3.115000009536743,21.54800033569336 8.15999984741211,21.538999557495117 C8.15999984741211,21.538999557495117 20.59600067138672,-0.0010000000474974513 20.59600067138672,-0.0010000000474974513 C20.59600067138672,-0.0010000000474974513 20.59600067138672,-0.02500000037252903 20.59600067138672,-0.02500000037252903 C19.34000015258789,2.1659998893737793 17.52899932861328,3.986999988555908 15.343999862670898,5.255000114440918 C13.15999984741211,6.521999835968018 10.678999900817871,7.190999984741211 8.154000282287598,7.192999839782715 C5.627999782562256,7.196000099182129 3.1470000743865967,6.5329999923706055 0.9599999785423279,5.269999980926514 C-1.2269999980926514,4.00600004196167 -3.0420000553131104,2.187000036239624 -4.302000045776367,-0.0010000000474974513 C-4.302000045776367,-0.0010000000474974513 -4.302000045776367,-0.0010000000474974513 -4.302000045776367,-0.0010000000474974513z"
                                fill="url(#__lottie_element_55)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,47.000999450683594,39.5)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-0.0010000000474974513,11.380000114440918 C6.283999919891357,11.380000114440918 11.380999565124512,6.284999847412109 11.380999565124512,0 C11.380999565124512,-6.284999847412109 6.283999919891357,-11.380000114440918 -0.0010000000474974513,-11.380000114440918 C-6.285999774932861,-11.380000114440918 -11.380999565124512,-6.284999847412109 -11.380999565124512,0 C-11.380999565124512,6.284999847412109 -6.285999774932861,11.380000114440918 -0.0010000000474974513,11.380000114440918z"
                                fill="rgb(26,115,232)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,46.99399948120117,28.724000930786133)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M0.007000000216066837,-3.5999999046325684 C0.007000000216066837,-3.5999999046325684 24.878999710083008,-3.5999999046325684 24.878999710083008,-3.5999999046325684 C22.360000610351562,-7.9720001220703125 18.733999252319336,-11.60200023651123 14.364999771118164,-14.12600040435791 C9.996000289916992,-16.649999618530273 5.039000034332275,-17.976999282836914 -0.006000000052154064,-17.975000381469727 C-5.052000045776367,-17.972999572753906 -10.006999969482422,-16.641000747680664 -14.37399959564209,-14.11299991607666 C-18.740999221801758,-11.586000442504883 -22.36400032043457,-7.951000213623047 -24.878999710083008,-3.5769999027252197 C-24.878999710083008,-3.5769999027252197 -12.442000389099121,17.96299934387207 -12.442000389099121,17.96299934387207 C-12.442000389099121,17.96299934387207 -12.420999526977539,17.975000381469727 -12.420999526977539,17.975000381469727 C-13.690999984741211,15.791999816894531 -14.362000465393066,13.312000274658203 -14.368000030517578,10.78600025177002 C-14.373000144958496,8.26099967956543 -13.711999893188477,5.7779998779296875 -12.451000213623047,3.5899999141693115 C-11.190999984741211,1.4019999504089355 -9.375,-0.41600000858306885 -7.186999797821045,-1.6779999732971191 C-5,-2.940000057220459 -2.5179998874664307,-3.6029999256134033 0.007000000216066837,-3.5999999046325684 C0.007000000216066837,-3.5999999046325684 0.007000000216066837,-3.5999999046325684 0.007000000216066837,-3.5999999046325684z"
                                fill="url(#__lottie_element_48)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </g>
                      </g>
                    </g>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,

        }}
      />
    </>
  );
}
