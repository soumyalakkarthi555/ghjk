import React from "react";

export default function Adjacent3() {
  return (
    <>
      <div
        className="chr-mosaic__image-container"
        style={{
          boxSizing: "border-box",
          transition: "opacity 0.85s ease-in-out",
          animationDuration: "0.85s",
          animationFillMode: "forwards",
          animationTimingFunction: "ease-out",
          willChange: "transform, opacity",
          opacity: 1,
          animationName: "animate-in-bottom",
        }}
      >
        <img
          aria-hidden="true"
          src="https://www.google.com/chrome/static/images/dev-components/chrome-gallery-3.webp"
          srcSet="/chrome/static/images/dev-components/chrome-gallery-3.webp, /chrome/static/images/dev-components/chrome-gallery-3-2x.webp 2x"
          style={{
            boxSizing: "border-box",
            borderStyle: "none",
            display: "block",
            height: "424px",
          }}
        />
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
