import React from "react";

export default function Textabove1
() {
  return (
    <>
      <h2
        className="chr-headline-1"
        aria-label="Stay safe while you browse"
        style={{
          boxSizing: "border-box",
          margin: "0px",
          color: "rgb(32, 33, 36)",
          fontFamily: '"Google Sans", arial, sans-serif',
          fontWeight: 700,
          fontSize: "3.75rem",
          lineHeight: "4.5rem",
          letterSpacing: "-0.078125rem",
          textAlign: "center",
        }}
      >
        {"Stay"}
        <span
          className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--blue chr-heading-pill__pill-container--medium animated"
          aria-hidden="true"
          style={{
            boxSizing: "border-box",
            overflow: "hidden",
            position: "relative",
            textAlign: "center",
            borderRadius: "48px",
            display: "inline-flex",
            WebkitBoxOrient: "horizontal",
            WebkitBoxDirection: "normal",
            flexDirection: "row",
            backgroundColor: "rgb(232, 240, 254)",
            color: "rgb(25, 103, 210)",
            WebkitBoxAlign: "center",
            alignItems: "center",
            transform: "none",
            animationFillMode: "both",
            animationTimingFunction: "ease-in-out",
            lineHeight: "4.5rem",
          }}
        >
          <span
            className="chr-heading-pill__mock"
            style={{ boxSizing: "border-box", height: "40px" }}
          />
          <div
            className="chr-lottie-animation chr-heading-pill__icon"
            style={{
              boxSizing: "border-box",
              display: "inline-flex",
              flexShrink: 0,
              marginLeft: "8px",
              height: "72px",
              width: "72px",
            }}
          >
            <svg
              height="72"
              width="72"
              preserveAspectRatio="xMidYMid meet"
              viewBox="0 0 72 72"
              xmlns="http://www.w3.org/2000/svg"
              style={{
                boxSizing: "border-box",
                overflow: "hidden",
                width: "100%",
                height: "100%",
                transform: "translate3d(0px, 0px, 0px)",
              }}
            >
              <defs style={{ boxSizing: "border-box" }}>
                <clippath
                  id="__lottie_element_84"
                  style={{ boxSizing: "border-box" }}
                >
                  <rect
                    height="72"
                    width="72"
                    x="0"
                    y="0"
                    style={{ boxSizing: "border-box" }}
                  />
                </clippath>
              </defs>
              <g
                clipPath="url(#__lottie_element_84)"
                style={{ boxSizing: "border-box" }}
              >
                <g
                  opacity="1"
                  transform="matrix(1,0,0,1,36,36)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M15.619999885559082,-15.246999740600586 C17.059999465942383,-14.607000350952148 18,-13.166999816894531 18,-11.586999893188477 C18,-11.586999893188477 18,-2.187999963760376 18,-2.187999963760376 C18,2.572000026702881 15.619999885559082,9.885000228881836 11.760000228881836,14.392999649047852 C8.65999984741211,18.01300048828125 4.599999904632568,20.691999435424805 0,21.812000274658203 C-10.319999694824219,19.29199981689453 -18,8.911999702453613 -18,-2.187999963760376 C-18,-2.187999963760376 -18,-11.586999893188477 -18,-11.586999893188477 C-18,-13.166999816894531 -17.059999465942383,-14.607000350952148 -15.619999885559082,-15.246999740600586 C-15.619999885559082,-15.246999740600586 -1.6200000047683716,-21.466999053955078 -1.6200000047683716,-21.466999053955078 C-0.6000000238418579,-21.927000045776367 0.5799999833106995,-21.927000045776367 1.6200000047683716,-21.466999053955078 C1.6200000047683716,-21.466999053955078 15.619999885559082,-15.246999740600586 15.619999885559082,-15.246999740600586z"
                      fill="rgb(25,103,210)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
                <g
                  opacity="1"
                  transform="matrix(0.9999997615814209,0,0,0.9999997615814209,32.00000762939453,35.81200408935547)"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,0,0)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M10,0 C10,3.313999891281128 7.314000129699707,6 4,6 C0.6859999895095825,6 -2,3.313999891281128 -2,0 C-2,-3.313999891281128 0.6859999895095825,-6 4,-6 C7.314000129699707,-6 10,-3.313999891281128 10,0z M9.515000343322754,8.343000411987305 C7.934000015258789,9.390000343322754 6.038000106811523,10 4,10 C-1.5230000019073486,10 -6,5.5229997634887695 -6,0 C-6,-5.5229997634887695 -1.5230000019073486,-10 4,-10 C9.52299976348877,-10 14,-5.5229997634887695 14,0 C14,2.0380001068115234 13.390000343322754,3.934000015258789 12.343000411987305,5.514999866485596 C12.343000411987305,5.514999866485596 18.913999557495117,12.086000442504883 18.913999557495117,12.086000442504883 C19.69499969482422,12.866999626159668 19.69499969482422,14.133000373840332 18.913999557495117,14.913999557495117 C18.132999420166016,15.694999694824219 16.867000579833984,15.694999694824219 16.086000442504883,14.913999557495117 C16.086000442504883,14.913999557495117 9.515000343322754,8.343000411987305 9.515000343322754,8.343000411987305z"
                      fill="rgb(255,255,255)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                  <g
                    opacity="1"
                    transform="matrix(1,0,0,1,3.997999906539917,-0.014999999664723873)"
                    style={{ boxSizing: "border-box" }}
                  >
                    <path
                      d=" M0,6 C3.313999891281128,6 6,3.313999891281128 6,0 C6,-3.313999891281128 3.313999891281128,-6 0,-6 C-3.313999891281128,-6 -6,-3.313999891281128 -6,0 C-6,3.313999891281128 -3.313999891281128,6 0,6z"
                      fill="rgb(25,103,210)"
                      fillOpacity="1"
                      style={{ boxSizing: "border-box" }}
                    />
                  </g>
                </g>
              </g>
            </svg>
          </div>
          <span
            className="chr-heading-pill__pill-text"
            style={{
              boxSizing: "border-box",
              overflow: "hidden",
              whiteSpace: "nowrap",
              display: "inline-flex",
              maxHeight: "4.5rem",
              fontSize: "3.25rem",
              paddingRight: "32px",
            }}
          >
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "20ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"s"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "40ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"a"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "60ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"f"}
            </span>
            <span
              className="chr-heading-pill__pill-char"
              style={{
                boxSizing: "border-box",
                fontWeight: 500,
                animationDelay: "80ms",
                animationDuration: ".7s",
                animationFillMode: "both",
                animationName: "charBounceSlideInUp",
                animationTimingFunction: "ease-in-out",
                visibility: "visible",
              }}
            >
              {"e"}
            </span>
          </span>
        </span>
        <br style={{ boxSizing: "border-box" }} />
        while you browse{" "}
      </h2>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
