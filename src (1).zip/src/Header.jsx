import React from "react";

export default function Component() {
  return (
    <>
      <div
        id="js-header"
        className="chr-header-v3 chr-header-v3--hide-on-scroll-up-mobile chr-header-v3--hide-on-scroll-up-tablet chr-header-v3--hide-on-scroll-up-desktop cta--hidden"
        role="banner"
        style={{
          boxSizing: "border-box",
          fontSize: "1rem",
          lineHeight: "1.5rem",
          left: "0px",
          position: "fixed",
          right: "0px",
          top: "0px",
          zIndex: 100,
          transition: "transform 0.4s ease-in, -webkit-transform 0.4s ease-in",
          willChange: "transform",
        }}
      >
        <div
          className="chr-header-v3__wrapper shadow-elevation-1"
          style={{
            boxSizing: "border-box",
            boxShadow: "rgba(32, 33, 36, 0.08) 0px 2px 8px 0px",
            backgroundColor: "rgb(255, 255, 255)",
            WebkitBoxAlign: "center",
            alignItems: "center",
            display: "flex",
            flexWrap: "wrap",
            height: "64px",
            position: "relative",
            zIndex: -1,
            transition:
              "transform 0.4s, background 0.4s, -webkit-transform 0.4s",
            transform: "translate3d(0px, 0px, 0px)",
          }}
        >
          <div
            className="chr-header-v3__hamburger"
            style={{
              boxSizing: "border-box",
              height: "100%",
              width: "64px",
              display: "none",
            }}
          >
            <div
              id="js-hamburger-button"
              className="chr-header-v3__hamburger-wrapper"
              style={{
                boxSizing: "border-box",
                padding: "12px",
                display: "table-cell",
                height: "100%",
                verticalAlign: "middle",
              }}
            >
              <button
                className="chr-header-v3__hamburger-button"
                type="button"
                aria-controls="js-header__drawer"
                aria-expanded="false"
                aria-label="Open the navigation drawer"
                role="button"
                tabIndex="0"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  textTransform: "none",
                  border: "none",
                  background: "none",
                  borderRadius: "50%",
                  font: "inherit",
                  overflow: "visible",
                  padding: "0px",
                  color: "inherit",
                  display: "block",
                  fontSize: "inherit",
                  lineHeight: "inherit",
                  fontFamily: "inherit",
                  height: "100%",
                  position: "relative",
                  userSelect: "none",
                  width: "100%",
                  cursor: "pointer",
                  appearance: "button",
                }}
              >
                <svg
                  className="chr-header-v3__hamburger-icon chr-header-v3__hamburger-icon--standard"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px auto",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    fill: "rgb(32, 33, 36)",
                    display: "block",
                  }}
                >
                  <title style={{ boxSizing: "border-box" }}>Menu</title>
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#hamburger"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
                <svg
                  className="chr-header-v3__hamburger-icon chr-header-v3__hamburger-icon--reversed"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px auto",
                    height: "24px",
                    width: "24px",
                    overflow: "hidden",
                    display: "none",
                  }}
                >
                  <title style={{ boxSizing: "border-box" }}>Menu</title>
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#hamburger"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </button>
            </div>
          </div>
          <div
            className="chr-header-v3__lockup"
            style={{
              boxSizing: "border-box",
              position: "relative",
              marginLeft: "12px",
            }}
          >
            <div
              className="chr-header-v3__logo"
              style={{ boxSizing: "border-box", height: "100%" }}
            >
              <a
                className="chr-header-v3__logo-link"
                href="https://www.google.com/intl/en_in/chrome/"
                tabIndex="0"
                title="Google Chrome"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  padding: "0px 8px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  height: "48px",
                  fontSize: "1.375rem",
                  lineHeight: "2rem",
                  borderRadius: "4px",
                }}
              >
                <svg
                  className="chr-header-v3__logo-icon"
                  style={{
                    boxSizing: "border-box",
                    height: "36px",
                    minHeight: "36px",
                    width: "134px",
                    overflow: "hidden",
                  }}
                >
                  <defs style={{ boxSizing: "border-box" }}>
                    <lineargradient
                      id="linear-gradient"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="23.9"
                      x2="5.15"
                      y1="1076.02"
                      y2="1043.54"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#1e8e3e"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#34a853"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                    <lineargradient
                      id="linear-gradient-2"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="18.32"
                      x2="37.07"
                      y1="1077.42"
                      y2="1044.93"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#fcc934"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#fbbc04"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                    <lineargradient
                      id="linear-gradient-3"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="2.87"
                      x2="40.19"
                      y1="1047.56"
                      y2="1047.56"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#d93025"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#ea4335"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                  </defs>
                  <title style={{ boxSizing: "border-box" }}>
                    icon chrome logo
                  </title>
                  <use
                    xlinkHref="#color-google-logo-2023"
                    style={{ boxSizing: "border-box" }}
                  />
                  <image
                    className="svg-fallback"
                    height="36"
                    width="134"
                    alt="Google Chrome"
                    src="/chrome/static/images/fallback/chrome-logo-2023.png"
                    style={{ boxSizing: "border-box", display: "none" }}
                  />
                </svg>
              </a>
            </div>
            <a
              className="chr-header-v3__jump-to-content"
              href="https://www.google.com/chrome/index.html#jump-content"
              style={{
                boxSizing: "border-box",
                textDecoration: "none",
                borderRadius: "4px",
                overflow: "hidden",
                padding: "10px",
                whiteSpace: "nowrap",
                backgroundColor: "rgb(255, 255, 255)",
                color: "rgb(32, 33, 36)",
                clip: "rect(1px, 1px, 1px, 1px)",
                fontFamily: '"Google Sans", arial, sans-serif',
                fontSize: "16px",
                fontWeight: 500,
                left: "80%",
                lineHeight: "24px",
                position: "absolute",
                top: "40px",
                zIndex: 103,
                display: "block",
              }}
            >
              <span
                className="chr-header-v3__jump-to-content-text"
                style={{ boxSizing: "border-box" }}
              >
                Jump to content
              </span>
            </a>
          </div>
          <nav
            className="chr-header-v3__nav"
            aria-hidden="false"
            aria-label="navigation menu"
            style={{
              boxSizing: "border-box",
              display: "block",
              height: "100%",
              marginLeft: "40px",
              maxWidth: "100%",
            }}
          >
            <ul
              className="chr-header-v3__nav-list"
              aria-label="Navigation drawer"
              role="menu"
              style={{
                boxSizing: "border-box",
                listStyle: "none",
                padding: "0px",
                margin: "0px",
                WebkitBoxAlign: "center",
                alignItems: "center",
                display: "flex",
                overflow: "unset",
                height: "100%",
              }}
            >
              <li
                className="chr-header-v3__nav-li selected-link"
                role="menuitem"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  height: "64px",
                  minWidth: "max-content",
                  position: "relative",
                }}
              >
                <a
                  className="chr-header-v3__nav-li-link chr-link--nav chr-link-first-level"
                  aria-label="home"
                  href="https://www.google.com/intl/en_in/chrome/"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    maxWidth: "100%",
                    padding: "0px 12px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "flex",
                    height: "46px",
                    width: "100%",
                    borderRadius: "4px",
                    transition: "background-color 0.3s, color 0.3s",
                    color: "rgb(32, 33, 36)",
                  }}
                >
                  Home
                </a>
              </li>
              <li
                className="chr-header-v3__nav-li"
                role="menuitem"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  height: "64px",
                  minWidth: "max-content",
                  position: "relative",
                }}
              >
                <a
                  className="chr-header-v3__nav-li-link chr-link--nav chr-link-first-level"
                  aria-label="the browser by google"
                  href="https://www.google.com/intl/en_in/chrome/browser-tools/"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    textDecoration: "none",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    maxWidth: "100%",
                    padding: "0px 12px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "flex",
                    height: "46px",
                    width: "100%",
                    color: "rgb(95, 99, 104)",
                    borderRadius: "4px",
                    transition: "background-color 0.3s, color 0.3s",
                  }}
                >
                  The Browser by Google
                </a>
              </li>
              <li
                className="js-main-nav chr-header-v3__nav-li"
                aria-hidden="false"
                role="menuitem"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  height: "64px",
                  minWidth: "max-content",
                  position: "relative",
                }}
              >
                <button
                  className="chr-cta__button chr-cta__button-- chr-header-v3__drawer-nav-li chr-link-first-level chr-link--nav js-sub-trigger"
                  type="button"
                  aria-expanded="false"
                  aria-haspopup="true"
                  aria-label="features"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "100%",
                    lineHeight: 1.15,
                    overflow: "visible",
                    textTransform: "none",
                    background: "none",
                    border: "none",
                    margin: "2px 0px",
                    position: "relative",
                    appearance: "button",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    maxWidth: "100%",
                    color: "rgb(95, 99, 104)",
                    padding: "0px 12px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "flex",
                    height: "46px",
                    width: "100%",
                    borderRadius: "4px",
                    transition: "background-color 0.3s, color 0.3s",
                  }}
                >
                  {"Features"}
                  <svg
                    className="chr-icon chr-icon--link chr-icon--18"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      fill: "currentcolor",
                      verticalAlign: "middle",
                      overflow: "hidden",
                      transition: "0.3s",
                      height: "50%",
                      width: "16px",
                      marginLeft: "4px",
                      marginTop: "2px",
                      transform: "none",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }}>
                      icon-expand-features
                    </title>
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </button>
                <ul
                  className="chr-header-v3__nav-sublist shadow-elevation-2"
                  role="menu"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    boxShadow:
                      "rgba(32, 33, 36, 0.15) 0px 1px 2px, rgba(32, 33, 36, 0.08) 0px 1px 8px",
                    border: "1px solid",
                    padding: "6px 0px",
                    WebkitBoxOrient: "vertical",
                    WebkitBoxDirection: "normal",
                    flexDirection: "column",
                    left: "0px",
                    position: "absolute",
                    top: "54px",
                    borderColor: "rgb(255, 255, 255)",
                    borderRadius: "0px 8px 8px",
                    overflow: "hidden",
                    backgroundColor: "rgb(255, 255, 255)",
                    display: "flex",
                    height: "auto",
                    opacity: 0,
                    pointerEvents: "none",
                    width: "max-content",
                    zIndex: -1,
                  }}
                >
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="overview"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Overview
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="google search bar"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#google-search-bar"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Google address bar
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="password check"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#password-check"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Password check
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="Use across devices"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#use-across-devices"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Use across devices
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="dark mode"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#dark-mode"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Dark mode
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="tabs"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#tabs"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Tabs
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="articles for you"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#articles-for-you"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Articles for you
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="extensions"
                      href="https://www.google.com/intl/en_in/chrome/browser-features/#extensions"
                      tabIndex="-1"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Extensions
                    </a>
                  </li>
                </ul>
              </li>
              <li
                className="js-main-nav chr-header-v3__nav-li"
                aria-hidden="false"
                role="menuitem"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  margin: "0px",
                  padding: "0px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  height: "64px",
                  minWidth: "max-content",
                  position: "relative",
                }}
              >
                <button
                  className="chr-cta__button chr-cta__button-- chr-header-v3__drawer-nav-li chr-link-first-level chr-link--nav js-sub-trigger js-drawer-focus-trap"
                  type="button"
                  aria-expanded="false"
                  aria-haspopup="true"
                  aria-label="support"
                  style={{
                    boxSizing: "border-box",
                    fontSize: "100%",
                    lineHeight: 1.15,
                    overflow: "visible",
                    textTransform: "none",
                    background: "none",
                    border: "none",
                    margin: "2px 0px",
                    position: "relative",
                    appearance: "button",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontWeight: 500,
                    maxWidth: "100%",
                    color: "rgb(95, 99, 104)",
                    padding: "0px 12px",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "flex",
                    height: "46px",
                    width: "100%",
                    borderRadius: "4px",
                    transition: "background-color 0.3s, color 0.3s",
                  }}
                >
                  {"Support"}
                  <svg
                    className="chr-icon chr-icon--link chr-icon--18"
                    aria-hidden="true"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-block",
                      fill: "currentcolor",
                      verticalAlign: "middle",
                      overflow: "hidden",
                      transition: "0.3s",
                      height: "50%",
                      width: "16px",
                      marginLeft: "4px",
                      marginTop: "2px",
                      transform: "none",
                    }}
                  >
                    <title style={{ boxSizing: "border-box" }}>
                      icon-expand-features
                    </title>
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </button>
                <ul
                  className="chr-header-v3__nav-sublist shadow-elevation-2"
                  role="menu"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    boxShadow:
                      "rgba(32, 33, 36, 0.15) 0px 1px 2px, rgba(32, 33, 36, 0.08) 0px 1px 8px",
                    border: "1px solid",
                    padding: "6px 0px",
                    WebkitBoxOrient: "vertical",
                    WebkitBoxDirection: "normal",
                    flexDirection: "column",
                    left: "0px",
                    position: "absolute",
                    top: "54px",
                    borderColor: "rgb(255, 255, 255)",
                    borderRadius: "0px 8px 8px",
                    overflow: "hidden",
                    backgroundColor: "rgb(255, 255, 255)",
                    display: "flex",
                    height: "auto",
                    opacity: 0,
                    pointerEvents: "none",
                    width: "max-content",
                    zIndex: -1,
                  }}
                >
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="tips"
                      href="https://www.google.com/intl/en_in/chrome/tips/"
                      tabIndex="0"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        color: "rgb(95, 99, 104)",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      Helpful tips for Chrome
                    </a>
                  </li>
                  <li
                    className="chr-header-v3__nav-li"
                    aria-hidden="false"
                    role="menuitem"
                    style={{
                      boxSizing: "border-box",
                      listStyle: "none",
                      margin: "0px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      minWidth: "max-content",
                      position: "relative",
                      padding: "0px 8px",
                      height: "46px",
                      marginBottom: "6px",
                    }}
                  >
                    <a
                      className="chr-link chr-link--external js-sub-link chr-header-v3__nav-li-link chr-link--nav"
                      aria-label="support"
                      href="https://support.google.com/chrome?p=chromecom_home&hl=en-GB"
                      rel="noopener"
                      tabIndex="0"
                      target="_blank"
                      style={{
                        boxSizing: "border-box",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        textDecoration: "none",
                        fontSize: "1rem",
                        lineHeight: "1.5rem",
                        letterSpacing: "0rem",
                        fontFamily: '"Google Sans", arial, sans-serif',
                        fontWeight: 500,
                        maxWidth: "100%",
                        color: "rgb(95, 99, 104)",
                        padding: "0px 12px",
                        WebkitBoxAlign: "center",
                        alignItems: "center",
                        cursor: "pointer",
                        display: "flex",
                        height: "46px",
                        width: "100%",
                        borderRadius: "4px",
                        transition: "background-color 0.3s, color 0.3s",
                      }}
                    >
                      {"Support"}
                      <svg
                        className="chr-icon chr-icon--link"
                        aria-hidden="true"
                        style={{
                          boxSizing: "border-box",
                          display: "inline-block",
                          fill: "currentcolor",
                          verticalAlign: "middle",
                          overflow: "hidden",
                          transition: "0.3s",
                          height: "50%",
                          marginLeft: "4px",
                          width: "16px",
                        }}
                      >
                        <use
                          xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                          style={{ boxSizing: "border-box" }}
                        />
                      </svg>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
        <div
          className="cta-container shadow-elevation-1"
          style={{
            boxSizing: "border-box",
            height: "62px",
            position: "fixed",
            visibility: "hidden",
            boxShadow: "none",
            right: "0px",
            width: "auto",
            zIndex: 1,
            padding: "8px",
            backgroundColor: "rgb(255, 255, 255)",
            transition: "none",
            display: "block",
            top: "0px",
          }}
        >
          <div
            className="chr-download-toggle-panel"
            style={{
              boxSizing: "border-box",
              animation: "0s ease 0s 1 normal forwards running hide",
              borderRadius: "24px",
              backgroundColor: "rgb(255, 255, 255)",
              WebkitBoxAlign: "stretch",
              alignItems: "stretch",
              WebkitBoxOrient: "vertical",
              WebkitBoxDirection: "normal",
              flexDirection: "column",
              marginBottom: "16px",
              maxWidth: "min-content",
              opacity: 0,
              display: "none",
            }}
          >
            <div
              className="chr-download-toggle-panel__header"
              style={{
                boxSizing: "border-box",
                WebkitBoxAlign: "center",
                alignItems: "center",
                display: "flex",
                WebkitBoxPack: "end",
                justifyContent: "flex-end",
              }}
            >
              <button
                className="chr-button chr-button--secondary chr-cta chr-download-toggle-panel__cta"
                type="button"
                aria-controls="chr-download-toggle-panel__content"
                aria-expanded="false"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  overflow: "visible",
                  textTransform: "none",
                  background: "none",
                  border: "none",
                  borderRadius: "24px",
                  gap: "8px",
                  padding: "12px 24px",
                  whiteSpace: "nowrap",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  cursor: "pointer",
                  display: "inline-flex",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "normal",
                  flexDirection: "row",
                  height: "auto",
                  WebkitBoxPack: "center",
                  justifyContent: "center",
                  backgroundColor: "rgb(232, 240, 254)",
                  color: "rgb(25, 103, 210)",
                  fontSize: "1rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontWeight: 500,
                  fontFamily: '"Google Sans", arial, sans-serif',
                  appearance: "button",
                }}
              >
                {"Download Chrome"}
                <svg
                  className="chr-button__icon"
                  style={{
                    boxSizing: "border-box",
                    height: "20px",
                    width: "20px",
                    overflow: "hidden",
                    fill: "rgb(25, 103, 210)",
                  }}
                >
                  <use
                    xlinkHref="/chrome/static/images/site-icons.svg#arrow-down"
                    style={{ boxSizing: "border-box" }}
                  />
                </svg>
              </button>
            </div>
            <div
              className="chr-download-toggle-panel__content"
              aria-expanded="false"
              style={{ boxSizing: "border-box", display: "none" }}
            >
              <hr
                className="chr-download-toggle-panel__rule"
                aria-hidden="true"
                style={{
                  overflow: "visible",
                  boxSizing: "content-box",
                  height: "0px",
                  border: "1px solid rgb(218, 220, 224)",
                  margin: "0px auto",
                  width: "85.1163%",
                }}
              />
              <div
                className="chr-download-toggle-panel__body"
                style={{ boxSizing: "border-box", textAlign: "center" }}
              >
                <div
                  className="chr-qr-code"
                  style={{
                    boxSizing: "border-box",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    display: "flex",
                    WebkitBoxOrient: "vertical",
                    WebkitBoxDirection: "normal",
                    flexDirection: "column",
                    textAlign: "center",
                    width: "auto",
                  }}
                >
                  <div
                    className="chr-qr-code__qr-code"
                    style={{ boxSizing: "border-box", padding: "16px 0 8px 0" }}
                  >
                    <img
                      alt="QR code to download chrome browser in mobile devices"
                      src="https://www.google.com/chrome/static/images/campaigns/chrome-download/qr-code.webp"
                      srcSet="/chrome/static/images/campaigns/chrome-download/qr-code.webp, /chrome/static/images/campaigns/chrome-download/qr-code-2x.webp 2x"
                      style={{ boxSizing: "border-box", borderStyle: "none" }}
                    />
                  </div>
                  <div
                    className="chr-copy-xl chr-qr-code__content"
                    style={{
                      boxSizing: "border-box",
                      fontSize: "1.125rem",
                      lineHeight: "1.75rem",
                      letterSpacing: "0rem",
                      color: "rgb(95, 99, 104)",
                      fontFamily: '"Google Sans Text", arial, sans-serif',
                      maxWidth: "140px",
                      padding: "0 0 16px",
                      marginTop: "0px",
                    }}
                  >
                    <p
                      className="chr-caption"
                      style={{
                        boxSizing: "border-box",
                        margin: "0px",
                        fontSize: "0.75rem",
                        lineHeight: "1.125rem",
                        letterSpacing: "0.009375rem",
                        fontFamily: '"Google Sans Text", arial, sans-serif',
                        fontWeight: 400,
                        color: "rgb(32, 33, 36)",
                      }}
                    >
                      {"Scan for the"}
                      <br style={{ boxSizing: "border-box" }} /> Chrome app{" "}
                    </p>
                  </div>
                </div>
              </div>
              <hr
                className="chr-download-toggle-panel__rule chr-download-toggle-panel__rule--full"
                aria-hidden="true"
                style={{
                  overflow: "visible",
                  boxSizing: "content-box",
                  height: "0px",
                  border: "1px solid rgb(218, 220, 224)",
                  margin: "0px",
                  width: "100%",
                }}
              />
              <div
                className="chr-download-toggle-panel__footer"
                style={{
                  boxSizing: "border-box",
                  padding: "16px 17.5px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  WebkitBoxPack: "center",
                  justifyContent: "center",
                }}
              >
                <button
                  id="js-download-header"
                  className="chr-download-button chr-download-button--dropdown js-download show"
                  type="button"
                  style={{
                    boxSizing: "border-box",
                    margin: "0px",
                    lineHeight: 1.15,
                    overflow: "visible",
                    textTransform: "none",
                    background: "none",
                    border: "none",
                    borderRadius: "24px",
                    gap: "8px",
                    whiteSpace: "nowrap",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    cursor: "pointer",
                    display: "inline-flex",
                    fontWeight: 500,
                    height: "auto",
                    WebkitBoxPack: "center",
                    justifyContent: "center",
                    backgroundColor: "rgb(26, 115, 232)",
                    color: "rgb(255, 255, 255)",
                    WebkitBoxOrient: "horizontal",
                    WebkitBoxDirection: "reverse",
                    flexDirection: "row-reverse",
                    padding: "12px 16px",
                    fontFamily: '"Google Sans", arial, sans-serif',
                    fontSize: "0.75rem",
                    appearance: "button",
                  }}
                >
                  {"Download for Desktop"}
                  <svg
                    className="chr-button__icon chr-download-button__icon"
                    style={{
                      boxSizing: "border-box",
                      height: "20px",
                      width: "20px",
                      overflow: "hidden",
                      fill: "rgb(255, 255, 255)",
                    }}
                  >
                    <use
                      xlinkHref="/chrome/static/images/site-icons.svg#download"
                      style={{ boxSizing: "border-box" }}
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div
          id="js-header__drawer"
          className="chr-header-v3__drawer"
          style={{
            boxSizing: "border-box",
            display: "none",
            inset: "0px 58px 0px 0px",
            backgroundColor: "rgb(255, 255, 255)",
            maxWidth: "400px",
            minWidth: "264px",
            position: "fixed",
            transform: "translate3d(-100%, 0px, 0px)",
            visibility: "hidden",
            zIndex: 102,
          }}
        >
          <div
            className="chr-header-v3__drawer-close"
            style={{
              boxSizing: "border-box",
              display: "none",
              height: "34px",
              position: "absolute",
              right: "-48px",
              top: "12px",
              width: "34px",
            }}
          >
            <button
              className="chr-btn-close-drawer"
              type="button"
              aria-controls="js-header__drawer"
              aria-label="close the navigation drawer"
              role="button"
              tabIndex="0"
              style={{
                boxSizing: "border-box",
                margin: "0px",
                fontSize: "100%",
                lineHeight: 1.15,
                overflow: "visible",
                textTransform: "none",
                background: "none",
                border: "none",
                fontFamily: "inherit",
                appearance: "button",
                padding: "0px",
                height: "inherit",
                width: "inherit",
              }}
            >
              <svg
                className="chr-header-v3__drawer-close-icon"
                style={{
                  boxSizing: "border-box",
                  cursor: "pointer",
                  height: "24px",
                  marginTop: "3px",
                  width: "24px",
                  overflow: "hidden",
                }}
              >
                <title style={{ boxSizing: "border-box" }}>close drawer</title>
                <use
                  xlinkHref="/chrome/static/images/site-icons.svg#close-white"
                  style={{ boxSizing: "border-box" }}
                />
              </svg>
            </button>
          </div>
          <div
            className="chr-header-v3__drawer-content"
            style={{
              boxSizing: "border-box",
              inset: "0px",
              overflowY: "auto",
              position: "absolute",
            }}
          >
            <div
              className="chr-header-v3__logo"
              style={{
                boxSizing: "border-box",
                borderBottom: "1px solid rgb(218, 220, 224)",
                height: "64px",
              }}
            >
              <a
                className="chr-header-v3__logo-link"
                href="https://www.google.com/intl/en_in/chrome/"
                tabIndex="0"
                title="Google Chrome"
                style={{
                  boxSizing: "border-box",
                  backgroundColor: "rgba(0, 0, 0, 0)",
                  textDecoration: "none",
                  padding: "0px 8px",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  display: "flex",
                  fontSize: "1.375rem",
                  lineHeight: "2rem",
                  borderRadius: "4px",
                  margin: "8px 20px",
                  height: "48px",
                  position: "absolute",
                }}
              >
                <svg
                  className="chr-header-v3__logo-icon"
                  style={{
                    boxSizing: "border-box",
                    height: "36px",
                    minHeight: "36px",
                    width: "134px",
                    overflow: "hidden",
                  }}
                >
                  <defs style={{ boxSizing: "border-box" }}>
                    <lineargradient
                      id="linear-gradient"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="23.9"
                      x2="5.15"
                      y1="1076.02"
                      y2="1043.54"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#1e8e3e"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#34a853"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                    <lineargradient
                      id="linear-gradient-2"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="18.32"
                      x2="37.07"
                      y1="1077.42"
                      y2="1044.93"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#fcc934"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#fbbc04"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                    <lineargradient
                      id="linear-gradient-3"
                      gradientTransform="translate(0 -1034)"
                      gradientUnits="userSpaceOnUse"
                      x1="2.87"
                      x2="40.19"
                      y1="1047.56"
                      y2="1047.56"
                      style={{ boxSizing: "border-box" }}
                    >
                      <stop
                        offset="0"
                        stopColor="#d93025"
                        style={{ boxSizing: "border-box" }}
                      />
                      <stop
                        offset="1"
                        stopColor="#ea4335"
                        style={{ boxSizing: "border-box" }}
                      />
                    </lineargradient>
                  </defs>
                  <title style={{ boxSizing: "border-box" }}>
                    icon chrome logo
                  </title>
                  <use
                    xlinkHref="#color-google-logo-2023"
                    style={{ boxSizing: "border-box" }}
                  />
                  <image
                    className="svg-fallback"
                    height="36"
                    width="134"
                    alt="Google Chrome"
                    src="/chrome/static/images/fallback/chrome-logo-2023.png"
                    style={{ boxSizing: "border-box", display: "none" }}
                  />
                </svg>
              </a>
            </div>
            <nav
              className="chr-header-v3__drawer-nav"
              style={{ boxSizing: "border-box", display: "block" }}
            >
              <ul
                className="chr-header-v3__drawer-nav-list"
                aria-label="Navigation drawer"
                role="menubar"
                style={{
                  boxSizing: "border-box",
                  listStyle: "none",
                  padding: "0px",
                  inset: "64px 0px 88px",
                  margin: "0px",
                  overflowY: "auto",
                  paddingTop: "24px",
                  position: "absolute",
                  width: "100%",
                }}
              >
                <li
                  className="chr-header-v3__drawer-nav-li"
                  role="menuitem"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "2px 0px",
                    padding: "0px 8px",
                    cursor: "pointer",
                    position: "relative",
                  }}
                >
                  <a
                    className="chr-header-v3__drawer-nav-li-link chr-link--nav chr-link-first-level"
                    aria-label="home"
                    href="https://www.google.com/intl/en_in/chrome/"
                    tabIndex="0"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      cursor: "pointer",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      fontWeight: 500,
                      maxWidth: "100%",
                      borderRadius: "4px 46px 46px 4px",
                      padding: "0px 0px 0px 12px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      height: "46px",
                      marginBottom: "1px",
                      position: "relative",
                      width: "100%",
                      color: "rgb(95, 99, 104)",
                    }}
                  >
                    Home
                  </a>
                </li>
                <li
                  className="chr-header-v3__drawer-nav-li"
                  role="menuitem"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "2px 0px",
                    padding: "0px 8px",
                    cursor: "pointer",
                    position: "relative",
                  }}
                >
                  <a
                    className="chr-header-v3__drawer-nav-li-link chr-link--nav chr-link-first-level"
                    aria-label="the browser by google"
                    href="https://www.google.com/intl/en_in/chrome/browser-tools/"
                    tabIndex="0"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgba(0, 0, 0, 0)",
                      textDecoration: "none",
                      cursor: "pointer",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      fontWeight: 500,
                      maxWidth: "100%",
                      borderRadius: "4px 46px 46px 4px",
                      padding: "0px 0px 0px 12px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      height: "46px",
                      marginBottom: "1px",
                      position: "relative",
                      width: "100%",
                      color: "rgb(95, 99, 104)",
                    }}
                  >
                    The Browser by Google
                  </a>
                </li>
                <li
                  className="js-main-nav chr-header-v3__drawer-nav-li"
                  role="menuitem"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "2px 0px",
                    padding: "0px 8px",
                    cursor: "pointer",
                    position: "relative",
                  }}
                >
                  <button
                    className="chr-cta__button chr-cta__button-- chr-header-v3__drawer-nav-li chr-link-first-level chr-link--nav js-sub-trigger"
                    type="button"
                    aria-expanded="false"
                    aria-haspopup="true"
                    aria-label="features"
                    tabIndex="0"
                    style={{
                      boxSizing: "border-box",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      background: "none",
                      border: "none",
                      margin: "2px 0px",
                      appearance: "button",
                      cursor: "pointer",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      fontWeight: 500,
                      maxWidth: "100%",
                      color: "rgb(95, 99, 104)",
                      transition: "none",
                      borderRadius: "4px 46px 46px 4px",
                      padding: "0px 0px 0px 12px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      height: "46px",
                      marginBottom: "1px",
                      position: "relative",
                      width: "100%",
                    }}
                  >
                    {"Features"}
                    <svg
                      className="chr-icon chr-icon--link chr-icon--18"
                      style={{
                        boxSizing: "border-box",
                        display: "inline-block",
                        fill: "currentcolor",
                        verticalAlign: "middle",
                        overflow: "hidden",
                        height: "50%",
                        marginLeft: "4px",
                        width: "16px",
                        pointerEvents: "none",
                        transition: "transform 0.5s, -webkit-transform 0.5s",
                        transform: "rotateX(0deg)",
                      }}
                    >
                      <title style={{ boxSizing: "border-box" }}>
                        icon-expand-features
                      </title>
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                  <ul
                    className="chr-header-v3__drawer-subnav-list"
                    aria-label="features"
                    role="menu"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      listStyle: "none",
                      borderLeft: "2px solid rgb(218, 220, 224)",
                      padding: "0px",
                      transition: "max-height 0.5s cubic-bezier(0, 1, 0.5, 1)",
                      marginLeft: "13px",
                      maxHeight: "0px",
                      overflowY: "hidden",
                      visibility: "hidden",
                    }}
                  >
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="overview"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Overview
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="google search bar"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#google-search-bar"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Google address bar
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="password check"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#password-check"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Password check
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="Use across devices"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#use-across-devices"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Use across devices
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="dark mode"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#dark-mode"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Dark mode
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="tabs"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#tabs"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Tabs
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="articles for you"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#articles-for-you"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Articles for you
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="extensions"
                        href="https://www.google.com/intl/en_in/chrome/browser-features/#extensions"
                        tabIndex="-1"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Extensions
                      </a>
                    </li>
                  </ul>
                </li>
                <li
                  className="js-main-nav chr-header-v3__drawer-nav-li"
                  role="menuitem"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "2px 0px",
                    padding: "0px 8px",
                    cursor: "pointer",
                    position: "relative",
                  }}
                >
                  <button
                    className="chr-cta__button chr-cta__button-- chr-header-v3__drawer-nav-li chr-link-first-level chr-link--nav js-sub-trigger js-drawer-focus-trap"
                    type="button"
                    aria-expanded="false"
                    aria-haspopup="true"
                    aria-label="support"
                    style={{
                      boxSizing: "border-box",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      background: "none",
                      border: "none",
                      margin: "2px 0px",
                      appearance: "button",
                      cursor: "pointer",
                      fontFamily: '"Google Sans", arial, sans-serif',
                      fontWeight: 500,
                      maxWidth: "100%",
                      color: "rgb(95, 99, 104)",
                      transition: "none",
                      borderRadius: "4px 46px 46px 4px",
                      padding: "0px 0px 0px 12px",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      display: "flex",
                      height: "46px",
                      marginBottom: "1px",
                      position: "relative",
                      width: "100%",
                    }}
                  >
                    {"Support"}
                    <svg
                      className="chr-icon chr-icon--link chr-icon--18"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        display: "inline-block",
                        fill: "currentcolor",
                        verticalAlign: "middle",
                        overflow: "hidden",
                        height: "50%",
                        marginLeft: "4px",
                        width: "16px",
                        pointerEvents: "none",
                        transition: "transform 0.5s, -webkit-transform 0.5s",
                        transform: "rotateX(0deg)",
                      }}
                    >
                      <title style={{ boxSizing: "border-box" }}>
                        icon-expand-features
                      </title>
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#mi-expand"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                  <ul
                    className="chr-header-v3__drawer-subnav-list"
                    aria-label="features"
                    role="menu"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      listStyle: "none",
                      borderLeft: "2px solid rgb(218, 220, 224)",
                      padding: "0px",
                      transition: "max-height 0.5s cubic-bezier(0, 1, 0.5, 1)",
                      marginLeft: "13px",
                      maxHeight: "0px",
                      overflowY: "hidden",
                      visibility: "hidden",
                    }}
                  >
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav"
                        aria-label="tips"
                        href="https://www.google.com/intl/en_in/chrome/tips/"
                        tabIndex="0"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        Helpful tips for Chrome
                      </a>
                    </li>
                    <li
                      className="chr-header-v3__drawer-nav-li drawer-sub_link"
                      aria-level="2"
                      role="menuitem"
                      style={{
                        boxSizing: "border-box",
                        listStyle: "none",
                        margin: "2px 0px",
                        padding: "0px 8px",
                        cursor: "pointer",
                        position: "relative",
                      }}
                    >
                      <a
                        className="chr-link chr-link--external js-sub-link chr-header-v3__drawer-nav-li-link chr-link--nav js-drawer-focus-trap"
                        aria-label="support"
                        href="https://support.google.com/chrome?p=chromecom_home&hl=en-GB"
                        rel="noopener"
                        tabIndex="0"
                        target="_blank"
                        style={{
                          boxSizing: "border-box",
                          backgroundColor: "rgba(0, 0, 0, 0)",
                          textDecoration: "none",
                          fontSize: "1rem",
                          lineHeight: "1.5rem",
                          letterSpacing: "0rem",
                          borderRadius: "4px 46px 46px 4px",
                          padding: "0px 0px 0px 12px",
                          WebkitBoxAlign: "center",
                          alignItems: "center",
                          display: "flex",
                          height: "46px",
                          marginBottom: "1px",
                          position: "relative",
                          width: "100%",
                          cursor: "pointer",
                          fontFamily: '"Google Sans", arial, sans-serif',
                          fontWeight: 500,
                          maxWidth: "100%",
                          color: "rgb(95, 99, 104)",
                          paddingLeft: "12px",
                        }}
                      >
                        {"Support"}
                        <svg
                          className="chr-icon chr-icon--link"
                          aria-hidden="true"
                          style={{
                            boxSizing: "border-box",
                            display: "inline-block",
                            fill: "currentcolor",
                            verticalAlign: "middle",
                            overflow: "hidden",
                            transition: "0.3s",
                            height: "50%",
                            marginLeft: "4px",
                            width: "16px",
                            pointerEvents: "none",
                          }}
                        >
                          <use
                            xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                            style={{ boxSizing: "border-box" }}
                          />
                        </svg>
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
            <div
              className="chr-header-v3__drawer-cta-container shadow-elevation-2"
              style={{
                boxSizing: "border-box",
                boxShadow:
                  "rgba(32, 33, 36, 0.15) 0px 1px 2px, rgba(32, 33, 36, 0.08) 0px 1px 8px",
                padding: "16px",
                backgroundColor: "rgb(255, 255, 255)",
                bottom: "0px",
                height: "80px",
                maxWidth: "400px",
                position: "absolute",
                width: "100%",
              }}
            >
              <button
                id="js-download-mobile-drawer"
                className="chr-download-button chr-download-button--mobile-drawer js-download show"
                type="button"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  overflow: "visible",
                  textTransform: "none",
                  background: "none",
                  border: "none",
                  borderRadius: "24px",
                  gap: "8px",
                  padding: "12px 24px",
                  whiteSpace: "nowrap",
                  WebkitBoxAlign: "center",
                  alignItems: "center",
                  cursor: "pointer",
                  display: "inline-flex",
                  height: "auto",
                  WebkitBoxPack: "center",
                  justifyContent: "center",
                  backgroundColor: "rgb(26, 115, 232)",
                  color: "rgb(255, 255, 255)",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "reverse",
                  flexDirection: "row-reverse",
                  width: "100%",
                  fontSize: "1.125rem",
                  lineHeight: "1.5rem",
                  letterSpacing: "0rem",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 500,
                  appearance: "button",
                }}
              >
                <span
                  className="environment"
                  style={{ boxSizing: "border-box", display: "none" }}
                >
                  Get Chrome
                </span>
                <span
                  className="environment environment--active"
                  style={{ boxSizing: "border-box", display: "block" }}
                >
                  Download Chrome
                </span>
              </button>
            </div>
          </div>
        </div>
        <div
          id="js-drawer-backdrop"
          className="chr-header-v3__drawer-backdrop"
          style={{
            boxSizing: "border-box",
            transition: "opacity 0.15s cubic-bezier(0.4, 0, 0.2, 1)",
            background: "rgb(60, 64, 67)",
            height: "100lvh",
            left: "0px",
            opacity: 0,
            position: "fixed",
            right: "0px",
            top: "0px",
            visibility: "hidden",
            zIndex: 101,
            display: "none",
          }}
        />
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
