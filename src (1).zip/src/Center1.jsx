import React from "react";

export default function Center1() {
  return (
    <>
      <div
        className="chr-chrome-hero__logo"
        style={{
          boxSizing: "border-box",
          transition: "opacity 0.85s ease-out, top 0.85s ease-out",
          position: "relative",
          gridArea: "logo / 1 / logo / -1",
          opacity: 1,
          top: "0px",
        }}
      >
        <img
          alt="Google Chrome logo."
          role="img"
          src="https://www.google.com/chrome/static/images/chrome-logo-m100.svg"
          style={{
            boxSizing: "border-box",
            borderStyle: "none",
            margin: "auto",
            display: "block",
          }}
        />
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
