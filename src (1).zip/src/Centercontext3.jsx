import React from "react";

export default function Centercontext3() {
  return (
    <>
      <div
        className="chr-hero-fast-scrolable chr-hero-fast-scrolable--ready chr-hero-fast-scrolable--end"
        style={{
          boxSizing: "border-box",
          pointerEvents: "auto",
          willChange: "transform",
          transition: "opacity 0.6s ease-in",
          opacity: 1,
          inset: "0px auto auto 0px",
          margin: "0px",
          padding: "0px",
          translate: "none",
          rotate: "none",
          scale: "none",
          maxWidth: "1519px",
          width: "1519px",
          maxHeight: "1186px",
          height: "1186px",
          transform: "translate(0px, 470px)",
        }}
      >
        <div
          className="chr-non-chrome-fast"
          style={{ boxSizing: "border-box", width: "100%" }}
        >
          <div
            className="chr-grid-default-parent chr-non-chrome-fast__parent"
            style={{
              boxSizing: "border-box",
              margin: "auto",
              padding: "0px 74px",
              maxWidth: "1440px",
              WebkitBoxOrient: "vertical",
              WebkitBoxDirection: "normal",
              flexDirection: "column",
              WebkitBoxPack: "center",
              justifyContent: "center",
              display: "block",
            }}
          >
            <div
              className="chr-grid-default chr-non-chrome-fast__wrapper"
              style={{
                boxSizing: "border-box",
                display: "grid",
                columnGap: "64px",
                gridTemplateColumns: "repeat(12, 1fr)",
                gridTemplateRows: "80px [heading] auto 40px",
              }}
            >
              <h2
                className="chr-headline-1 chr-non-chrome-fast__heading"
                aria-label="The fast way to do things online"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  color: "rgb(32, 33, 36)",
                  fontFamily: '"Google Sans", arial, sans-serif',
                  fontWeight: 700,
                  fontSize: "3.75rem",
                  lineHeight: "4.5rem",
                  letterSpacing: "-0.078125rem",
                  gridArea: "heading / 1 / heading / -1",
                  gridColumn: "3 / span 8",
                  gridRow: "heading",
                  textAlign: "center",
                }}
              >
                {"The"}
                <span
                  className="chr-heading-pill chr-heading-pill__pill-container chr-heading-pill__pill-container--green chr-heading-pill__pill-container--medium animated"
                  aria-hidden="true"
                  style={{
                    boxSizing: "border-box",
                    overflow: "hidden",
                    position: "relative",
                    textAlign: "center",
                    borderRadius: "48px",
                    display: "inline-flex",
                    WebkitBoxOrient: "horizontal",
                    WebkitBoxDirection: "normal",
                    flexDirection: "row",
                    backgroundColor: "rgb(206, 234, 214)",
                    color: "rgb(24, 128, 56)",
                    WebkitBoxAlign: "center",
                    alignItems: "center",
                    transform: "none",
                    animationFillMode: "both",
                    animationTimingFunction: "ease-in-out",
                    lineHeight: "4.5rem",
                  }}
                >
                  <span
                    className="chr-heading-pill__mock"
                    style={{ boxSizing: "border-box", height: "40px" }}
                  />
                  <div
                    className="chr-lottie-animation chr-heading-pill__icon"
                    style={{
                      boxSizing: "border-box",
                      display: "inline-flex",
                      flexShrink: 0,
                      marginLeft: "8px",
                      height: "72px",
                      width: "72px",
                    }}
                  >
                    <svg
                      height="72"
                      width="72"
                      preserveAspectRatio="xMidYMid meet"
                      viewBox="0 0 72 72"
                      xmlns="http://www.w3.org/2000/svg"
                      style={{
                        boxSizing: "border-box",
                        overflow: "hidden",
                        width: "100%",
                        height: "100%",
                        transform: "translate3d(0px, 0px, 0px)",
                      }}
                    >
                      <defs style={{ boxSizing: "border-box" }}>
                        <clippath
                          id="__lottie_element_91"
                          style={{ boxSizing: "border-box" }}
                        >
                          <rect
                            height="72"
                            width="72"
                            x="0"
                            y="0"
                            style={{ boxSizing: "border-box" }}
                          />
                        </clippath>
                        <mask
                          id="__lottie_element_92"
                          style={{ boxSizing: "border-box" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(0.9902671575546265,0.13917966187000275,-0.13917966187000275,0.9902671575546265,36.46030807495117,35.95879364013672)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-0.125,4.25 C-0.125,4.25 9.5,-7.125 9.5,-7.125"
                                fillOpacity="0"
                                stroke="rgb(255,0,0)"
                                strokeLinecap="round"
                                strokeLinejoin="miter"
                                strokeMiterlimit="4"
                                strokeOpacity="1"
                                strokeWidth="14"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </mask>
                        <mask
                          id="__lottie_element_98"
                          style={{ boxSizing: "border-box" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,36,36)"
                            style={{
                              boxSizing: "border-box",
                              display: "block",
                            }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M14.875,-6.125 C14.875,-6.125 17.118000030517578,-5.285999774932861 17.68400001525879,3.1070001125335693 C18.25,11.5 14.375,14.25 14.375,14.25 C14.375,14.25 -14.375,14.5 -14.375,14.5 C-14.375,14.5 -20.59600067138672,3.9000000953674316 -14.762999534606934,-6.03000020980835 C-11.652999877929688,-11.324000358581543 -6.784999847412109,-13.845999717712402 0.004999999888241291,-14.187000274658203 C3.4010000228881836,-14.357000350952148 5.499000072479248,-13.644000053405762 8.439000129699707,-12.586999893188477"
                                fillOpacity="0"
                                stroke="rgb(255,255,255)"
                                strokeLinecap="butt"
                                strokeLinejoin="miter"
                                strokeMiterlimit="4"
                                strokeOpacity="1"
                                strokeWidth="14"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </mask>
                      </defs>
                      <g
                        clipPath="url(#__lottie_element_91)"
                        style={{ boxSizing: "border-box" }}
                      >
                        <g
                          mask="url(#__lottie_element_98)"
                          style={{ boxSizing: "border-box", display: "block" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(1,0,0,1,36.000999450683594,36)"
                            style={{ boxSizing: "border-box" }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M16.78499984741211,-6.881999969482422 C16.78499984741211,-6.881999969482422 14.305000305175781,-3.1619999408721924 14.305000305175781,-3.1619999408721924 C15.491000175476074,-0.7960000038146973 16.07200050354004,1.8279999494552612 15.994999885559082,4.473999977111816 C15.918000221252441,7.119999885559082 15.187000274658203,9.704999923706055 13.864999771118164,11.998000144958496 C13.864999771118164,11.998000144958496 -13.854999542236328,11.998000144958496 -13.854999542236328,11.998000144958496 C-15.572999954223633,9.017999649047852 -16.28499984741211,5.565000057220459 -15.885000228881836,2.1489999294281006 C-15.484999656677246,-1.2669999599456787 -13.994999885559082,-4.464000225067139 -11.63599967956543,-6.9670000076293945 C-9.277000427246094,-9.470000267028809 -6.175000190734863,-11.145000457763672 -2.7880001068115234,-11.746000289916992 C0.5989999771118164,-12.347000122070312 4.089000225067139,-11.840999603271484 7.164999961853027,-10.302000045776367 C7.164999961853027,-10.302000045776367 10.885000228881836,-12.781999588012695 10.885000228881836,-12.781999588012695 C6.943999767303467,-15.336000442504883 2.2290000915527344,-16.422000885009766 -2.431999921798706,-15.848999977111816 C-7.0929999351501465,-15.276000022888184 -11.402999877929688,-13.081999778747559 -14.609000205993652,-9.649999618530273 C-17.815000534057617,-6.2179999351501465 -19.711000442504883,-1.7669999599456787 -19.964000701904297,2.921999931335449 C-20.216999053955078,7.611000061035156 -18.812000274658203,12.239999771118164 -15.994999885559082,15.998000144958496 C-15.994999885559082,15.998000144958496 16.0049991607666,15.998000144958496 16.0049991607666,15.998000144958496 C18.45800018310547,12.720999717712402 19.84600067138672,8.770000457763672 19.98200035095215,4.677999973297119 C20.118000030517578,0.5860000252723694 18.9950008392334,-3.4489998817443848 16.764999389648438,-6.881999969482422 C16.764999389648438,-6.881999969482422 16.78499984741211,-6.881999969482422 16.78499984741211,-6.881999969482422z"
                                fill="rgb(24,128,56)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </g>
                        <g
                          mask="url(#__lottie_element_92)"
                          style={{ boxSizing: "border-box", display: "block" }}
                        >
                          <g
                            opacity="1"
                            transform="matrix(1,0.000006621236479986692,-0.000006621236479986692,1,40.96403503417969,34.91503143310547)"
                            style={{ boxSizing: "border-box" }}
                          >
                            <g
                              opacity="1"
                              transform="matrix(1,0,0,1,0,0)"
                              style={{ boxSizing: "border-box" }}
                            >
                              <path
                                d=" M-7.9029998779296875,7.9029998779296875 C-7.531000137329102,8.274999618530273 -7.091000080108643,8.571000099182129 -6.605000019073486,8.772000312805176 C-6.11899995803833,8.972999572753906 -5.598999977111816,9.07699966430664 -5.072999954223633,9.07699966430664 C-4.546999931335449,9.07699966430664 -4.0279998779296875,8.972999572753906 -3.5420000553131104,8.772000312805176 C-3.055999994277954,8.571000099182129 -2.614000082015991,8.274999618530273 -2.243000030517578,7.9029998779296875 C-2.243000030517578,7.9029998779296875 9.07699966430664,-9.07699966430664 9.07699966430664,-9.07699966430664 C9.07699966430664,-9.07699966430664 -7.9029998779296875,2.243000030517578 -7.9029998779296875,2.243000030517578 C-8.274999618530273,2.615000009536743 -8.571000099182129,3.055999994277954 -8.772000312805176,3.5420000553131104 C-8.972999572753906,4.0279998779296875 -9.07699966430664,4.546999931335449 -9.07699966430664,5.072999954223633 C-9.07699966430664,5.598999977111816 -8.972999572753906,6.11899995803833 -8.772000312805176,6.605000019073486 C-8.571000099182129,7.091000080108643 -8.274999618530273,7.531000137329102 -7.9029998779296875,7.9029998779296875z"
                                fill="rgb(24,128,56)"
                                fillOpacity="1"
                                style={{ boxSizing: "border-box" }}
                              />
                            </g>
                          </g>
                        </g>
                      </g>
                    </svg>
                  </div>
                  <span
                    className="chr-heading-pill__pill-text"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      whiteSpace: "nowrap",
                      display: "inline-flex",
                      maxHeight: "4.5rem",
                      fontSize: "3.25rem",
                      paddingRight: "32px",
                    }}
                  >
                    <span
                      className="chr-heading-pill__pill-char"
                      style={{
                        boxSizing: "border-box",
                        fontWeight: 500,
                        animationDelay: "20ms",
                        animationDuration: ".7s",
                        animationFillMode: "both",
                        animationName: "charBounceSlideInUp",
                        animationTimingFunction: "ease-in-out",
                        visibility: "visible",
                      }}
                    >
                      {"f"}
                    </span>
                    <span
                      className="chr-heading-pill__pill-char"
                      style={{
                        boxSizing: "border-box",
                        fontWeight: 500,
                        animationDelay: "40ms",
                        animationDuration: ".7s",
                        animationFillMode: "both",
                        animationName: "charBounceSlideInUp",
                        animationTimingFunction: "ease-in-out",
                        visibility: "visible",
                      }}
                    >
                      {"a"}
                    </span>
                    <span
                      className="chr-heading-pill__pill-char"
                      style={{
                        boxSizing: "border-box",
                        fontWeight: 500,
                        animationDelay: "60ms",
                        animationDuration: ".7s",
                        animationFillMode: "both",
                        animationName: "charBounceSlideInUp",
                        animationTimingFunction: "ease-in-out",
                        visibility: "visible",
                      }}
                    >
                      {"s"}
                    </span>
                    <span
                      className="chr-heading-pill__pill-char"
                      style={{
                        boxSizing: "border-box",
                        fontWeight: 500,
                        animationDelay: "80ms",
                        animationDuration: ".7s",
                        animationFillMode: "both",
                        animationName: "charBounceSlideInUp",
                        animationTimingFunction: "ease-in-out",
                        visibility: "visible",
                      }}
                    >
                      {"t"}
                    </span>
                  </span>
                </span>
                {"way to do things online"}
              </h2>
            </div>
          </div>
        </div>
        <div
          className="chr-hero-fast-scrolable__headline-trigger"
          style={{ boxSizing: "border-box", opacity: 0 }}
        />
        <div
          className="chr-hero-fast-scrolable__cards-desktop"
          style={{
            boxSizing: "border-box",
            display: "block",
            visibility: "visible",
          }}
        >
          <div
            id="fast-scrollable-carousel"
            className="chr-static-carousel chr-carousel chr-static-carousel--scrollable"
            style={{
              boxSizing: "border-box",
              padding: "40px 0",
              translate: "none",
              rotate: "none",
              scale: "none",
              transform: "translate(0px, 100px)",
            }}
          >
            <div
              className="chr-static-carousel__container chr-carousel__container"
              style={{
                boxSizing: "border-box",
                height: "auto",
                width: "100%",
                overflow: "hidden",
                padding: "unset",
              }}
            >
              <ul
                className="chr-static-carousel__wrapper chr-carousel__wrapper"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  padding: "0px",
                  display: "flex",
                  flexFlow: "row",
                  gap: "64px",
                  listStyle: "none",
                  scrollPadding:
                    "calc(74px + 1 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                  scrollbarWidth: "none",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "normal",
                  flexDirection: "row",
                  height: "auto",
                  overflowX: "scroll",
                  paddingLeft:
                    "calc(74px + 1 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                  scrollBehavior: "smooth",
                  scrollSnapType: "x mandatory",
                  width: "auto",
                }}
              >
                <li
                  className="chr-static-carousel__card chr-carousel__card chr-static-carousel__card--is-feature chr-carousel__card--is-feature"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                    borderColor: "rgb(218, 220, 224)",
                    overflow: "hidden",
                    translate: "none",
                    rotate: "none",
                    scale: "none",
                    transform: "translate(0px, 0px)",
                    height: "480px",
                    minWidth: "953px",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--landscape chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgb(255, 255, 255)",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                      height: "100%",
                      minHeight: "auto",
                      borderColor: "rgb(218, 220, 224)",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 80px 24px 64px",
                        minHeight: "216px",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flexBasis: "200px",
                          flexShrink: 0,
                        }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            color: "rgb(32, 33, 36)",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                          }}
                        >
                          {"Prioritise performance"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                          marginLeft: "40px",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "unset",
                            maxWidth: "480px",
                            width: "480px",
                          }}
                        >
                          {
                            "Chrome is built for performance. Optimise your experience with features like Energy Saver and Memory Saver."
                          }
                        </p>
                        <a
                          className="chr-link chr-link--primary chr-link--external chr-carousel-card__link"
                          href="https://blog.google/products/chrome/new-chrome-features-to-save-battery-and-make-browsing-smoother/"
                          rel="noopener"
                          target="_blank"
                          style={{
                            boxSizing: "border-box",
                            backgroundColor: "rgba(0, 0, 0, 0)",
                            textDecoration: "none",
                            padding: "12px 0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            display: "inline-block",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 500,
                            color: "rgb(25, 103, 210)",
                            marginTop: "8px",
                            width: "480px",
                          }}
                        >
                          {"Learn more about Memory and Energy"}
                          <span
                            className="chr-link-icon"
                            style={{
                              boxSizing: "border-box",
                              WebkitBoxAlign: "center",
                              alignItems: "center",
                              display: "inline-flex",
                              flexWrap: "nowrap",
                            }}
                          >
                            {"Saver"}
                            <svg
                              className="chr-link__icon"
                              aria-hidden="true"
                              style={{
                                boxSizing: "border-box",
                                overflow: "hidden",
                                transition:
                                  "transform 0.1s linear, -webkit-transform 0.1s linear",
                                height: "16px",
                                marginLeft: "6px",
                                verticalAlign: "middle",
                                width: "16px",
                                fill: "rgb(25, 103, 210)",
                              }}
                            >
                              <use
                                xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                                style={{ boxSizing: "border-box" }}
                              />
                            </svg>
                          </span>
                        </a>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-right chr-carousel-card__image-wrapper--only-on-mobile"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                        display: "none",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "right center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A cursor has clicked on the Energy Saver icon, which explains background activity and some visual effects have been limited to save memory."
                          srcSet="/chrome/static/images/homepage/fast/energy-saver_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "right center",
                          }}
                        />
                      </picture>
                    </div>
                    <div
                      className="chr-carousel-card__video-wrapper"
                      style={{
                        boxSizing: "border-box",
                        borderRadius: "unset",
                        flex: "1 1 0%",
                        aspectRatio: "unset",
                        display: "flex",
                        WebkitBoxFlex: "1",
                      }}
                    >
                      <video
                        className="chr-carousel__video shadow-ui"
                        aria-hidden="true"
                        muted
                        poster="/chrome/static/images/dev-components/home-poster-2x.webp"
                        preload="none"
                        style={{
                          boxSizing: "border-box",
                          display: "inline-block",
                          borderRadius: "20px",
                          position: "absolute",
                          translate: "none",
                          rotate: "none",
                          scale: "none",
                          width: "100%",
                          transform: "translate(-80px, 0px)",
                          boxShadow: "none",
                        }}
                      >
                        <source
                          type="video/webm"
                          src="https://www.google.com/chrome/static/videos/dev-components/non-chrome.webm"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="video/mp4"
                          src="https://www.google.com/chrome/static/videos/dev-components/non-chrome.mp4"
                          style={{ boxSizing: "border-box" }}
                        />
                      </video>
                      <img
                        className="chr-carousel__video shadow-ui"
                        style={{
                          boxSizing: "border-box",
                          borderStyle: "none",
                          boxShadow: "rgba(32, 33, 36, 0.1) 0px 8px 20px 0px",
                          width: "100%",
                          position: "absolute",
                          display: "none",
                        }}
                      />
                    </div>
                  </div>
                </li>
                <li
                  className="chr-static-carousel__card chr-carousel__card"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    minWidth:
                      "calc((min(100vw, 1440px) - 148px - 704px) / 12 * 9 + 512px)",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                    translate: "none",
                    rotate: "none",
                    scale: "none",
                    transform: "translate(0px, 0px)",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--landscape chr-carousel-card--yellow chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      minHeight: "480px",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                      backgroundColor: "rgb(253, 226, 147)",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 80px 24px 64px",
                        minHeight: "216px",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flexBasis: "200px",
                          flexShrink: 0,
                        }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            color: "rgb(32, 33, 36)",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                          }}
                        >
                          {"Stay on top of tabs"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                          marginLeft: "40px",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "unset",
                            maxWidth: "480px",
                          }}
                        >
                          {
                            "Chrome has tools to help you manage the tabs you’re not quite ready to close. Group, label, and colour-code your tabs to stay organised and work faster."
                          }
                        </p>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-left"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        display: "flex",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "left center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_mobile.webp 1x, /chrome/static/images/homepage/fast/tabs-groups_mobile-2x.webp 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_mobile.png 1x, /chrome/static/images/homepage/fast/tabs-groups_mobile-2x.png 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_desktop.webp 1x, /chrome/static/images/homepage/fast/tabs-groups_desktop-2x.webp 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_desktop.png 1x, /chrome/static/images/homepage/fast/tabs-groups_desktop-2x.png 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_tablet.webp 1x, /chrome/static/images/homepage/fast/tabs-groups_tablet-2x.webp 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_tablet.png 1x, /chrome/static/images/homepage/fast/tabs-groups_tablet-2x.png 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A browser UI features three groups of tabs: Personal, Trip to Arches and Work."
                          src="https://www.google.com/chrome/static/images/homepage/fast/tabs-groups_desktop.png"
                          srcSet="/chrome/static/images/homepage/fast/tabs-groups_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "left center",
                          }}
                        />
                      </picture>
                    </div>
                  </div>
                </li>
                <li
                  className="chr-static-carousel__card chr-carousel__card"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    minWidth:
                      "calc((min(100vw, 1440px) - 148px - 704px) / 12 * 9 + 512px)",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                    translate: "none",
                    rotate: "none",
                    scale: "none",
                    transform: "translate(0px, 0px)",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--vertical-qr chr-carousel-card--green chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      minHeight: "480px",
                      WebkitBoxOrient: "horizontal",
                      WebkitBoxDirection: "normal",
                      flexDirection: "row",
                      backgroundColor: "rgb(24, 128, 56)",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 24px 0 64px",
                        flexBasis: "360px",
                        WebkitBoxOrient: "vertical",
                        WebkitBoxDirection: "normal",
                        flexDirection: "column",
                        WebkitBoxPack: "start",
                        justifyContent: "flex-start",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{ boxSizing: "border-box" }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                            color: "rgb(255, 255, 255)",
                          }}
                        >
                          {"Optimised for your device"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "16px",
                            color: "rgb(255, 255, 255)",
                          }}
                        >
                          {
                            "Chrome is built to work with your device across platforms. That means a smooth experience on whatever you’re working with."
                          }
                        </p>
                      </div>
                      <div
                        className="chr-carousel-card__qr-wrapper"
                        style={{ boxSizing: "border-box", display: "flex" }}
                      >
                        <div
                          className="chr-qr-code chr-qr-code--container chr-carousel-card__qr"
                          style={{
                            boxSizing: "border-box",
                            WebkitBoxAlign: "center",
                            alignItems: "center",
                            display: "flex",
                            WebkitBoxOrient: "vertical",
                            WebkitBoxDirection: "normal",
                            flexDirection: "column",
                            textAlign: "center",
                            width: "fit-content",
                            borderRadius: "16px 16px 0px 0px",
                            padding: "24px",
                            backgroundColor: "rgb(255, 255, 255)",
                            position: "relative",
                          }}
                        >
                          <div
                            className="chr-qr-code__qr-container"
                            style={{
                              boxSizing: "border-box",
                              display: "flex",
                              height: "fit-content",
                              width: "auto",
                            }}
                          >
                            <img
                              className="js-lazy-load chr-qr-code__image"
                              alt="QR code to download chrome browser in mobile devices"
                              src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMDQgMTA0Jz48L3N2Zz4="
                              srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMDQgMTA0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAyMDggMjA4Jz48L3N2Zz4= 2x"
                              style={{
                                boxSizing: "border-box",
                                borderStyle: "none",
                                height: "104px",
                                width: "104px",
                              }}
                            />
                          </div>
                          <div
                            className="chr-qr-code__content"
                            style={{
                              boxSizing: "border-box",
                              marginTop: "8px",
                              maxWidth: "140px",
                            }}
                          >
                            <p
                              className="chr-caption"
                              style={{
                                boxSizing: "border-box",
                                margin: "0px",
                                fontSize: "0.75rem",
                                lineHeight: "1.125rem",
                                letterSpacing: "0.009375rem",
                                color: "rgb(95, 99, 104)",
                                fontFamily:
                                  '"Google Sans Text", arial, sans-serif',
                                fontWeight: 400,
                              }}
                            >
                              {"Scan for the"}
                              <br style={{ boxSizing: "border-box" }} /> Chrome
                              app{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-left"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        display: "flex",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "left center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDk2MCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDk2MCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A mobile device and a desktop computer both show the Google homepage on Chrome."
                          srcSet="/chrome/static/images/homepage/fast/devices_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "left center",
                          }}
                        />
                      </picture>
                    </div>
                  </div>
                </li>
                <span
                  className="chr-static-carousel__card-offset chr-carousel__card-offset"
                  aria-hidden="true"
                  style={{
                    boxSizing: "border-box",
                    height: "auto",
                    minWidth:
                      "calc(74px + 2 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                    opacity: 0,
                  }}
                />
              </ul>
            </div>
            <div
              className="chr-grid-default-parent"
              style={{
                boxSizing: "border-box",
                margin: "auto",
                padding: "0px 74px",
                maxWidth: "1440px",
              }}
            >
              <div
                className="chr-grid-default"
                style={{
                  boxSizing: "border-box",
                  display: "grid",
                  columnGap: "64px",
                  gridTemplateColumns: "repeat(12, 1fr)",
                }}
              >
                <div
                  className="chr-static-carousel__controls chr-carousel__controls"
                  style={{
                    boxSizing: "border-box",
                    gap: "16px",
                    gridColumn: "2 / span 10",
                    display: "flex",
                    WebkitBoxOrient: "horizontal",
                    WebkitBoxDirection: "normal",
                    flexDirection: "row",
                    marginTop: "40px",
                    transition: "opacity 0.2s",
                    opacity: 1,
                  }}
                >
                  <button
                    className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--prev chr-carousel__control-btn--prev"
                    aria-controls="fast-scrollable-carousel"
                    aria-hidden="true"
                    disabled
                    tabIndex="-1"
                    title="Previous card"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      appearance: "button",
                      background: "none",
                      border: "none",
                      fontFamily: "inherit",
                      borderRadius: "50%",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      cursor: "pointer",
                      display: "flex",
                      WebkitBoxPack: "center",
                      justifyContent: "center",
                      height: "56px",
                      width: "56px",
                      transition: "unset",
                      transform: "rotateZ(180deg)",
                      backgroundColor: "rgb(241, 243, 244)",
                    }}
                  >
                    <svg
                      className="chr-action-icon__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                        overflow: "hidden",
                        height: "32px",
                        width: "32px",
                        fill: "rgb(128, 134, 139)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                  <button
                    className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--next chr-carousel__control-btn--next"
                    aria-controls="fast-scrollable-carousel"
                    aria-hidden="true"
                    tabIndex="-1"
                    title="Next card"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      appearance: "button",
                      background: "none",
                      border: "none",
                      fontFamily: "inherit",
                      borderRadius: "50%",
                      transition:
                        "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      cursor: "pointer",
                      display: "flex",
                      WebkitBoxPack: "center",
                      justifyContent: "center",
                      transform: "scale(1)",
                      height: "56px",
                      width: "56px",
                      backgroundColor: "rgb(232, 240, 254)",
                    }}
                  >
                    <svg
                      className="chr-action-icon__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                        overflow: "hidden",
                        height: "32px",
                        width: "32px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="chr-hero-fast-scrolable__cards-mobile"
          style={{
            boxSizing: "border-box",
            display: "none",
            visibility: "hidden",
          }}
        >
          <div
            id="fast-scrollable-carousel"
            className="chr-static-carousel chr-carousel chr-static-carousel--scrollable"
            style={{ boxSizing: "border-box", padding: "40px 0" }}
          >
            <div
              className="chr-static-carousel__container chr-carousel__container"
              style={{
                boxSizing: "border-box",
                height: "auto",
                width: "100%",
                overflow: "hidden",
                padding: "unset",
              }}
            >
              <ul
                className="chr-static-carousel__wrapper chr-carousel__wrapper"
                style={{
                  boxSizing: "border-box",
                  margin: "0px",
                  padding: "0px",
                  display: "flex",
                  flexFlow: "row",
                  gap: "64px",
                  listStyle: "none",
                  scrollPadding:
                    "calc(74px + 1 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                  scrollbarWidth: "none",
                  WebkitBoxOrient: "horizontal",
                  WebkitBoxDirection: "normal",
                  flexDirection: "row",
                  height: "auto",
                  overflowX: "scroll",
                  paddingLeft:
                    "calc(74px + 1 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                  scrollBehavior: "smooth",
                  scrollSnapType: "x mandatory",
                  width: "auto",
                }}
              >
                <li
                  className="chr-static-carousel__card chr-carousel__card chr-static-carousel__card--is-feature chr-carousel__card--is-feature"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    minWidth:
                      "calc((min(100vw, 1440px) - 148px - 704px) / 12 * 9 + 512px)",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--landscape chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      backgroundColor: "rgb(255, 255, 255)",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                      overflow: "unset",
                      height: "100%",
                      minHeight: "auto",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 80px 24px 64px",
                        minHeight: "216px",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flexBasis: "200px",
                          flexShrink: 0,
                        }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            color: "rgb(32, 33, 36)",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                          }}
                        >
                          {"Prioritise performance"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                          marginLeft: "40px",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "unset",
                            maxWidth: "480px",
                          }}
                        >
                          {
                            "Chrome is built for performance. Optimise your experience with features like Energy Saver and Memory Saver."
                          }
                        </p>
                        <a
                          className="chr-link chr-link--primary chr-link--external chr-carousel-card__link"
                          href="https://blog.google/products/chrome/new-chrome-features-to-save-battery-and-make-browsing-smoother/"
                          rel="noopener"
                          target="_blank"
                          style={{
                            boxSizing: "border-box",
                            backgroundColor: "rgba(0, 0, 0, 0)",
                            textDecoration: "none",
                            padding: "12px 0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            display: "inline-block",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 500,
                            color: "rgb(25, 103, 210)",
                            marginTop: "8px",
                          }}
                        >
                          {"Learn more about Memory and Energy"}
                          <span
                            className="chr-link-icon"
                            style={{
                              boxSizing: "border-box",
                              WebkitBoxAlign: "center",
                              alignItems: "center",
                              display: "inline-flex",
                              flexWrap: "nowrap",
                            }}
                          >
                            {"Saver"}
                            <svg
                              className="chr-link__icon"
                              aria-hidden="true"
                              style={{
                                boxSizing: "border-box",
                                overflow: "hidden",
                                transition:
                                  "transform 0.1s linear, -webkit-transform 0.1s linear",
                                height: "16px",
                                marginLeft: "6px",
                                verticalAlign: "middle",
                                width: "16px",
                                fill: "rgb(25, 103, 210)",
                              }}
                            >
                              <use
                                xlinkHref="/chrome/static/images/site-icons.svg#arrow-external"
                                style={{ boxSizing: "border-box" }}
                              />
                            </svg>
                          </span>
                        </a>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-right chr-carousel-card__image-wrapper--only-on-mobile"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                        display: "none",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "right center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A cursor has clicked on the Energy Saver icon, which explains background activity and some visual effects have been limited to save memory."
                          srcSet="/chrome/static/images/homepage/fast/energy-saver_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "right center",
                          }}
                        />
                      </picture>
                    </div>
                    <div
                      className="chr-carousel-card__video-wrapper"
                      style={{
                        boxSizing: "border-box",
                        borderRadius: "unset",
                        flex: "1 1 0%",
                        aspectRatio: "unset",
                        display: "flex",
                        WebkitBoxFlex: "1",
                      }}
                    >
                      <video
                        className="chr-carousel__video shadow-ui"
                        aria-hidden="true"
                        muted
                        poster="/chrome/static/images/dev-components/home-poster-2x.webp"
                        preload="none"
                        style={{
                          boxSizing: "border-box",
                          display: "inline-block",
                          boxShadow: "rgba(32, 33, 36, 0.1) 0px 8px 20px 0px",
                          borderRadius: "20px",
                          width: "100%",
                          position: "absolute",
                        }}
                      >
                        <source
                          type="video/webm"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="video/mp4"
                          style={{ boxSizing: "border-box" }}
                        />
                      </video>
                      <img
                        className="chr-carousel__video shadow-ui"
                        style={{
                          boxSizing: "border-box",
                          borderStyle: "none",
                          boxShadow: "rgba(32, 33, 36, 0.1) 0px 8px 20px 0px",
                          width: "100%",
                          position: "absolute",
                          display: "none",
                        }}
                      />
                    </div>
                  </div>
                </li>
                <li
                  className="chr-static-carousel__card chr-carousel__card"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    minWidth:
                      "calc((min(100vw, 1440px) - 148px - 704px) / 12 * 9 + 512px)",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--landscape chr-carousel-card--yellow chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      minHeight: "480px",
                      WebkitBoxOrient: "vertical",
                      WebkitBoxDirection: "normal",
                      flexDirection: "column",
                      backgroundColor: "rgb(253, 226, 147)",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 80px 24px 64px",
                        minHeight: "216px",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flexBasis: "200px",
                          flexShrink: 0,
                        }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            color: "rgb(32, 33, 36)",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                          }}
                        >
                          {"Stay on top of tabs"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                          marginLeft: "40px",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            color: "rgb(95, 99, 104)",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "unset",
                            maxWidth: "480px",
                          }}
                        >
                          {
                            "Chrome has tools to help you manage the tabs you’re not quite ready to close. Group, label, and colour-code your tabs to stay organised and work faster."
                          }
                        </p>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-left"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        display: "flex",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "left center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA5NjAgMjY0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxOTIwIDUyOCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A browser UI features three groups of tabs: Personal, Trip to Arches and Work."
                          srcSet="/chrome/static/images/homepage/fast/tabs-groups_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "left center",
                          }}
                        />
                      </picture>
                    </div>
                  </div>
                </li>
                <li
                  className="chr-static-carousel__card chr-carousel__card"
                  tabIndex="0"
                  style={{
                    boxSizing: "border-box",
                    listStyle: "none",
                    margin: "0px",
                    padding: "0px",
                    borderRadius: "24px",
                    maxHeight: "min-content",
                    minWidth:
                      "calc((min(100vw, 1440px) - 148px - 704px) / 12 * 9 + 512px)",
                    scrollSnapAlign: "start",
                    scrollSnapStop: "always",
                  }}
                >
                  <div
                    className="chr-carousel-card chr-carousel-card--vertical-qr chr-carousel-card--green chr-carousel-card--border chr-static-carousel__gallery-card"
                    style={{
                      boxSizing: "border-box",
                      overflow: "hidden",
                      display: "flex",
                      WebkitBoxPack: "justify",
                      justifyContent: "space-between",
                      position: "relative",
                      width: "100%",
                      border: "1px solid rgb(218, 220, 224)",
                      borderRadius: "24px",
                      minHeight: "480px",
                      WebkitBoxOrient: "horizontal",
                      WebkitBoxDirection: "normal",
                      flexDirection: "row",
                      backgroundColor: "rgb(24, 128, 56)",
                    }}
                  >
                    <div
                      className="chr-carousel-card__text-wrapper"
                      style={{
                        boxSizing: "border-box",
                        display: "flex",
                        marginTop: "unset",
                        WebkitBoxOrdinalGroup: "unset",
                        order: "unset",
                        padding: "64px 24px 0 64px",
                        flexBasis: "360px",
                        WebkitBoxOrient: "vertical",
                        WebkitBoxDirection: "normal",
                        flexDirection: "column",
                        WebkitBoxPack: "start",
                        justifyContent: "flex-start",
                      }}
                    >
                      <div
                        className="chr-carousel-card__headings-wrapper"
                        style={{ boxSizing: "border-box" }}
                      >
                        <h3
                          className="chr-headline-4 chr-carousel-card__heading"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontFamily: '"Google Sans", arial, sans-serif',
                            fontWeight: 700,
                            fontSize: "1.75rem",
                            lineHeight: "2.25rem",
                            letterSpacing: "-0.03125rem",
                            color: "rgb(255, 255, 255)",
                          }}
                        >
                          {"Optimised for your device"}
                        </h3>
                      </div>
                      <div
                        className="chr-carousel-card__body-wrapper"
                        style={{
                          boxSizing: "border-box",
                          flex: "1 1 0%",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          WebkitBoxOrient: "vertical",
                          WebkitBoxDirection: "normal",
                          flexDirection: "column",
                          WebkitBoxPack: "start",
                          justifyContent: "flex-start",
                        }}
                      >
                        <p
                          className="chr-copy chr-carousel-card__body"
                          style={{
                            boxSizing: "border-box",
                            margin: "0px",
                            fontSize: "1rem",
                            lineHeight: "1.5rem",
                            letterSpacing: "0rem",
                            fontFamily: '"Google Sans Text", arial, sans-serif',
                            fontWeight: 400,
                            marginTop: "16px",
                            color: "rgb(255, 255, 255)",
                          }}
                        >
                          {
                            "Chrome is built to work with your device across platforms. That means a smooth experience on whatever you’re working with."
                          }
                        </p>
                      </div>
                      <div
                        className="chr-carousel-card__qr-wrapper"
                        style={{ boxSizing: "border-box", display: "flex" }}
                      >
                        <div
                          className="chr-qr-code chr-qr-code--container chr-carousel-card__qr"
                          style={{
                            boxSizing: "border-box",
                            WebkitBoxAlign: "center",
                            alignItems: "center",
                            display: "flex",
                            WebkitBoxOrient: "vertical",
                            WebkitBoxDirection: "normal",
                            flexDirection: "column",
                            textAlign: "center",
                            width: "fit-content",
                            borderRadius: "16px 16px 0px 0px",
                            padding: "24px",
                            backgroundColor: "rgb(255, 255, 255)",
                            position: "relative",
                          }}
                        >
                          <div
                            className="chr-qr-code__qr-container"
                            style={{
                              boxSizing: "border-box",
                              display: "flex",
                              height: "fit-content",
                              width: "auto",
                            }}
                          >
                            <img
                              className="js-lazy-load chr-qr-code__image"
                              alt="QR code to download chrome browser in mobile devices"
                              src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMDQgMTA0Jz48L3N2Zz4="
                              srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMDQgMTA0Jz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAyMDggMjA4Jz48L3N2Zz4= 2x"
                              style={{
                                boxSizing: "border-box",
                                borderStyle: "none",
                                height: "104px",
                                width: "104px",
                              }}
                            />
                          </div>
                          <div
                            className="chr-qr-code__content"
                            style={{
                              boxSizing: "border-box",
                              marginTop: "8px",
                              maxWidth: "140px",
                            }}
                          >
                            <p
                              className="chr-caption"
                              style={{
                                boxSizing: "border-box",
                                margin: "0px",
                                fontSize: "0.75rem",
                                lineHeight: "1.125rem",
                                letterSpacing: "0.009375rem",
                                color: "rgb(95, 99, 104)",
                                fontFamily:
                                  '"Google Sans Text", arial, sans-serif',
                                fontWeight: 400,
                              }}
                            >
                              {"Scan for the"}
                              <br style={{ boxSizing: "border-box" }} /> Chrome
                              app{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      className="chr-carousel-card__image-wrapper chr-carousel-card__image-wrapper--stick-left"
                      style={{
                        boxSizing: "border-box",
                        flex: "1 1 0%",
                        overflow: "hidden",
                        display: "flex",
                        WebkitBoxFlex: "1",
                        borderRadius: "unset",
                        aspectRatio: "unset",
                      }}
                    >
                      <picture
                        className="js-lazy-load"
                        style={{
                          boxSizing: "border-box",
                          display: "flex",
                          WebkitBoxFlex: "1",
                          flexGrow: 1,
                          minHeight: "100%",
                          objectFit: "cover",
                          width: "100%",
                          objectPosition: "left center",
                        }}
                      >
                        <source
                          type="image/webp"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(max-width: 599px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDk2MCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 1024px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDgwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDk2MCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/webp"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <source
                          type="image/png"
                          media="(min-width: 600px)"
                          srcSet="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA2MDAgNDAwJz48L3N2Zz4= 1x, data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAxMjAwIDgwMCc+PC9zdmc+ 2x"
                          style={{ boxSizing: "border-box" }}
                        />
                        <img
                          alt="A mobile device and a desktop computer both show the Google homepage on Chrome."
                          srcSet="/chrome/static/images/homepage/fast/devices_desktop.png"
                          style={{
                            boxSizing: "border-box",
                            borderStyle: "none",
                            display: "flex",
                            WebkitBoxFlex: "1",
                            flexGrow: 1,
                            minHeight: "100%",
                            objectFit: "cover",
                            width: "100%",
                            objectPosition: "left center",
                          }}
                        />
                      </picture>
                    </div>
                  </div>
                </li>
                <span
                  className="chr-static-carousel__card-offset chr-carousel__card-offset"
                  aria-hidden="true"
                  style={{
                    boxSizing: "border-box",
                    height: "auto",
                    minWidth:
                      "calc(74px + 2 * (min(100vw, 1440px) - 148px - 704px) / 12 + 64px + (max(100vw, 1440px) - 1440px) / 2)",
                    opacity: 0,
                  }}
                />
              </ul>
            </div>
            <div
              className="chr-grid-default-parent"
              style={{
                boxSizing: "border-box",
                margin: "auto",
                padding: "0px 74px",
                maxWidth: "1440px",
              }}
            >
              <div
                className="chr-grid-default"
                style={{
                  boxSizing: "border-box",
                  display: "grid",
                  columnGap: "64px",
                  gridTemplateColumns: "repeat(12, 1fr)",
                }}
              >
                <div
                  className="chr-static-carousel__controls chr-carousel__controls"
                  style={{
                    boxSizing: "border-box",
                    gap: "16px",
                    gridColumn: "2 / span 10",
                    display: "flex",
                    WebkitBoxOrient: "horizontal",
                    WebkitBoxDirection: "normal",
                    flexDirection: "row",
                    marginTop: "40px",
                    transition: "opacity 0.2s",
                    opacity: 1,
                  }}
                >
                  <button
                    className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--prev chr-carousel__control-btn--prev"
                    aria-controls="fast-scrollable-carousel"
                    aria-hidden="true"
                    disabled
                    tabIndex="-1"
                    title="Previous card"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      appearance: "button",
                      background: "none",
                      border: "none",
                      fontFamily: "inherit",
                      borderRadius: "50%",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      cursor: "pointer",
                      display: "flex",
                      WebkitBoxPack: "center",
                      justifyContent: "center",
                      height: "56px",
                      width: "56px",
                      transition: "unset",
                      transform: "rotateZ(180deg)",
                      backgroundColor: "rgb(241, 243, 244)",
                    }}
                  >
                    <svg
                      className="chr-action-icon__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                        overflow: "hidden",
                        height: "32px",
                        width: "32px",
                        fill: "rgb(128, 134, 139)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                  <button
                    className="chr-action-icon chr-action-icon--secondary chr-action-icon--regular chr-static-carousel__control-btn chr-static-carousel__control-btn--next chr-carousel__control-btn--next"
                    aria-controls="fast-scrollable-carousel"
                    aria-hidden="true"
                    tabIndex="-1"
                    title="Next card"
                    style={{
                      boxSizing: "border-box",
                      margin: "0px",
                      fontSize: "100%",
                      lineHeight: 1.15,
                      overflow: "visible",
                      textTransform: "none",
                      appearance: "button",
                      background: "none",
                      border: "none",
                      fontFamily: "inherit",
                      borderRadius: "50%",
                      transition:
                        "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                      WebkitBoxAlign: "center",
                      alignItems: "center",
                      cursor: "pointer",
                      display: "flex",
                      WebkitBoxPack: "center",
                      justifyContent: "center",
                      transform: "scale(1)",
                      height: "56px",
                      width: "56px",
                      backgroundColor: "rgb(232, 240, 254)",
                    }}
                  >
                    <svg
                      className="chr-action-icon__icon"
                      aria-hidden="true"
                      style={{
                        boxSizing: "border-box",
                        transition:
                          "transform 0.3s ease-out, -webkit-transform 0.3s ease-out",
                        overflow: "hidden",
                        height: "32px",
                        width: "32px",
                        fill: "rgb(25, 103, 210)",
                      }}
                    >
                      <use
                        xlinkHref="/chrome/static/images/site-icons.svg#arrow-forward"
                        style={{ boxSizing: "border-box" }}
                      />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  line-height: 1.15;
  text-size-adjust: 100%;
  overscroll-behavior-y: none;
}

body {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  word-break: break-word;
  overflow-wrap: break-word;
  margin: 0px;
  padding: 0px;
  background-color: rgb(255, 255, 255);
  font-family: "Google Sans", arial, sans-serif;
  overflow-x: hidden;
  overscroll-behavior-y: none;
}
`,
        }}
      />
    </>
  );
}
